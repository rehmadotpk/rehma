-- Create payment_gateways table for API management
CREATE TABLE IF NOT EXISTS payment_gateways (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  gateway_name TEXT NOT NULL UNIQUE,
  is_enabled BOOLEAN DEFAULT false,
  is_test_mode BOOLEAN DEFAULT true,
  api_key TEXT,
  api_secret TEXT,
  webhook_secret TEXT,
  config JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_by UUID REFERENCES auth.users(id)
);

-- Create seo_keywords table for keyword tracking
CREATE TABLE IF NOT EXISTS seo_keywords (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  keyword TEXT NOT NULL,
  search_volume INTEGER,
  difficulty INTEGER,
  current_position INTEGER,
  previous_position INTEGER,
  target_url TEXT,
  is_active BOOLEAN DEFAULT true,
  last_checked TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create seo_rankings table for historical tracking
CREATE TABLE IF NOT EXISTS seo_rankings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  keyword_id UUID REFERENCES seo_keywords(id) ON DELETE CASCADE,
  position INTEGER,
  search_volume INTEGER,
  checked_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create seo_reports table for email reports
CREATE TABLE IF NOT EXISTS seo_reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  report_date DATE NOT NULL,
  total_keywords INTEGER,
  improved_keywords INTEGER,
  declined_keywords INTEGER,
  average_position FLOAT,
  report_data JSONB,
  sent_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create seo_settings table for automation config
CREATE TABLE IF NOT EXISTS seo_settings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  auto_keyword_research BOOLEAN DEFAULT true,
  auto_ranking_check BOOLEAN DEFAULT true,
  daily_report_email TEXT,
  report_frequency TEXT DEFAULT 'daily',
  competitor_domains TEXT[],
  target_keywords_count INTEGER DEFAULT 50,
  min_search_volume INTEGER DEFAULT 100,
  max_difficulty INTEGER DEFAULT 70,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE payment_gateways ENABLE ROW LEVEL SECURITY;
ALTER TABLE seo_keywords ENABLE ROW LEVEL SECURITY;
ALTER TABLE seo_rankings ENABLE ROW LEVEL SECURITY;
ALTER TABLE seo_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE seo_settings ENABLE ROW LEVEL SECURITY;

-- Create policies for payment_gateways (admin only)
CREATE POLICY "Admin can view payment gateways" ON payment_gateways FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM user_profiles WHERE user_profiles.id = auth.uid() AND user_profiles.role = 'admin'
  )
);

CREATE POLICY "Admin can insert payment gateways" ON payment_gateways FOR INSERT WITH CHECK (
  EXISTS (
    SELECT 1 FROM user_profiles WHERE user_profiles.id = auth.uid() AND user_profiles.role = 'admin'
  )
);

CREATE POLICY "Admin can update payment gateways" ON payment_gateways FOR UPDATE USING (
  EXISTS (
    SELECT 1 FROM user_profiles WHERE user_profiles.id = auth.uid() AND user_profiles.role = 'admin'
  )
);

CREATE POLICY "Admin can delete payment gateways" ON payment_gateways FOR DELETE USING (
  EXISTS (
    SELECT 1 FROM user_profiles WHERE user_profiles.id = auth.uid() AND user_profiles.role = 'admin'
  )
);

-- Create policies for SEO tables (admin only)
CREATE POLICY "Admin can view seo_keywords" ON seo_keywords FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM user_profiles WHERE user_profiles.id = auth.uid() AND user_profiles.role = 'admin'
  )
);

CREATE POLICY "Admin can manage seo_keywords" ON seo_keywords FOR ALL USING (
  EXISTS (
    SELECT 1 FROM user_profiles WHERE user_profiles.id = auth.uid() AND user_profiles.role = 'admin'
  )
);

CREATE POLICY "Admin can view seo_rankings" ON seo_rankings FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM user_profiles WHERE user_profiles.id = auth.uid() AND user_profiles.role = 'admin'
  )
);

CREATE POLICY "Admin can manage seo_rankings" ON seo_rankings FOR ALL USING (
  EXISTS (
    SELECT 1 FROM user_profiles WHERE user_profiles.id = auth.uid() AND user_profiles.role = 'admin'
  )
);

CREATE POLICY "Admin can view seo_reports" ON seo_reports FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM user_profiles WHERE user_profiles.id = auth.uid() AND user_profiles.role = 'admin'
  )
);

CREATE POLICY "Admin can manage seo_reports" ON seo_reports FOR ALL USING (
  EXISTS (
    SELECT 1 FROM user_profiles WHERE user_profiles.id = auth.uid() AND user_profiles.role = 'admin'
  )
);

CREATE POLICY "Admin can view seo_settings" ON seo_settings FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM user_profiles WHERE user_profiles.id = auth.uid() AND user_profiles.role = 'admin'
  )
);

CREATE POLICY "Admin can manage seo_settings" ON seo_settings FOR ALL USING (
  EXISTS (
    SELECT 1 FROM user_profiles WHERE user_profiles.id = auth.uid() AND user_profiles.role = 'admin'
  )
);

-- Insert default payment gateways
INSERT INTO payment_gateways (gateway_name, is_enabled, is_test_mode) VALUES
  ('stripe', false, true),
  ('paypal', false, true),
  ('paypro', false, true)
ON CONFLICT (gateway_name) DO NOTHING;

-- Insert default SEO settings
INSERT INTO seo_settings (
  auto_keyword_research,
  auto_ranking_check,
  report_frequency,
  target_keywords_count,
  min_search_volume,
  max_difficulty
) VALUES (
  true,
  true,
  'daily',
  50,
  100,
  70
) ON CONFLICT DO NOTHING;