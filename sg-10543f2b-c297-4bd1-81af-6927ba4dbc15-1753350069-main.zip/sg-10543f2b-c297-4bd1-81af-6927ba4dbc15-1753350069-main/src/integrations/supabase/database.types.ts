 
export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.12 (cd3cf9e)"
  }
  public: {
    Tables: {
      approval_requests: {
        Row: {
          admin_notes: string | null
          approved_at: string | null
          approved_by: string | null
          created_at: string | null
          entity_id: string
          entity_type: string
          id: string
          priority: string
          rejection_reason: string | null
          requester_id: string | null
          status: string
          updated_at: string | null
        }
        Insert: {
          admin_notes?: string | null
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string | null
          entity_id: string
          entity_type: string
          id?: string
          priority?: string
          rejection_reason?: string | null
          requester_id?: string | null
          status?: string
          updated_at?: string | null
        }
        Update: {
          admin_notes?: string | null
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string | null
          entity_id?: string
          entity_type?: string
          id?: string
          priority?: string
          rejection_reason?: string | null
          requester_id?: string | null
          status?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      audit_logs: {
        Row: {
          action: string
          created_at: string
          id: string
          new_values: Json | null
          old_values: Json | null
          record_id: string | null
          table_name: string | null
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string
          id?: string
          new_values?: Json | null
          old_values?: Json | null
          record_id?: string | null
          table_name?: string | null
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          id?: string
          new_values?: Json | null
          old_values?: Json | null
          record_id?: string | null
          table_name?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      banners: {
        Row: {
          clicks: number | null
          conversions: number | null
          created_at: string | null
          cta_link: string | null
          cta_text: string | null
          ctr: number | null
          description: string | null
          end_date: string | null
          id: string
          image: string | null
          impressions: number | null
          is_active: boolean | null
          position: Database["public"]["Enums"]["banner_position"]
          priority: number | null
          revenue: number | null
          sponsor: string | null
          start_date: string | null
          title: string
          updated_at: string | null
        }
        Insert: {
          clicks?: number | null
          conversions?: number | null
          created_at?: string | null
          cta_link?: string | null
          cta_text?: string | null
          ctr?: number | null
          description?: string | null
          end_date?: string | null
          id?: string
          image?: string | null
          impressions?: number | null
          is_active?: boolean | null
          position: Database["public"]["Enums"]["banner_position"]
          priority?: number | null
          revenue?: number | null
          sponsor?: string | null
          start_date?: string | null
          title: string
          updated_at?: string | null
        }
        Update: {
          clicks?: number | null
          conversions?: number | null
          created_at?: string | null
          cta_link?: string | null
          cta_text?: string | null
          ctr?: number | null
          description?: string | null
          end_date?: string | null
          id?: string
          image?: string | null
          impressions?: number | null
          is_active?: boolean | null
          position?: Database["public"]["Enums"]["banner_position"]
          priority?: number | null
          revenue?: number | null
          sponsor?: string | null
          start_date?: string | null
          title?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      child_updates: {
        Row: {
          child_id: string
          created_at: string
          description: string | null
          id: string
          image: string | null
          title: string
        }
        Insert: {
          child_id: string
          created_at?: string
          description?: string | null
          id?: string
          image?: string | null
          title: string
        }
        Update: {
          child_id?: string
          created_at?: string
          description?: string | null
          id?: string
          image?: string | null
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "child_updates_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: false
            referencedRelation: "children"
            referencedColumns: ["id"]
          },
        ]
      }
      children: {
        Row: {
          age: number
          approval_status: string | null
          approved_at: string | null
          approved_by: string | null
          condition: string
          created_at: string | null
          created_by: string | null
          guardian: string
          guardian_contact: string
          id: string
          image: string | null
          is_active: boolean
          location: string
          medical_reports: string[] | null
          monthly_needs: number
          name: string
          raised_amount: number
          requirements: Json | null
          status: string | null
          story: string | null
          target_amount: number
          updated_at: string | null
          urgency: string | null
          urgent_need: string | null
          verified: boolean
        }
        Insert: {
          age: number
          approval_status?: string | null
          approved_at?: string | null
          approved_by?: string | null
          condition: string
          created_at?: string | null
          created_by?: string | null
          guardian: string
          guardian_contact: string
          id?: string
          image?: string | null
          is_active?: boolean
          location: string
          medical_reports?: string[] | null
          monthly_needs: number
          name: string
          raised_amount?: number
          requirements?: Json | null
          status?: string | null
          story?: string | null
          target_amount: number
          updated_at?: string | null
          urgency?: string | null
          urgent_need?: string | null
          verified?: boolean
        }
        Update: {
          age?: number
          approval_status?: string | null
          approved_at?: string | null
          approved_by?: string | null
          condition?: string
          created_at?: string | null
          created_by?: string | null
          guardian?: string
          guardian_contact?: string
          id?: string
          image?: string | null
          is_active?: boolean
          location?: string
          medical_reports?: string[] | null
          monthly_needs?: number
          name?: string
          raised_amount?: number
          requirements?: Json | null
          status?: string | null
          story?: string | null
          target_amount?: number
          updated_at?: string | null
          urgency?: string | null
          urgent_need?: string | null
          verified?: boolean
        }
        Relationships: []
      }
      contact_messages: {
        Row: {
          created_at: string
          email: string
          id: string
          message: string
          name: string
          status: string
          subject: string | null
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          message: string
          name: string
          status?: string
          subject?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          message?: string
          name?: string
          status?: string
          subject?: string | null
        }
        Relationships: []
      }
      doctors: {
        Row: {
          approval_status: string | null
          approved_at: string | null
          approved_by: string | null
          available_for_teleconsult: boolean | null
          bio: string | null
          consultation_fee: number | null
          contact_email: string | null
          contact_phone: string | null
          created_at: string
          education: string | null
          experience_years: number | null
          hospital_affiliation: string | null
          id: string
          is_available: boolean | null
          languages: string[] | null
          license_number: string | null
          location: string | null
          name: string | null
          profile_id: string | null
          qualification: string | null
          rating: number | null
          specialization: string | null
          status: string
          total_reviews: number | null
          updated_at: string
          verified: boolean | null
          years_experience: number | null
        }
        Insert: {
          approval_status?: string | null
          approved_at?: string | null
          approved_by?: string | null
          available_for_teleconsult?: boolean | null
          bio?: string | null
          consultation_fee?: number | null
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string
          education?: string | null
          experience_years?: number | null
          hospital_affiliation?: string | null
          id?: string
          is_available?: boolean | null
          languages?: string[] | null
          license_number?: string | null
          location?: string | null
          name?: string | null
          profile_id?: string | null
          qualification?: string | null
          rating?: number | null
          specialization?: string | null
          status?: string
          total_reviews?: number | null
          updated_at?: string
          verified?: boolean | null
          years_experience?: number | null
        }
        Update: {
          approval_status?: string | null
          approved_at?: string | null
          approved_by?: string | null
          available_for_teleconsult?: boolean | null
          bio?: string | null
          consultation_fee?: number | null
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string
          education?: string | null
          experience_years?: number | null
          hospital_affiliation?: string | null
          id?: string
          is_available?: boolean | null
          languages?: string[] | null
          license_number?: string | null
          location?: string | null
          name?: string | null
          profile_id?: string | null
          qualification?: string | null
          rating?: number | null
          specialization?: string | null
          status?: string
          total_reviews?: number | null
          updated_at?: string
          verified?: boolean | null
          years_experience?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "doctors_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "user_profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      documents: {
        Row: {
          document_type: string
          entity_id: string
          entity_type: string
          file_name: string
          file_path: string
          file_size: number | null
          id: string
          mime_type: string | null
          review_notes: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          uploaded_at: string | null
          uploaded_by: string | null
        }
        Insert: {
          document_type: string
          entity_id: string
          entity_type: string
          file_name: string
          file_path: string
          file_size?: number | null
          id?: string
          mime_type?: string | null
          review_notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          uploaded_at?: string | null
          uploaded_by?: string | null
        }
        Update: {
          document_type?: string
          entity_id?: string
          entity_type?: string
          file_name?: string
          file_path?: string
          file_size?: number | null
          id?: string
          mime_type?: string | null
          review_notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          uploaded_at?: string | null
          uploaded_by?: string | null
        }
        Relationships: []
      }
      donation_updates: {
        Row: {
          created_at: string
          donation_id: string
          id: string
          message: string | null
          status: string
        }
        Insert: {
          created_at?: string
          donation_id: string
          id?: string
          message?: string | null
          status: string
        }
        Update: {
          created_at?: string
          donation_id?: string
          id?: string
          message?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "donation_updates_donation_id_fkey"
            columns: ["donation_id"]
            isOneToOne: false
            referencedRelation: "donations"
            referencedColumns: ["id"]
          },
        ]
      }
      donations: {
        Row: {
          amount: number
          anonymous: boolean
          child_id: string | null
          created_at: string
          currency: string
          donation_type: Database["public"]["Enums"]["donation_type"]
          donor_email: string
          donor_id: string | null
          donor_name: string
          id: string
          message: string | null
          payment_method: Database["public"]["Enums"]["payment_method"]
          payment_status: Database["public"]["Enums"]["payment_status"]
          transaction_id: string | null
          updated_at: string
        }
        Insert: {
          amount: number
          anonymous?: boolean
          child_id?: string | null
          created_at?: string
          currency: string
          donation_type: Database["public"]["Enums"]["donation_type"]
          donor_email: string
          donor_id?: string | null
          donor_name: string
          id?: string
          message?: string | null
          payment_method: Database["public"]["Enums"]["payment_method"]
          payment_status?: Database["public"]["Enums"]["payment_status"]
          transaction_id?: string | null
          updated_at?: string
        }
        Update: {
          amount?: number
          anonymous?: boolean
          child_id?: string | null
          created_at?: string
          currency?: string
          donation_type?: Database["public"]["Enums"]["donation_type"]
          donor_email?: string
          donor_id?: string | null
          donor_name?: string
          id?: string
          message?: string | null
          payment_method?: Database["public"]["Enums"]["payment_method"]
          payment_status?: Database["public"]["Enums"]["payment_status"]
          transaction_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "donations_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: false
            referencedRelation: "children"
            referencedColumns: ["id"]
          },
        ]
      }
      newsletter_subscriptions: {
        Row: {
          created_at: string
          email: string
          id: string
          subscribed: boolean
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          subscribed?: boolean
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          subscribed?: boolean
        }
        Relationships: []
      }
      ngos: {
        Row: {
          address: string | null
          approval_status: string | null
          approved_at: string | null
          approved_by: string | null
          contact_email: string | null
          contact_person: string | null
          contact_phone: string | null
          created_at: string
          description: string | null
          focus_areas: string[] | null
          id: string
          organization_name: string | null
          profile_id: string | null
          registration_number: string | null
          status: string
          updated_at: string
          verification_documents: string[] | null
          verified: boolean | null
          website: string | null
        }
        Insert: {
          address?: string | null
          approval_status?: string | null
          approved_at?: string | null
          approved_by?: string | null
          contact_email?: string | null
          contact_person?: string | null
          contact_phone?: string | null
          created_at?: string
          description?: string | null
          focus_areas?: string[] | null
          id?: string
          organization_name?: string | null
          profile_id?: string | null
          registration_number?: string | null
          status?: string
          updated_at?: string
          verification_documents?: string[] | null
          verified?: boolean | null
          website?: string | null
        }
        Update: {
          address?: string | null
          approval_status?: string | null
          approved_at?: string | null
          approved_by?: string | null
          contact_email?: string | null
          contact_person?: string | null
          contact_phone?: string | null
          created_at?: string
          description?: string | null
          focus_areas?: string[] | null
          id?: string
          organization_name?: string | null
          profile_id?: string | null
          registration_number?: string | null
          status?: string
          updated_at?: string
          verification_documents?: string[] | null
          verified?: boolean | null
          website?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ngos_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "user_profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      notification_preferences: {
        Row: {
          child_updates: boolean | null
          created_at: string | null
          donation_updates: boolean | null
          email_notifications: boolean | null
          id: string
          newsletter: boolean | null
          push_notifications: boolean | null
          sms_notifications: boolean | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          child_updates?: boolean | null
          created_at?: string | null
          donation_updates?: boolean | null
          email_notifications?: boolean | null
          id?: string
          newsletter?: boolean | null
          push_notifications?: boolean | null
          sms_notifications?: boolean | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          child_updates?: boolean | null
          created_at?: string | null
          donation_updates?: boolean | null
          email_notifications?: boolean | null
          id?: string
          newsletter?: boolean | null
          push_notifications?: boolean | null
          sms_notifications?: boolean | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      notifications: {
        Row: {
          created_at: string
          id: string
          message: string
          read: boolean
          title: string
          type: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          message: string
          read?: boolean
          title: string
          type?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          message?: string
          read?: boolean
          title?: string
          type?: string
          user_id?: string | null
        }
        Relationships: []
      }
      order_items: {
        Row: {
          created_at: string
          id: string
          order_id: string
          price: number
          product_id: string
          quantity: number
        }
        Insert: {
          created_at?: string
          id?: string
          order_id: string
          price: number
          product_id: string
          quantity: number
        }
        Update: {
          created_at?: string
          id?: string
          order_id?: string
          price?: number
          product_id?: string
          quantity?: number
        }
        Relationships: [
          {
            foreignKeyName: "order_items_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      orders: {
        Row: {
          created_at: string
          id: string
          shipping_address: Json | null
          status: string
          total_amount: number
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          shipping_address?: Json | null
          status?: string
          total_amount: number
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          shipping_address?: Json | null
          status?: string
          total_amount?: number
          user_id?: string
        }
        Relationships: []
      }
      payment_gateways: {
        Row: {
          api_key: string | null
          api_secret: string | null
          config: Json | null
          created_at: string | null
          gateway_name: string
          id: string
          is_enabled: boolean | null
          is_test_mode: boolean | null
          updated_at: string | null
          updated_by: string | null
          webhook_secret: string | null
        }
        Insert: {
          api_key?: string | null
          api_secret?: string | null
          config?: Json | null
          created_at?: string | null
          gateway_name: string
          id?: string
          is_enabled?: boolean | null
          is_test_mode?: boolean | null
          updated_at?: string | null
          updated_by?: string | null
          webhook_secret?: string | null
        }
        Update: {
          api_key?: string | null
          api_secret?: string | null
          config?: Json | null
          created_at?: string | null
          gateway_name?: string
          id?: string
          is_enabled?: boolean | null
          is_test_mode?: boolean | null
          updated_at?: string | null
          updated_by?: string | null
          webhook_secret?: string | null
        }
        Relationships: []
      }
      products: {
        Row: {
          artist_age: number | null
          artist_name: string | null
          category: string | null
          created_at: string
          description: string | null
          featured: boolean | null
          id: string
          image: string | null
          name: string
          price: number
          rating: number | null
          reviews: number | null
        }
        Insert: {
          artist_age?: number | null
          artist_name?: string | null
          category?: string | null
          created_at?: string
          description?: string | null
          featured?: boolean | null
          id?: string
          image?: string | null
          name: string
          price: number
          rating?: number | null
          reviews?: number | null
        }
        Update: {
          artist_age?: number | null
          artist_name?: string | null
          category?: string | null
          created_at?: string
          description?: string | null
          featured?: boolean | null
          id?: string
          image?: string | null
          name?: string
          price?: number
          rating?: number | null
          reviews?: number | null
        }
        Relationships: []
      }
      seo_keywords: {
        Row: {
          created_at: string | null
          current_position: number | null
          difficulty: number | null
          id: string
          is_active: boolean | null
          keyword: string
          last_checked: string | null
          previous_position: number | null
          search_volume: number | null
          target_url: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          current_position?: number | null
          difficulty?: number | null
          id?: string
          is_active?: boolean | null
          keyword: string
          last_checked?: string | null
          previous_position?: number | null
          search_volume?: number | null
          target_url?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          current_position?: number | null
          difficulty?: number | null
          id?: string
          is_active?: boolean | null
          keyword?: string
          last_checked?: string | null
          previous_position?: number | null
          search_volume?: number | null
          target_url?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      seo_rankings: {
        Row: {
          checked_at: string | null
          created_at: string | null
          id: string
          keyword_id: string | null
          position: number | null
          search_volume: number | null
        }
        Insert: {
          checked_at?: string | null
          created_at?: string | null
          id?: string
          keyword_id?: string | null
          position?: number | null
          search_volume?: number | null
        }
        Update: {
          checked_at?: string | null
          created_at?: string | null
          id?: string
          keyword_id?: string | null
          position?: number | null
          search_volume?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "seo_rankings_keyword_id_fkey"
            columns: ["keyword_id"]
            isOneToOne: false
            referencedRelation: "seo_keywords"
            referencedColumns: ["id"]
          },
        ]
      }
      seo_reports: {
        Row: {
          average_position: number | null
          created_at: string | null
          declined_keywords: number | null
          id: string
          improved_keywords: number | null
          report_data: Json | null
          report_date: string
          sent_at: string | null
          total_keywords: number | null
        }
        Insert: {
          average_position?: number | null
          created_at?: string | null
          declined_keywords?: number | null
          id?: string
          improved_keywords?: number | null
          report_data?: Json | null
          report_date: string
          sent_at?: string | null
          total_keywords?: number | null
        }
        Update: {
          average_position?: number | null
          created_at?: string | null
          declined_keywords?: number | null
          id?: string
          improved_keywords?: number | null
          report_data?: Json | null
          report_date?: string
          sent_at?: string | null
          total_keywords?: number | null
        }
        Relationships: []
      }
      seo_settings: {
        Row: {
          auto_keyword_research: boolean | null
          auto_ranking_check: boolean | null
          competitor_domains: string[] | null
          created_at: string | null
          daily_report_email: string | null
          id: string
          max_difficulty: number | null
          min_search_volume: number | null
          report_frequency: string | null
          target_keywords_count: number | null
          updated_at: string | null
        }
        Insert: {
          auto_keyword_research?: boolean | null
          auto_ranking_check?: boolean | null
          competitor_domains?: string[] | null
          created_at?: string | null
          daily_report_email?: string | null
          id?: string
          max_difficulty?: number | null
          min_search_volume?: number | null
          report_frequency?: string | null
          target_keywords_count?: number | null
          updated_at?: string | null
        }
        Update: {
          auto_keyword_research?: boolean | null
          auto_ranking_check?: boolean | null
          competitor_domains?: string[] | null
          created_at?: string | null
          daily_report_email?: string | null
          id?: string
          max_difficulty?: number | null
          min_search_volume?: number | null
          report_frequency?: string | null
          target_keywords_count?: number | null
          updated_at?: string | null
        }
        Relationships: []
      }
      shop_items: {
        Row: {
          artist: string
          artist_age: number | null
          artist_contact: string | null
          auction_enabled: boolean | null
          auction_end_time: string | null
          bid_count: number | null
          category: Database["public"]["Enums"]["item_category"]
          created_at: string | null
          current_bid: number | null
          description: string | null
          id: string
          image: string | null
          is_active: boolean
          price: number
          rating: number | null
          sales: number | null
          story: string | null
          title: string
          updated_at: string | null
          verified: boolean
        }
        Insert: {
          artist: string
          artist_age?: number | null
          artist_contact?: string | null
          auction_enabled?: boolean | null
          auction_end_time?: string | null
          bid_count?: number | null
          category: Database["public"]["Enums"]["item_category"]
          created_at?: string | null
          current_bid?: number | null
          description?: string | null
          id?: string
          image?: string | null
          is_active?: boolean
          price: number
          rating?: number | null
          sales?: number | null
          story?: string | null
          title: string
          updated_at?: string | null
          verified?: boolean
        }
        Update: {
          artist?: string
          artist_age?: number | null
          artist_contact?: string | null
          auction_enabled?: boolean | null
          auction_end_time?: string | null
          bid_count?: number | null
          category?: Database["public"]["Enums"]["item_category"]
          created_at?: string | null
          current_bid?: number | null
          description?: string | null
          id?: string
          image?: string | null
          is_active?: boolean
          price?: number
          rating?: number | null
          sales?: number | null
          story?: string | null
          title?: string
          updated_at?: string | null
          verified?: boolean
        }
        Relationships: []
      }
      shop_owners: {
        Row: {
          address: string | null
          business_name: string
          business_type: string
          created_at: string | null
          description: string | null
          email: string
          id: string
          owner_name: string
          phone: string | null
          registration_number: string | null
          status: string
          tax_id: string | null
          updated_at: string | null
          user_id: string | null
          verified: boolean | null
        }
        Insert: {
          address?: string | null
          business_name: string
          business_type: string
          created_at?: string | null
          description?: string | null
          email: string
          id?: string
          owner_name: string
          phone?: string | null
          registration_number?: string | null
          status?: string
          tax_id?: string | null
          updated_at?: string | null
          user_id?: string | null
          verified?: boolean | null
        }
        Update: {
          address?: string | null
          business_name?: string
          business_type?: string
          created_at?: string | null
          description?: string | null
          email?: string
          id?: string
          owner_name?: string
          phone?: string | null
          registration_number?: string | null
          status?: string
          tax_id?: string | null
          updated_at?: string | null
          user_id?: string | null
          verified?: boolean | null
        }
        Relationships: []
      }
      system_settings: {
        Row: {
          category: string
          created_at: string
          description: string | null
          id: string
          setting_key: string
          setting_type: string
          setting_value: string | null
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          category: string
          created_at?: string
          description?: string | null
          id?: string
          setting_key: string
          setting_type: string
          setting_value?: string | null
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          category?: string
          created_at?: string
          description?: string | null
          id?: string
          setting_key?: string
          setting_type?: string
          setting_value?: string | null
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      user_profiles: {
        Row: {
          avatar_url: string | null
          bio: string | null
          created_at: string
          email: string
          full_name: string | null
          id: string
          location: string | null
          phone: string | null
          role: string
          updated_at: string
          verified: boolean
        }
        Insert: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          email: string
          full_name?: string | null
          id: string
          location?: string | null
          phone?: string | null
          role?: string
          updated_at?: string
          verified?: boolean
        }
        Update: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          email?: string
          full_name?: string | null
          id?: string
          location?: string | null
          phone?: string | null
          role?: string
          updated_at?: string
          verified?: boolean
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string | null
          id: string
          role: string
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          role?: string
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          role?: string
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      create_admin_user_bypass: {
        Args: { user_email: string; user_full_name: string; user_id: string }
        Returns: undefined
      }
      get_user_role: { Args: { user_id: string }; Returns: string }
      increment_banner_clicks: {
        Args: { banner_id: string }
        Returns: undefined
      }
      increment_banner_impressions: {
        Args: { banner_id: string }
        Returns: undefined
      }
      increment_shop_item_bids: {
        Args: { item_id: string; new_bid_amount: number }
        Returns: undefined
      }
      is_admin:
        | { Args: { user_id: string }; Returns: boolean }
        | { Args: never; Returns: boolean }
      update_child_support: {
        Args: { p_amount_added: number; p_child_id: string }
        Returns: {
          age: number
          approval_status: string | null
          approved_at: string | null
          approved_by: string | null
          condition: string
          created_at: string | null
          created_by: string | null
          guardian: string
          guardian_contact: string
          id: string
          image: string | null
          is_active: boolean
          location: string
          medical_reports: string[] | null
          monthly_needs: number
          name: string
          raised_amount: number
          requirements: Json | null
          status: string | null
          story: string | null
          target_amount: number
          updated_at: string | null
          urgency: string | null
          urgent_need: string | null
          verified: boolean
        }[]
        SetofOptions: {
          from: "*"
          to: "children"
          isOneToOne: false
          isSetofReturn: true
        }
      }
    }
    Enums: {
      banner_position: "hero" | "sidebar" | "between-sections" | "footer"
      child_category: "education" | "healthcare" | "nutrition" | "shelter"
      child_status: "active" | "sponsored" | "completed"
      donation_type: "one-time" | "monthly" | "emergency"
      item_category: "art" | "tshirt" | "nft"
      payment_method: "card" | "bank" | "paypal" | "crypto"
      payment_status: "pending" | "completed" | "failed" | "refunded"
      project_urgency: "low" | "medium" | "high"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      banner_position: ["hero", "sidebar", "between-sections", "footer"],
      child_category: ["education", "healthcare", "nutrition", "shelter"],
      child_status: ["active", "sponsored", "completed"],
      donation_type: ["one-time", "monthly", "emergency"],
      item_category: ["art", "tshirt", "nft"],
      payment_method: ["card", "bank", "paypal", "crypto"],
      payment_status: ["pending", "completed", "failed", "refunded"],
      project_urgency: ["low", "medium", "high"],
    },
  },
} as const
