import { supabase } from "@/integrations/supabase/client";
import { User, Session } from "@supabase/supabase-js";

export interface UserProfile {
  id: string;
  email: string;
  full_name: string | null;
  phone: string | null;
  role: string; // Changed from "admin" to flexible string
  avatar_url?: string | null;
  bio?: string | null;
  location?: string | null;
  verified: boolean;
  created_at: string;
  updated_at: string;
}

export interface SignUpData {
  email: string;
  password: string;
  fullName: string;
  phone?: string;
  role?: string; // Optional role parameter
}

export interface SignInData {
  email: string;
  password: string;
}

export const authService = {
  async signUp(data: SignUpData) {
    try {
      console.log('🚀 Starting signUp process for:', data.email);
      console.log('📝 SignUp data:', {
        email: data.email,
        fullName: data.fullName,
        phone: data.phone,
        role: data.role || 'user'
      });

      // Sign up the user with Supabase Auth
      // The database trigger will automatically create the profile
      console.log('📡 Calling supabase.auth.signUp...');
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: data.email,
        password: data.password,
        options: {
          data: {
            full_name: data.fullName,
            phone: data.phone || '',
            role: data.role || 'user' // Default to 'user' role for security
          }
        }
      });

      console.log('📡 Supabase signUp response:', {
        user: authData?.user ? { id: authData.user.id, email: authData.user.email } : null,
        session: authData?.session ? 'Session exists' : 'No session',
        error: authError
      });

      if (authError) {
        console.error('❌ Supabase signUp error:', authError);
        console.error('❌ Error details:', {
          message: authError.message,
          status: authError.status,
          name: authError.name
        });
        throw new Error(authError.message);
      }

      if (!authData.user) {
        console.error('❌ User creation failed - no user returned');
        throw new Error('User creation failed');
      }

      console.log('✅ User created successfully:', authData.user.id);

      // Wait a moment for the database trigger to create the profile
      console.log('⏳ Waiting for database trigger to complete...');
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Verify the profile was created by the trigger
      console.log('🔍 Verifying profile creation...');
      let attempts = 0;
      let profile = null;
      while (attempts < 5 && !profile) {
        console.log(`🔍 Profile check attempt ${attempts + 1}/5`);
        profile = await this.getUserProfile(authData.user.id);
        if (!profile) {
          console.log('⏳ Profile not found yet, waiting...');
          await new Promise(resolve => setTimeout(resolve, 500));
          attempts++;
        } else {
          console.log('✅ Profile found:', profile);
        }
      }

      if (!profile) {
        console.warn('⚠️ Profile not found after trigger, but this is not necessarily an error');
      }

      console.log('🎉 SignUp process completed successfully');
      return authData;
    } catch (error) {
      console.error('💥 SignUp service error:', error);
      console.error('💥 Error stack:', error instanceof Error ? error.stack : 'No stack trace');
      throw error;
    }
  },

  async signIn(data: SignInData) {
    try {
      const { data: authData, error } = await supabase.auth.signInWithPassword({
        email: data.email,
        password: data.password
      });

      if (error) {
        console.error('Supabase signIn error:', error);
        throw new Error(error.message);
      }

      return authData;
    } catch (error) {
      console.error('SignIn service error:', error);
      throw error;
    }
  },

  async signOut() {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) {
        console.error('Supabase signOut error:', error);
        throw new Error(error.message);
      }
    } catch (error) {
      console.error('SignOut service error:', error);
      throw error;
    }
  },

  async resetPassword(email: string) {
    try {
      // Get the current domain dynamically, but handle both dev and production
      const baseUrl = typeof window !== 'undefined' 
        ? window.location.origin 
        : process.env.NEXT_PUBLIC_SITE_URL || 'https://your-domain.com';
      
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${baseUrl}/auth/reset-password`
      });
      if (error) {
        console.error('Reset password error:', error);
        throw new Error(error.message);
      }
    } catch (error) {
      console.error('Reset password service error:', error);
      throw error;
    }
  },

  async updatePassword(newPassword: string) {
    try {
      const { error } = await supabase.auth.updateUser({
        password: newPassword
      });
      if (error) {
        console.error('Update password error:', error);
        throw new Error(error.message);
      }
    } catch (error) {
      console.error('Update password service error:', error);
      throw error;
    }
  },

  async getCurrentUser(): Promise<User | null> {
    try {
      const { data: { user }, error } = await supabase.auth.getUser();
      if (error) {
        console.error('Get current user error:', error);
        return null;
      }
      return user;
    } catch (error) {
      console.error('Get current user service error:', error);
      return null;
    }
  },

  async getCurrentSession(): Promise<Session | null> {
    try {
      const { data: { session }, error } = await supabase.auth.getSession();
      if (error) {
        console.error('Get current session error:', error);
        return null;
      }
      return session;
    } catch (error) {
      console.error('Get current session service error:', error);
      return null;
    }
  },

  async getUserProfile(userId: string): Promise<UserProfile | null> {
    try {
      // First try without .single() to see what we get
      const { data, error } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('id', userId);

      if (error) {
        console.error('Get user profile error:', error);
        return null;
      }

      // Check if we got results
      if (!data || data.length === 0) {
        console.log('No user profile found for user:', userId);
        return null;
      }

      // If we got multiple results, log a warning but return the first one
      if (data.length > 1) {
        console.warn(`Multiple profiles found for user ${userId}, returning first one:`, data);
      }

      return data[0] as UserProfile;
    } catch (error) {
      console.error('Get user profile service error:', error);
      return null;
    }
  },

  async updateUserProfile(userId: string, updates: Partial<UserProfile>): Promise<UserProfile | null> {
    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .update({
          ...updates,
          updated_at: new Date().toISOString()
        })
        .eq('id', userId)
        .select()
        .single();

      if (error) {
        console.error('Update user profile error:', error);
        return null;
      }

      return data as UserProfile;
    } catch (error) {
      console.error('Update user profile service error:', error);
      return null;
    }
  },

  async uploadAvatar(userId: string, file: File) {
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${userId}.${fileExt}`;
      const filePath = `avatars/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file, { upsert: true });

      if (uploadError) {
        console.error('Upload avatar error:', uploadError);
        throw new Error(uploadError.message);
      }

      const { data } = supabase.storage
        .from('avatars')
        .getPublicUrl(filePath);

      return data.publicUrl;
    } catch (error) {
      console.error('Upload avatar service error:', error);
      throw error;
    }
  },

  onAuthStateChange(callback: (event: string, session: Session | null) => void) {
    return supabase.auth.onAuthStateChange(callback);
  }
};

export default authService;
