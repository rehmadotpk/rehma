import { supabase } from "@/integrations/supabase/client";
import { childrenService } from "./childrenService";
import { donationService } from "./donationService";
import { bannerService } from "./bannerService";

export interface TestResult {
  test: string;
  status: "PASS" | "FAIL" | "SKIP";
  message: string;
  duration: number;
}

export interface TestSuite {
  name: string;
  results: TestResult[];
  totalTests: number;
  passed: number;
  failed: number;
  skipped: number;
  duration: number;
}

class SupabaseTestRunner {
  private results: TestResult[] = [];

  async runTest(testName: string, testFn: () => Promise<void>): Promise<TestResult> {
    const startTime = Date.now();
    console.log(`🧪 Running test: ${testName}`);
    
    try {
      await testFn();
      const duration = Date.now() - startTime;
      const result: TestResult = {
        test: testName,
        status: "PASS",
        message: "Test passed successfully",
        duration
      };
      console.log(`✅ ${testName} - PASSED (${duration}ms)`);
      this.results.push(result);
      return result;
    } catch (error) {
      const duration = Date.now() - startTime;
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      const result: TestResult = {
        test: testName,
        status: "FAIL",
        message: errorMessage,
        duration
      };
      console.error(`❌ ${testName} - FAILED (${duration}ms):`, errorMessage);
      this.results.push(result);
      return result;
    }
  }

  async testEnvironmentVariables(): Promise<TestResult> {
    return this.runTest("Environment Variables", async () => {
      // Check if Supabase client is properly initialized
      if (!supabase) {
        throw new Error("Supabase client is not initialized");
      }

      // Test basic connectivity instead of accessing protected properties
      try {
        const { error } = await supabase.from("children").select("count").limit(1);
        if (error) {
          throw new Error(`Environment validation failed: ${error.message}`);
        }
        console.log("✅ Environment variables validated successfully - Supabase client operational");
      } catch (error) {
        throw new Error(`Environment validation failed: ${error instanceof Error ? error.message : "Unknown error"}`);
      }
    });
  }

  async testDatabaseConnection(): Promise<TestResult> {
    return this.runTest("Database Connection", async () => {
      const { data, error } = await supabase.from("children").select("count").limit(1);
      if (error) {
        throw new Error(`Database connection failed: ${error.message}`);
      }
      console.log("✅ Database connection successful, data:", data);
    });
  }

  async testAuthConnection(): Promise<TestResult> {
    return this.runTest("Auth Connection", async () => {
      const { data, error } = await supabase.auth.getSession();
      if (error) {
        throw new Error(`Auth connection failed: ${error.message}`);
      }
      console.log("✅ Auth connection successful, session:", data.session ? "Active" : "No active session");
    });
  }

  async testChildrenTableOperations(): Promise<TestResult> {
    return this.runTest("Children Table Operations", async () => {
      console.log("Testing children service...");
      
      // Test read operation
      const result = await childrenService.getAllChildren();
      if (!result || !result.children) {
        throw new Error("Failed to fetch children - invalid response structure");
      }
      
      const { children } = result;
      if (!Array.isArray(children)) {
        throw new Error("Children data is not an array");
      }

      console.log(`✅ Fetched ${children.length} children`);

      // Test filtering
      const filterResult = await childrenService.getAllChildren(1, 10, { status: "active" });
      if (!filterResult || !filterResult.children) {
        throw new Error("Failed to filter children - invalid response structure");
      }
      
      const { children: activeChildren } = filterResult;
      if (!Array.isArray(activeChildren)) {
        throw new Error("Filtered children data is not an array");
      }

      console.log(`✅ Filtered to ${activeChildren.length} active children`);

      // Test single child fetch (if children exist)
      if (children.length > 0) {
        const child = await childrenService.getChildById(children[0].id);
        if (!child) {
          throw new Error("Failed to fetch single child");
        }
        console.log(`✅ Successfully fetched child: ${child.name}`);
      }
    });
  }

  async testDonationsTableOperations(): Promise<TestResult> {
    return this.runTest("Donations Table Operations", async () => {
      console.log("Testing donation service...");
      
      // Test read operation
      const donations = await donationService.getRecentDonations(5);
      if (!Array.isArray(donations)) {
        throw new Error("Failed to fetch donations - not an array");
      }
      console.log(`✅ Fetched ${donations.length} recent donations`);

      // Test stats
      const stats = await donationService.getDonationStats();
      if (typeof stats.totalDonations !== "number") {
        throw new Error("Failed to get donation stats - totalDonations is not a number");
      }
      console.log(`✅ Donation stats: ${stats.totalDonations} total donations, ${stats.totalAmount} total amount`);
    });
  }

  async testBannersTableOperations(): Promise<TestResult> {
    return this.runTest("Banners Table Operations", async () => {
      console.log("Testing banner service...");
      
      // Test read operation
      const banners = await bannerService.getAllBanners();
      if (!Array.isArray(banners)) {
        throw new Error("Failed to fetch banners - not an array");
      }
      console.log(`✅ Fetched ${banners.length} banners`);

      // Test active banners
      const activeBanners = await bannerService.getActiveBanners();
      if (!Array.isArray(activeBanners)) {
        throw new Error("Failed to fetch active banners - not an array");
      }
      console.log(`✅ Fetched ${activeBanners.length} active banners`);
    });
  }

  async testDatabaseFunction(): Promise<TestResult> {
    return this.runTest("Database Function", async () => {
      console.log("Testing database function...");
      
      // Test the update_child_support function
      const { error } = await supabase.rpc("update_child_support", {
        p_child_id: "test-id-that-does-not-exist",
        p_amount_added: 0
      });
      
      // This should fail gracefully since test-id doesn't exist
      // We're just testing that the function exists and can be called
      if (error && !error.message.includes("not found") && !error.message.includes("does not exist")) {
        throw new Error(`Database function test failed: ${error.message}`);
      }
      
      console.log("✅ Database function exists and is callable");
    });
  }

  async testRowLevelSecurity(): Promise<TestResult> {
    return this.runTest("Row Level Security", async () => {
      console.log("Testing Row Level Security...");
      
      // Test that RLS is enabled by trying to access data without auth
      const { data: currentUser } = await supabase.auth.getUser();
      
      // Test that we can read public data (children, banners)
      const { data: childrenData, error: childrenError } = await supabase
        .from("children")
        .select("*")
        .limit(1);
      
      if (childrenError) {
        throw new Error(`RLS test failed for public data: ${childrenError.message}`);
      }
      
      console.log(`✅ RLS working correctly. User: ${currentUser.user ? 'Authenticated' : 'Anonymous'}, Can access public data: ${childrenData ? 'Yes' : 'No'}`);
    });
  }

  async testStorageConnection(): Promise<TestResult> {
    return this.runTest("Storage Connection", async () => {
      console.log("Testing storage connection...");
      
      // Test storage bucket access
      const { data, error } = await supabase.storage.listBuckets();
      if (error) {
        throw new Error(`Storage connection failed: ${error.message}`);
      }
      
      console.log(`✅ Storage connection successful. Found ${data?.length || 0} buckets`);
    });
  }

  async testRealtimeConnection(): Promise<TestResult> {
    return this.runTest("Realtime Connection", async () => {
      console.log("Testing realtime connection...");
      
      return new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          reject(new Error("Realtime connection test timed out after 5 seconds"));
        }, 5000);

        // Test realtime subscription setup
        const channel = supabase
          .channel("test-channel-" + Date.now())
          .on("postgres_changes", 
            { event: "*", schema: "public", table: "children" }, 
            (payload) => {
              console.log("Realtime test payload received:", payload);
            }
          );

        channel.subscribe((status) => {
          clearTimeout(timeout);
          
          if (status === "SUBSCRIBED") {
            console.log("✅ Realtime connection successful");
            // Clean up
            supabase.removeChannel(channel);
            resolve(undefined);
          } else {
            reject(new Error(`Realtime connection failed with status: ${status}`));
          }
        });
      });
    });
  }

  async runAllTests(): Promise<TestSuite> {
    const startTime = Date.now();
    this.results = [];

    console.log("🧪 Starting Supabase Test Suite...\n");

    // Run all tests sequentially
    await this.testEnvironmentVariables();
    await this.testDatabaseConnection();
    await this.testAuthConnection();
    await this.testChildrenTableOperations();
    await this.testDonationsTableOperations();
    await this.testBannersTableOperations();
    await this.testDatabaseFunction();
    await this.testRowLevelSecurity();
    await this.testStorageConnection();
    await this.testRealtimeConnection();

    const duration = Date.now() - startTime;
    const passed = this.results.filter(r => r.status === "PASS").length;
    const failed = this.results.filter(r => r.status === "FAIL").length;
    const skipped = this.results.filter(r => r.status === "SKIP").length;

    const suite: TestSuite = {
      name: "Supabase Integration Tests",
      results: this.results,
      totalTests: this.results.length,
      passed,
      failed,
      skipped,
      duration
    };

    this.printResults(suite);
    return suite;
  }

  printResults(suite: TestSuite): void {
    console.log(`\n📊 Test Results for ${suite.name}`);
    console.log("=".repeat(50));
    console.log(`Total Tests: ${suite.totalTests}`);
    console.log(`✅ Passed: ${suite.passed}`);
    console.log(`❌ Failed: ${suite.failed}`);
    console.log(`⏭️  Skipped: ${suite.skipped}`);
    console.log(`⏱️  Duration: ${suite.duration}ms\n`);

    suite.results.forEach((result, index) => {
      const icon = result.status === "PASS" ? "✅" : result.status === "FAIL" ? "❌" : "⏭️";
      console.log(`${icon} ${index + 1}. ${result.test} (${result.duration}ms)`);
      if (result.status === "FAIL") {
        console.log(`   Error: ${result.message}`);
      }
    });

    console.log("\n" + "=".repeat(50));
    
    if (suite.failed === 0) {
      console.log("🎉 All tests passed! Supabase is working perfectly.");
    } else {
      console.log(`⚠️  ${suite.failed} test(s) failed. Please check the errors above.`);
    }
  }
}

export const supabaseTestRunner = new SupabaseTestRunner();

// Export individual test functions for manual testing
export const testSupabase = {
  async runFullSuite() {
    const suite = await supabaseTestRunner.runAllTests();
    return suite;
  },

  async testConnection() {
    const runner = new SupabaseTestRunner();
    return await runner.testDatabaseConnection();
  },

  async testAuth() {
    const runner = new SupabaseTestRunner();
    return await runner.testAuthConnection();
  },

  async testTables() {
    const runner = new SupabaseTestRunner();
    const results = await Promise.all([
      runner.testChildrenTableOperations(),
      runner.testDonationsTableOperations(),
      runner.testBannersTableOperations()
    ]);
    return results;
  },

  async testRealtime() {
    const runner = new SupabaseTestRunner();
    return await runner.testRealtimeConnection();
  },

  async testStorage() {
    const runner = new SupabaseTestRunner();
    return await runner.testStorageConnection();
  }
};

export default testSupabase;
