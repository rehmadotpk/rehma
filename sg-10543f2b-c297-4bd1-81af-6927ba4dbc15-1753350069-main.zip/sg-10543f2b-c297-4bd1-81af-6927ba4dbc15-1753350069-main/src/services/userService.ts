import { supabase } from "@/integrations/supabase/client";
import { UserProfile } from "./authService";

export const userService = {
  async getAllUsers(): Promise<UserProfile[]> {
    try {
      const { data, error } = await supabase
        .from("user_profiles")
        .select("*");

      if (error) {
        console.error("Error fetching users:", error);
        throw error;
      }
      return data || [];
    } catch (error) {
      console.error("Service error fetching users:", error);
      throw error;
    }
  },

  async getUserById(userId: string): Promise<UserProfile | null> {
    try {
      const { data, error } = await supabase
        .from("user_profiles")
        .select("*")
        .eq("id", userId);

      if (error) {
        console.error(`Error fetching user ${userId}:`, error);
        return null;
      }

      // Check if we got results
      if (!data || data.length === 0) {
        console.log(`No user profile found for user: ${userId}`);
        return null;
      }

      // If we got multiple results, log a warning but return the first one
      if (data.length > 1) {
        console.warn(`Multiple profiles found for user ${userId}, returning first one:`, data);
      }

      return data[0] as UserProfile;
    } catch (error) {
      console.error(`Service error fetching user ${userId}:`, error);
      return null;
    }
  },

  async updateUser(userId: string, updates: Partial<Omit<UserProfile, "id" | "email" | "role" | "created_at">>): Promise<UserProfile | null> {
    try {
      const { data, error } = await supabase
        .from("user_profiles")
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq("id", userId)
        .select()
        .single();

      if (error) {
        console.error(`Error updating user ${userId}:`, error);
        return null;
      }
      return data;
    } catch (error) {
      console.error(`Service error updating user ${userId}:`, error);
      return null;
    }
  },

  async deleteUser(userId: string): Promise<boolean> {
    try {
      // This should ideally be a call to a secure backend function
      // that also handles deleting the user from `auth.users`.
      // For now, just deleting the profile.
      const { error } = await supabase
        .from("user_profiles")
        .delete()
        .eq("id", userId);

      if (error) {
        console.error(`Error deleting user ${userId}:`, error);
        return false;
      }
      return true;
    } catch (error) {
      console.error(`Service error deleting user ${userId}:`, error);
      return false;
    }
  }
};

export default userService;
