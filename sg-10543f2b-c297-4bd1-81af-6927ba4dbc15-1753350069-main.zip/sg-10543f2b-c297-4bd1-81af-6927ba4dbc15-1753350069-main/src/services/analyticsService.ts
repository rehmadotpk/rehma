import { supabase } from "@/integrations/supabase/client";

export interface AnalyticsData {
  donations: {
    totalAmount: number;
    totalCount: number;
    averageAmount: number;
    monthlyTrend: Array<{ month: string; amount: number; count: number }>;
    topDonors: Array<{ name: string; amount: number; donations: number }>;
    paymentMethods: Array<{ method: string; amount: number; percentage: number }>;
  };
  children: {
    totalActive: number;
    totalCompleted: number;
    averageGoal: number;
    completionRate: number;
    urgencyDistribution: Array<{ urgency: string; count: number; percentage: number }>;
    locationDistribution: Array<{ location: string; count: number; amount: number }>;
  };
  users: {
    totalUsers: number;
    newUsersThisMonth: number;
    usersByRole: Array<{ role: string; count: number; percentage: number }>;
    retentionRate: number;
    engagementMetrics: {
      averageSessionTime: number;
      averageDonationsPerUser: number;
      returnVisitorRate: number;
    };
  };
  performance: {
    conversionRate: number;
    averageTimeToFirstDonation: number;
    platformGrowthRate: number;
    successStories: number;
  };
}

export interface DateRange {
  startDate: string;
  endDate: string;
}

class AnalyticsService {
  // Get comprehensive analytics data
  async getAnalyticsData(dateRange?: DateRange): Promise<AnalyticsData> {
    const startDate = dateRange?.startDate || new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString();
    const endDate = dateRange?.endDate || new Date().toISOString();

    const [donations, children, users, performance] = await Promise.all([
      this.getDonationAnalytics(startDate, endDate),
      this.getChildrenAnalytics(startDate, endDate),
      this.getUserAnalytics(startDate, endDate),
      this.getPerformanceAnalytics()
    ]);

    return {
      donations,
      children,
      users,
      performance
    };
  }

  // Donation analytics
  private async getDonationAnalytics(startDate: string, endDate: string) {
    // Get donation data
    const { data: donationsData } = await supabase
      .from('donations')
      .select('*')
      .eq('payment_status', 'completed')
      .gte('created_at', startDate)
      .lte('created_at', endDate);

    const donations = donationsData || [];
    const totalAmount = donations.reduce((sum, d) => sum + d.amount, 0);
    const totalCount = donations.length;
    const averageAmount = totalCount > 0 ? totalAmount / totalCount : 0;

    // Monthly trend
    const monthlyTrend = this.calculateMonthlyTrend(donations);

    // Top donors
    const donorMap = new Map();
    donations.forEach(d => {
      const key = d.donor_name || 'Anonymous';
      if (!donorMap.has(key)) {
        donorMap.set(key, { name: key, amount: 0, donations: 0 });
      }
      const donor = donorMap.get(key);
      donor.amount += d.amount;
      donor.donations += 1;
    });
    const topDonors = Array.from(donorMap.values())
      .sort((a, b) => b.amount - a.amount)
      .slice(0, 10);

    // Payment methods
    const methodMap = new Map();
    donations.forEach(d => {
      const method = d.payment_method || 'unknown';
      if (!methodMap.has(method)) {
        methodMap.set(method, 0);
      }
      methodMap.set(method, methodMap.get(method) + d.amount);
    });
    const paymentMethods = Array.from(methodMap.entries()).map(([method, amount]) => ({
      method,
      amount,
      percentage: totalAmount > 0 ? (amount / totalAmount) * 100 : 0
    }));

    return {
      totalAmount,
      totalCount,
      averageAmount,
      monthlyTrend,
      topDonors,
      paymentMethods
    };
  }

  // Children analytics
  private async getChildrenAnalytics(startDate: string, endDate: string) {
    const { data: childrenData } = await supabase
      .from('children')
      .select('*')
      .gte('created_at', startDate)
      .lte('created_at', endDate);

    const children = childrenData || [];
    const totalActive = children.filter(c => c.status === 'active').length;
    const totalCompleted = children.filter(c => c.status === 'completed').length;
    const averageGoal = children.length > 0 ? 
      children.reduce((sum, c) => sum + c.target_amount, 0) / children.length : 0;
    const completionRate = children.length > 0 ? (totalCompleted / children.length) * 100 : 0;

    // Urgency distribution
    const urgencyMap = new Map();
    children.forEach(c => {
      const urgency = c.urgency || 'low';
      urgencyMap.set(urgency, (urgencyMap.get(urgency) || 0) + 1);
    });
    const urgencyDistribution = Array.from(urgencyMap.entries()).map(([urgency, count]) => ({
      urgency,
      count,
      percentage: children.length > 0 ? (count / children.length) * 100 : 0
    }));

    // Location distribution
    const locationMap = new Map();
    children.forEach(c => {
      const location = c.location || 'Unknown';
      if (!locationMap.has(location)) {
        locationMap.set(location, { count: 0, amount: 0 });
      }
      const loc = locationMap.get(location);
      loc.count += 1;
      loc.amount += c.raised_amount || 0;
    });
    const locationDistribution = Array.from(locationMap.entries()).map(([location, data]) => ({
      location,
      count: data.count,
      amount: data.amount
    }));

    return {
      totalActive,
      totalCompleted,
      averageGoal,
      completionRate,
      urgencyDistribution,
      locationDistribution
    };
  }

  // User analytics
  private async getUserAnalytics(startDate: string, endDate: string) {
    const { data: usersData } = await supabase
      .from('user_profiles')
      .select('*')
      .gte('created_at', startDate)
      .lte('created_at', endDate);

    const users = usersData || [];
    const totalUsers = users.length;

    // New users this month
    const thisMonth = new Date();
    thisMonth.setDate(1);
    const newUsersThisMonth = users.filter(u => 
      new Date(u.created_at) >= thisMonth
    ).length;

    // Users by role
    const roleMap = new Map();
    users.forEach(u => {
      const role = u.role || 'user';
      roleMap.set(role, (roleMap.get(role) || 0) + 1);
    });
    const usersByRole = Array.from(roleMap.entries()).map(([role, count]) => ({
      role,
      count,
      percentage: totalUsers > 0 ? (count / totalUsers) * 100 : 0
    }));

    // Mock engagement metrics (would need more detailed tracking in production)
    const engagementMetrics = {
      averageSessionTime: 8.5, // minutes
      averageDonationsPerUser: 2.3,
      returnVisitorRate: 65.2 // percentage
    };

    const retentionRate = 78.5; // Mock retention rate

    return {
      totalUsers,
      newUsersThisMonth,
      usersByRole,
      retentionRate,
      engagementMetrics
    };
  }

  // Performance analytics
  private async getPerformanceAnalytics() {
    // Mock performance data (would need detailed tracking in production)
    return {
      conversionRate: 12.8, // percentage of visitors who donate
      averageTimeToFirstDonation: 3.2, // days
      platformGrowthRate: 15.6, // monthly growth percentage
      successStories: 45 // number of children who reached their goals
    };
  }

  // Helper method to calculate monthly trend
  private calculateMonthlyTrend(donations: { created_at: string; amount: number }[]) {
    const monthMap = new Map<string, { amount: number; count: number }>();
    
    donations.forEach(d => {
      const date = new Date(d.created_at);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      
      if (!monthMap.has(monthKey)) {
        monthMap.set(monthKey, { amount: 0, count: 0 });
      }
      
      const month = monthMap.get(monthKey);
      month.amount += d.amount;
      month.count += 1;
    });

    return Array.from(monthMap.entries())
      .map(([month, data]) => ({
        month,
        amount: data.amount,
        count: data.count
      }))
      .sort((a, b) => a.month.localeCompare(b.month));
  }

  // Get donation insights
  async getDonationInsights(childId?: string): Promise<{
    totalRaised: number;
    donorCount: number;
    averageDonation: number;
    recentTrend: 'up' | 'down' | 'stable';
    projectedCompletion?: string;
  }> {
    let query = supabase
      .from('donations')
      .select('*')
      .eq('payment_status', 'completed');

    if (childId) {
      query = query.eq('child_id', childId);
    }

    const { data: donations } = await query;
    const donationList = donations || [];

    const totalRaised = donationList.reduce((sum, d) => sum + d.amount, 0);
    const donorCount = new Set(donationList.map(d => d.donor_id)).size;
    const averageDonation = donationList.length > 0 ? totalRaised / donationList.length : 0;

    // Calculate trend (comparing last 30 days vs previous 30 days)
    const now = new Date();
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    const sixtyDaysAgo = new Date(now.getTime() - 60 * 24 * 60 * 60 * 1000);

    const recentDonations = donationList.filter(d => new Date(d.created_at) >= thirtyDaysAgo);
    const previousDonations = donationList.filter(d => {
      const date = new Date(d.created_at);
      return date >= sixtyDaysAgo && date < thirtyDaysAgo;
    });

    const recentTotal = recentDonations.reduce((sum, d) => sum + d.amount, 0);
    const previousTotal = previousDonations.reduce((sum, d) => sum + d.amount, 0);

    let recentTrend: 'up' | 'down' | 'stable' = 'stable';
    if (recentTotal > previousTotal * 1.1) recentTrend = 'up';
    else if (recentTotal < previousTotal * 0.9) recentTrend = 'down';

    return {
      totalRaised,
      donorCount,
      averageDonation,
      recentTrend
    };
  }

  // Export analytics data
  async exportAnalyticsData(format: 'csv' | 'json' = 'csv', dateRange?: DateRange): Promise<string> {
    const data = await this.getAnalyticsData(dateRange);
    
    if (format === 'json') {
      return JSON.stringify(data, null, 2);
    }

    // Convert to CSV format
    let csv = 'Analytics Report\n\n';
    
    // Donations summary
    csv += 'Donation Summary\n';
    csv += 'Total Amount,Total Count,Average Amount\n';
    csv += `${data.donations.totalAmount},${data.donations.totalCount},${data.donations.averageAmount}\n\n`;
    
    // Monthly trend
    csv += 'Monthly Trend\n';
    csv += 'Month,Amount,Count\n';
    data.donations.monthlyTrend.forEach(item => {
      csv += `${item.month},${item.amount},${item.count}\n`;
    });
    
    return csv;
  }
}

export const analyticsService = new AnalyticsService();
export default analyticsService;
