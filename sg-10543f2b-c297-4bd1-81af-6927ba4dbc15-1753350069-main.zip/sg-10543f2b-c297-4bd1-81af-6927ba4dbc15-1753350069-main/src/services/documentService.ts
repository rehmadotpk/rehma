import { supabase } from "@/integrations/supabase/client";
import { Tables } from "@/integrations/supabase/types";

type DocumentRow = Tables<"documents">;

export interface Document {
  id: string;
  entity_type: string;
  entity_id: string;
  document_type: string;
  file_name: string;
  file_path: string;
  file_size: number | null;
  mime_type: string | null;
  uploaded_by: string;
  status: string;
  review_notes: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  uploaded_at: string;
}

export interface DocumentUploadData {
  entity_type: 'child' | 'ngo' | 'doctor' | 'shop_owner';
  entity_id: string;
  document_type: string;
  file: File;
}

export const documentService = {
  async uploadDocument(uploadData: DocumentUploadData): Promise<Document> {
    const { entity_type, entity_id, document_type, file } = uploadData;
    
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) throw new Error('User not authenticated');

    const fileExt = file.name.split('.').pop();
    const fileName = `${entity_id}/${document_type}-${Date.now()}.${fileExt}`;
    const bucketName = 'documents';
    
    const { error: uploadError } = await supabase.storage
      .from(bucketName)
      .upload(`${user.id}/${fileName}`, file);

    if (uploadError) throw uploadError;

    const newDocument = {
      entity_type,
      entity_id,
      document_type,
      file_name: file.name,
      file_path: `${user.id}/${fileName}`,
      file_size: file.size,
      mime_type: file.type,
      uploaded_by: user.id,
    };

    const { data: insertedData, error } = await supabase
      .from('documents')
      .insert(newDocument)
      .select()
      .single();

    if (error) throw error;
    return insertedData as Document;
  },

  async getDocumentsByEntity(entityType: string, entityId: string): Promise<Document[]> {
    const { data, error } = await supabase
      .from('documents')
      .select('*')
      .eq('entity_type', entityType)
      .eq('entity_id', entityId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data as Document[];
  },

  async updateDocumentStatus(documentId: string, status: 'approved' | 'rejected', rejectionReason?: string): Promise<Document> {
    const { data, error } = await supabase
      .from('documents')
      .update({
        status,
        rejection_reason: rejectionReason,
        updated_at: new Date().toISOString()
      })
      .eq('id', documentId)
      .select()
      .single();

    if (error) throw error;
    return data as Document;
  },

  async getPendingDocuments(page = 1, limit = 20): Promise<{ documents: Document[], total: number }> {
    const offset = (page - 1) * limit;
    
    const { data, error, count } = await supabase
      .from('documents')
      .select('*', { count: 'exact' })
      .eq('status', 'pending')
      .range(offset, offset + limit - 1)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return { documents: data as Document[], total: count || 0 };
  },

  async deleteDocument(documentId: string): Promise<void> {
    const { data: document, error: fetchError } = await supabase
      .from('documents')
      .select('file_path')
      .eq('id', documentId)
      .single();

    if (fetchError) throw fetchError;

    if (document?.file_path) {
        await supabase.storage.from('documents').remove([document.file_path]);
    }

    const { error } = await supabase
      .from('documents')
      .delete()
      .eq('id', documentId);

    if (error) throw error;
  }
};

export default documentService;
