import { supabase } from "@/integrations/supabase/client";
import { Tables } from "@/integrations/supabase/types";

export interface Donation {
  id: string;
  donor_id: string | null;
  donor_name: string;
  donor_email: string;
  donor_phone?: string | null;
  child_id: string;
  amount: number;
  currency: string;
  donation_type: "one-time" | "monthly" | "emergency";
  payment_status: "pending" | "completed" | "failed" | "refunded";
  payment_method?: "card" | "bank" | "paypal" | "crypto";
  transaction_id?: string;
  order_id?: string;
  anonymous: boolean;
  message?: string;
  created_at: string;
  updated_at: string;
  child?: {
    name: string;
    image?: string;
    condition?: string;
  };
}

export interface NewDonation {
  child_id: string;
  donor_id: string | null;
  amount: number;
  currency: string;
  donor_name: string;
  donor_email: string;
  donor_phone?: string | null;
  payment_status: "pending" | "completed" | "failed";
  donation_type: "one-time" | "monthly" | "emergency";
  payment_method: "card" | "bank" | "paypal" | "crypto";
  anonymous?: boolean;
  message?: string;
}

export const donationService = {
  async createDonation(donationData: NewDonation): Promise<Donation> {
    const { data, error } = await supabase
      .from("donations")
      .insert(donationData)
      .select(`*, child:children(name, image)`)
      .single();

    if (error) throw error;
    return data as Donation;
  },

  async getDonationById(donationId: string): Promise<Donation> {
    const { data, error } = await supabase
      .from("donations")
      .select(`*, child:children(name, image)`)
      .eq("id", donationId)
      .single();

    if (error) throw error;
    return data as Donation;
  },

  async updateDonation(donationId: string, updates: Partial<Donation>): Promise<Donation> {
    const updatePayload: Partial<Tables<"donations">> = { ...updates };
    delete (updatePayload as any).child; // Remove joined 'child' object before update
    
    const { data, error } = await supabase
      .from("donations")
      .update({ ...updatePayload, updated_at: new Date().toISOString() })
      .eq("id", donationId)
      .select()
      .single();

    if (error) throw error;

    // If payment is completed, update the child's raised amount directly
    if (updates.payment_status === "completed" && data) {
      await this.updateChildRaisedAmount(data.child_id);
    }

    return data as Donation;
  },

  async getUserDonations(userEmail: string, page = 1, limit = 20) {
    if (!userEmail) {
      return { donations: [], total: 0 };
    }
    
    const offset = (page - 1) * limit;
    
    try {
      const { data, error, count } = await supabase
        .from("donations")
        .select(`*, child:children(name, image, condition)`, { count: "exact" })
        .eq("donor_email", userEmail)
        .range(offset, offset + limit - 1)
        .order("created_at", { ascending: false });

      if (error) {
        console.error("Error fetching user donations:", error);
        throw error;
      }
      
      return { donations: data as Donation[] || [], total: count || 0 };
    } catch (error) {
      console.error("Failed to fetch user donations:", error);
      throw error;
    }
  },

  async getChildDonations(childId: string, page = 1, limit = 20) {
    const offset = (page - 1) * limit;
    
    const { data, error, count } = await supabase
      .from("donations")
      .select("*", { count: "exact" })
      .eq("child_id", childId)
      .eq("payment_status", "completed")
      .range(offset, offset + limit - 1)
      .order("created_at", { ascending: false });

    if (error) throw error;
    return { donations: data as Donation[], total: count || 0 };
  },

  async updateChildRaisedAmount(childId: string) {
    const { data: donations, error: donationsError } = await supabase
      .from("donations")
      .select("amount")
      .eq("child_id", childId)
      .eq("payment_status", "completed");

    if (donationsError) throw donationsError;

    const totalRaised = donations?.reduce((sum, donation) => sum + Number(donation.amount), 0) || 0;

    const { error: updateError } = await supabase
      .from("children")
      .update({ raised_amount: totalRaised, updated_at: new Date().toISOString() })
      .eq("id", childId);

    if (updateError) throw updateError;
  },

  async getDonationStats() {
    const { data, error } = await supabase
      .from("donations")
      .select("amount, payment_status, created_at")
      .eq("payment_status", "completed");

    if (error) throw error;

    const totalAmount = data?.reduce((sum, donation) => sum + Number(donation.amount), 0) || 0;
    const totalDonations = data?.length || 0;
    
    const thisMonth = new Date();
    thisMonth.setDate(1);
    const thisMonthDonations = data?.filter(d => new Date(d.created_at) >= thisMonth) || [];
    const thisMonthAmount = thisMonthDonations.reduce((sum, donation) => sum + Number(donation.amount), 0);

    return {
      totalAmount,
      totalDonations,
      thisMonthAmount,
      thisMonthDonations: thisMonthDonations.length
    };
  },

  async getRecentDonations(limit = 10) {
    const { data, error } = await supabase
      .from("donations")
      .select(`*, child:children(name, image)`)
      .eq("payment_status", "completed")
      .order("created_at", { ascending: false })
      .limit(limit);

    if (error) throw error;
    return data as Donation[];
  }
};

export default donationService;
