import { loadStripe } from "@stripe/stripe-js";
import { supabase } from "@/integrations/supabase/client";

const getStripePromise = () => {
  if (!process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY) {
    console.warn("NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY is not set. Stripe functionality will be disabled.");
    return null;
  }
  return loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY);
};

const stripePromise = getStripePromise();

export interface PaymentIntent {
  id: string;
  amount: number;
  currency: string;
  status: string;
  client_secret: string;
}

export interface DonationPayment {
  amount: number;
  currency: string;
  child_id?: string;
  ngo_id?: string;
  donor_email: string;
  donor_name: string;
  message?: string;
  is_anonymous: boolean;
  is_recurring: boolean;
  recurring_frequency?: "monthly" | "quarterly" | "yearly";
}

type DonationRecord = Omit<DonationPayment, "is_recurring" | "recurring_frequency">;

export const paymentService = {
  async createPaymentIntent(donation: DonationPayment): Promise<PaymentIntent> {
    if (!process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY) {
      throw new Error("Stripe is not configured. Please set NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY.");
    }

    const response = await fetch("/api/payments/create-intent", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(donation),
    });

    if (!response.ok) {
      throw new Error("Failed to create payment intent");
    }

    return response.json();
  },

  async confirmPayment(paymentIntentId: string, paymentMethodId: string) {
    const stripe = await stripePromise;
    if (!stripe) throw new Error("Stripe not loaded or not configured");

    return stripe.confirmCardPayment(paymentIntentId, {
      payment_method: paymentMethodId,
    });
  },

  async processRecurringDonation(donation: DonationPayment) {
    if (!process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY) {
      throw new Error("Stripe is not configured. Please set NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY.");
    }

    const response = await fetch("/api/payments/create-subscription", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(donation),
    });

    if (!response.ok) {
      throw new Error("Failed to create subscription");
    }

    return response.json();
  },

  async saveDonationRecord(donation: DonationRecord, paymentIntentId: string) {
    const { data, error } = await supabase
      .from("donations")
      .insert([
        {
          ...donation,
          transaction_id: paymentIntentId,
          payment_status: "completed",
          created_at: new Date().toISOString(),
          donation_type: 'one-time', // Assuming default, this should be passed in.
          payment_method: 'card', // Added missing required field
        },
      ])
      .select();

    if (error) throw error;
    return data[0];
  },

  async getDonationHistory(userId: string) {
    const { data, error } = await supabase
      .from("donations")
      .select(`
        *,
        child:children(name, image),
        ngo:ngos(name, logo_url)
      `)
      .eq("donor_id", userId)
      .order("created_at", { ascending: false });

    if (error) throw error;
    return data;
  },

  async generateReceipt(donationId: string) {
    const response = await fetch(`/api/payments/receipt/${donationId}`, {
      method: "GET",
    });

    if (!response.ok) {
      throw new Error("Failed to generate receipt");
    }

    return response.blob();
  },
};

export default paymentService;
