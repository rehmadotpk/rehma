import { supabase } from "@/integrations/supabase/client";

export const databaseResetService = {
  async clearAllUsers() {
    try {
      // Clear user-related data in the correct order to avoid foreign key constraints
      
      // 1. Clear donations associated with users (using correct column name)
      const { error: donationsError } = await supabase
        .from('donations')
        .delete()
        .not('donor_id', 'is', null);
      
      if (donationsError) {
        console.error('Error clearing donations:', donationsError);
      }

      // 2. Clear audit logs
      const { error: auditError } = await supabase
        .from('audit_logs')
        .delete()
        .not('user_id', 'is', null);
      
      if (auditError) {
        console.error('Error clearing audit logs:', auditError);
      }

      // 3. Clear notification preferences
      const { error: notifPrefError } = await supabase
        .from('notification_preferences')
        .delete()
        .not('user_id', 'is', null);
      
      if (notifPrefError) {
        console.error('Error clearing notification preferences:', notifPrefError);
      }

      // 4. Clear notifications
      const { error: notificationsError } = await supabase
        .from('notifications')
        .delete()
        .not('user_id', 'is', null);
      
      if (notificationsError) {
        console.error('Error clearing notifications:', notificationsError);
      }

      // 5. Clear user roles
      const { error: rolesError } = await supabase
        .from('user_roles')
        .delete()
        .not('user_id', 'is', null);
      
      if (rolesError) {
        console.error('Error clearing user roles:', rolesError);
      }

      // 6. Clear user profiles
      const { error: profilesError } = await supabase
        .from('user_profiles')
        .delete()
        .not('id', 'is', null);
      
      if (profilesError) {
        console.error('Error clearing user profiles:', profilesError);
      }

      return { success: true, message: 'All user data cleared successfully from database tables. Note: Supabase Auth users need to be cleared separately via admin functions.' };
    } catch (error) {
      console.error('Error clearing user data:', error);
      return { success: false, error: error.message };
    }
  },

  async createAdminUser(email: string, password: string, fullName: string) {
    try {
      // Step 1: Create the admin user with signUp
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName,
            role: 'admin'
          }
        }
      });

      if (authError) {
        throw new Error(`Auth error: ${authError.message}`);
      }

      if (!authData.user) {
        throw new Error('User creation failed - no user returned');
      }

      // Step 2: Sign in the user immediately to get proper session
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (signInError) {
        console.warn('Sign in after signup failed:', signInError.message);
        // Continue anyway, the user was created
      }

      // Step 3: Wait a moment for auth state to settle
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Step 4: Create user profile (now that user is authenticated)
      const { error: profileError } = await supabase
        .from('user_profiles')
        .insert({
          id: authData.user.id,
          full_name: fullName,
          email: email,
          role: 'admin',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        });

      if (profileError) {
        console.error('Profile creation error:', profileError);
        throw new Error(`Failed to create user profile: ${profileError.message}`);
      }

      // Step 5: Assign admin role
      const { error: roleError } = await supabase
        .from('user_roles')
        .insert({
          user_id: authData.user.id,
          role: 'admin',
          created_at: new Date().toISOString()
        });

      if (roleError) {
        console.error('Role assignment error:', roleError);
        throw new Error(`Failed to assign admin role: ${roleError.message}`);
      }

      // Step 6: Sign out the user so they can log in normally
      await supabase.auth.signOut();

      return { 
        success: true, 
        message: 'Admin user created successfully! You can now log in with the provided credentials.',
        user: authData.user 
      };
    } catch (error) {
      console.error('Error creating admin user:', error);
      return { success: false, error: error.message };
    }
  }
};

export default databaseResetService;
