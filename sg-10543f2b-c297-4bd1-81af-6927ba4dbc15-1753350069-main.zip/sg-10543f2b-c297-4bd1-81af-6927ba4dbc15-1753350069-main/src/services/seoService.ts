import { supabase } from "@/integrations/supabase/client";

export interface SEOKeyword {
  id: string;
  keyword: string;
  search_volume: number | null;
  difficulty: number | null;
  current_position: number | null;
  previous_position: number | null;
  target_url: string | null;
  is_active: boolean;
  last_checked: string;
  created_at: string;
  updated_at: string;
}

export interface SEORanking {
  id: string;
  keyword_id: string;
  position: number;
  search_volume: number | null;
  checked_at: string;
  created_at: string;
}

export interface SEOReport {
  id: string;
  report_date: string;
  total_keywords: number;
  improved_keywords: number;
  declined_keywords: number;
  average_position: number;
  report_data: Record<string, any> | null;
  sent_at: string | null;
  created_at: string;
}

export interface SEOSettings {
  id: string;
  auto_keyword_research: boolean;
  auto_ranking_check: boolean;
  daily_report_email: string | null;
  report_frequency: string;
  competitor_domains: string[] | null;
  target_keywords_count: number;
  min_search_volume: number;
  max_difficulty: number;
  created_at: string;
  updated_at: string;
}

export async function findKeywordRowSafe(term: string) {
  const { data, error } = await supabase
    .from("seo_keywords")
    .select("*")
    .eq("keyword", term)
    .limit(1);
  if (error) return { row: null, error };
  const row = Array.isArray(data) && data.length > 0 ? data[0] : null;
  return { row, error: null as unknown as null };
}

export const seoService = {
  // Keyword Management
  async getAllKeywords(): Promise<SEOKeyword[]> {
    const { data, error } = await supabase
      .from("seo_keywords")
      .select("*")
      .order("current_position", { ascending: true, nullsFirst: false });

    if (error) throw error;
    return data || [];
  },

  async checkKeywordExists(keyword: string): Promise<boolean> {
    const { data, error } = await supabase
      .from("seo_keywords")
      .select("id")
      .eq("keyword", keyword.toLowerCase().trim())
      .limit(1)
      .maybeSingle();

    if (error) {
      console.error("Error checking keyword existence:", error);
      return false;
    }

    return !!data;
  },

  async addKeyword(keywordData: Omit<SEOKeyword, 'id'|'created_at'|'updated_at'|'last_checked'>): Promise<SEOKeyword> {
    // Normalize keyword
    const normalizedKeyword = keywordData.keyword.toLowerCase().trim();
    
    // Check for duplicates first
    const exists = await this.checkKeywordExists(normalizedKeyword);
    if (exists) {
      throw new Error(`DUPLICATE_KEYWORD: The keyword "${normalizedKeyword}" already exists in your tracking list.`);
    }

    const { data, error } = await supabase
      .from("seo_keywords")
      .insert([{
        ...keywordData, 
        keyword: normalizedKeyword,
        last_checked: new Date().toISOString()
      }])
      .select()
      .single();

    if (error) {
      if (error.code === '23505') { // PostgreSQL unique constraint violation
        throw new Error(`DUPLICATE_KEYWORD: The keyword "${normalizedKeyword}" already exists in your tracking list.`);
      }
      throw error;
    }
    return data;
  },

  async updateKeyword(id: string, updates: Partial<SEOKeyword>): Promise<SEOKeyword> {
    const { data, error } = await supabase
      .from("seo_keywords")
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq("id", id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async deleteKeyword(id: string): Promise<void> {
    const { error } = await supabase
      .from("seo_keywords")
      .delete()
      .eq("id", id);

    if (error) throw error;
  },

  // Ranking Tracking
  async getKeywordRankings(keywordId: string): Promise<SEORanking[]> {
    const { data, error } = await supabase
      .from("seo_rankings")
      .select("*")
      .eq("keyword_id", keywordId)
      .order("checked_at", { ascending: false })
      .limit(30);

    if (error) throw error;
    return data || [];
  },

  async recordRanking(keywordId: string, position: number, searchVolume: number | null): Promise<SEORanking> {
    const { data, error } = await supabase
      .from("seo_rankings")
      .insert([
        {
          keyword_id: keywordId,
          position,
          search_volume: searchVolume,
          checked_at: new Date().toISOString(),
        },
      ])
      .select()
      .single();

    if (error) throw error;

    // Update the keyword's current position
    await this.updateKeyword(keywordId, {
      previous_position: (await supabase.from("seo_keywords").select("current_position").eq("id", keywordId).single()).data?.current_position,
      current_position: position,
      last_checked: new Date().toISOString(),
    });

    return data;
  },

  // Reports
  async getReports(limit: number = 30): Promise<SEOReport[]> {
    const { data, error } = await supabase
      .from("seo_reports")
      .select("*")
      .order("report_date", { ascending: false })
      .limit(limit);

    if (error) throw error;
    return (data as any[]) || [];
  },

  async createReport(reportData: Partial<Omit<SEOReport, 'id' | 'created_at'>>): Promise<SEOReport> {
    const { data, error } = await supabase
      .from("seo_reports")
      .insert([{...reportData, report_date: new Date().toISOString()}])
      .select()
      .single();

    if (error) throw error;
    return data as SEOReport;
  },

  // Settings
  async getSettings(): Promise<SEOSettings | null> {
    const { data, error } = await supabase
      .from("seo_settings")
      .select("*")
      .limit(1)
      .maybeSingle();

    if (error) throw error;
    return data;
  },

  async updateSettings(updates: Partial<SEOSettings>): Promise<SEOSettings> {
    const settings = await this.getSettings();

    if (!settings) {
      const { data, error } = await supabase
        .from("seo_settings")
        .insert([{ ...updates }])
        .select()
        .single();

      if (error) throw error;
      return data;
    }

    const { data, error } = await supabase
      .from("seo_settings")
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq("id", settings.id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  // Automated Functions (would be called by Edge Functions/Cron)
  async performKeywordResearch(): Promise<string[]> {
    const settings = await this.getSettings();
    if (!settings || !settings.auto_keyword_research) {
      return [];
    }

    // In production, this would use APIs like SEMrush, Ahrefs, or Google Keyword Planner
    // For now, we'll simulate keyword discovery
    const suggestedKeywords = [
      "child sponsorship programs",
      "donate to children in need",
      "support underprivileged children",
      "charity for children education",
      "help children in poverty",
    ];

    // Filter based on settings
    const filteredKeywords: string[] = [];
    for (const keyword of suggestedKeywords) {
      const { data: existingKeyword, error } = await supabase
        .from("seo_keywords")
        .select("id")
        .eq("keyword", keyword)
        .limit(1) // Ensure at most one row is returned
        .maybeSingle();

      if (error) {
        // Log the error but continue, so one failure doesn't stop the whole process
        console.error(`Error checking for keyword '${keyword}':`, error);
        continue;
      }
      
      if (!existingKeyword) {
        filteredKeywords.push(keyword);
      }
    }

    const allKeywords = await this.getAllKeywords();
    const availableSlots = settings.target_keywords_count - allKeywords.length;
    
    return filteredKeywords.slice(0, Math.max(0, availableSlots));
  },

  async checkAllRankings(): Promise<{ success: number; failed: number }> {
    const keywords = await this.getAllKeywords();
    const settings = await this.getSettings();

    if (!settings || !settings.auto_ranking_check) {
      return { success: 0, failed: 0 };
    }

    let success = 0;
    let failed = 0;

    for (const keyword of keywords.filter(k => k.is_active)) {
      try {
        // In production, this would use real SEO APIs
        const simulatedPosition = Math.floor(Math.random() * 100) + 1;
        await this.recordRanking(keyword.id, simulatedPosition, keyword.search_volume);
        success++;
      } catch (error) {
        console.error(`Failed to check ranking for ${keyword.keyword}:`, error);
        failed++;
      }
    }

    return { success, failed };
  },

  async generateDailyReport(): Promise<SEOReport> {
    const keywords = await this.getAllKeywords();
    const today = new Date().toISOString().split("T")[0];

    let improved = 0;
    let declined = 0;
    let totalPosition = 0;
    let positionCount = 0;

    keywords.forEach((keyword) => {
      if (keyword.current_position && keyword.previous_position) {
        if (keyword.current_position < keyword.previous_position) improved++;
        if (keyword.current_position > keyword.previous_position) declined++;
        totalPosition += keyword.current_position;
        positionCount++;
      }
    });

    const reportData = {
      report_date: today,
      total_keywords: keywords.length,
      improved_keywords: improved,
      declined_keywords: declined,
      average_position: positionCount > 0 ? totalPosition / positionCount : 0,
      report_data: {
        top_keywords: keywords
          .filter(k => k.current_position && k.current_position <= 10)
          .map(k => ({ keyword: k.keyword, position: k.current_position })),
        biggest_improvements: keywords
          .filter(k => k.current_position && k.previous_position && k.previous_position - k.current_position > 0)
          .sort((a, b) => ((b.previous_position || 0) - (b.current_position || 0)) - ((a.previous_position || 0) - (a.current_position || 0)))
          .slice(0, 5)
          .map(k => ({ keyword: k.keyword, improvement: (k.previous_position || 0) - (k.current_position || 0) })),
      },
    };

    return await this.createReport(reportData);
  },
};
