import { supabase } from "@/integrations/supabase/client";
import { Tables } from "@/integrations/supabase/types";

type ChildRow = Tables<"children">;

export interface Child {
  id: string;
  name: string;
  age: number;
  condition: string;
  story: string;
  image: string | null;
  target_amount: number;
  raised_amount: number;
  monthly_needs: number;
  status: string;
  urgency: string;
  location: string;
  guardian: string;
  guardian_contact: string;
  urgent_need: string | null;
  created_at: string;
  updated_at: string;
  verified: boolean;
  approval_status: string;
  approved_by: string | null;
  approved_at: string | null;
  created_by: string;
}

interface ChildrenFilters {
  status?: string;
  urgency?: string;
  searchTerm?: string;
  sortBy?: string;
  search?: string;
}

class ChildrenService {
  // Get all children with pagination and filtering
  async getAllChildren(page = 1, limit = 10, filters: ChildrenFilters = {}): Promise<{
    children: Child[];
    total: number;
  }> {
    try {
      const offset = (page - 1) * limit;
      let query = supabase.from('children').select('*', { count: 'exact' });

      // Only show active and approved children for public access
      query = query.eq('approval_status', 'approved');

      if (filters.status) {
        query = query.eq('status', filters.status);
      }
      // Fix: Only apply urgency filter if it's not 'all'
      if (filters.urgency && filters.urgency !== 'all') {
        query = query.eq('urgency', filters.urgency);
      }
      if (filters.search) {
        query = query.or(`name.ilike.%${filters.search}%,condition.ilike.%${filters.search}%,location.ilike.%${filters.search}%`);
      }

      if (filters.sortBy === 'urgent') {
        query = query.order('urgency', { ascending: false });
      } else {
        query = query.order('created_at', { ascending: false });
      }

      query = query.range(offset, offset + limit - 1);

      const { data, error, count } = await query;

      if (error) {
        console.error("Error fetching children:", error);
        // Return empty result instead of throwing on RLS errors
        if (error.code === 'PGRST301' || error.message.includes('relation') || error.message.includes('does not exist')) {
          console.warn("Database access issue - returning empty results");
          return { children: [], total: 0 };
        }
        throw error;
      }
      
      return { children: data || [], total: count || 0 };
    } catch (error) {
      console.error("Unexpected error in getAllChildren:", error);
      // Return empty results as fallback
      return { children: [], total: 0 };
    }
  }

  // Get a single child by ID
  async getChildById(id: string): Promise<Child | null> {
    const { data, error } = await supabase
      .from('children')
      .select('*')
      .eq('id', id)
      .single();

    if (error && error.code !== 'PGRST116') { // Ignore "No rows found" error
        throw error;
    }
    return data;
  }

  // Create a new child profile
  async createChild(childData: Pick<Child, 'name' | 'age' | 'condition' | 'story' | 'target_amount' | 'monthly_needs' | 'location' | 'guardian' | 'guardian_contact'> & Partial<Pick<Child, 'image' | 'urgent_need'>>): Promise<Child> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');
    
    const { data, error } = await supabase
      .from('children')
      .insert([
        { 
          ...childData,
          raised_amount: 0,
          status: 'pending',
          urgency: 'medium',
          verified: false,
          approval_status: 'pending',
          created_by: user.id,
        }
      ])
      .select()
      .single();
    
    if (error) throw error;
    return data as Child;
  }

  // Update a child profile by ID
  async updateChildById(id: string, updates: Partial<Child>): Promise<Child | null> {
    const { data, error } = await supabase
      .from('children')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  // Delete a child by ID
  async deleteChildById(id: string): Promise<void> {
    const { error } = await supabase.from('children').delete().eq('id', id);
    if (error) throw error;
  }

  // Search and filter children
  async searchAndFilterChildren(filters: {
    searchTerm?: string;
    status?: string;
    urgency?: string;
    sortBy?: string;
  }): Promise<Child[]> {
    let query = supabase.from("children").select('*');

    if (filters.searchTerm) {
      query = query.or(`name.ilike.%${filters.searchTerm}%,condition.ilike.%${filters.searchTerm}%`);
    }

    if (filters.status) {
      query = query.eq("status", filters.status);
    }

    if (filters.urgency) {
      query = query.eq("urgency", filters.urgency);
    }

    if (filters.sortBy) {
      query = query.order(filters.sortBy as string);
    }

    const { data, error } = await query;

    if (error) throw error;
    return data || [];
  }
}

export const childrenService = new ChildrenService();