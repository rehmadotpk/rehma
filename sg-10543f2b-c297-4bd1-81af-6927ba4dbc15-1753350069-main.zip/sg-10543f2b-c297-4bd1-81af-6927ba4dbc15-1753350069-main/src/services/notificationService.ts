import { supabase } from "@/integrations/supabase/client";

export interface Notification {
  id: string;
  user_id: string;
  title: string;
  message: string;
  type: 'donation' | 'child_update' | 'system' | 'achievement';
  read: boolean;
  data?: Record<string, unknown>;
  created_at: string;
}

export interface NotificationPreferences {
  user_id: string;
  email_notifications: boolean;
  push_notifications: boolean;
  sms_notifications: boolean;
  email_donations: boolean;
  email_updates: boolean;
  push_donations: boolean;
  push_updates: boolean;
  sms_critical: boolean;
  newsletter: boolean;
  child_updates: boolean;
  donation_updates: boolean;
  created_at: string;
  updated_at: string;
}

class NotificationService {
  // Create notification
  async createNotification(notification: Omit<Notification, 'id' | 'created_at'>): Promise<Notification> {
    const { data, error } = await supabase
      .from('notifications')
      .insert([notification])
      .select()
      .single();

    if (error) throw error;
    return data as Notification;
  }

  // Get user notifications
  async getUserNotifications(userId: string, page = 1, limit = 20): Promise<{
    notifications: Notification[];
    total: number;
    unreadCount: number;
  }> {
    const offset = (page - 1) * limit;

    // Get notifications
    const { data: notifications, error } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) throw error;

    // Get total count
    const { count: total } = await supabase
      .from('notifications')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', userId);

    // Get unread count
    const { count: unreadCount } = await supabase
      .from('notifications')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', userId)
      .eq('read', false);

    return {
      notifications: (notifications as Notification[]) || [],
      total: total || 0,
      unreadCount: unreadCount || 0
    };
  }

  // Mark notification as read
  async markAsRead(notificationId: string): Promise<void> {
    const { error } = await supabase
      .from('notifications')
      .update({ read: true })
      .eq('id', notificationId);

    if (error) throw error;
  }

  // Mark all notifications as read
  async markAllAsRead(userId: string): Promise<void> {
    const { error } = await supabase
      .from('notifications')
      .update({ read: true })
      .eq('user_id', userId)
      .eq('read', false);

    if (error) throw error;
  }

  // Delete notification
  async deleteNotification(notificationId: string): Promise<void> {
    const { error } = await supabase
      .from('notifications')
      .delete()
      .eq('id', notificationId);

    if (error) throw error;
  }

  // Send donation notification
  async sendDonationNotification(donorId: string, childId: string, amount: number, childName: string): Promise<void> {
    // Notify donor
    await this.createNotification({
      user_id: donorId,
      title: 'Donation Confirmed',
      message: `Your donation of PKR ${amount.toLocaleString()} to ${childName} has been processed successfully.`,
      type: 'donation',
      read: false,
      data: { childId, amount }
    });

    // There is no guardian_id on children table, so this part is removed.
    // We can notify based on another relation if needed, but for now, this logic is faulty.
  }

  // Send child update notification
  async sendChildUpdateNotification(childId: string, updateMessage: string): Promise<void> {
    // Get all donors for this child
    const { data: donations } = await supabase
      .from('donations')
      .select('donor_id')
      .eq('child_id', childId)
      .eq('payment_status', 'completed');

    if (donations) {
      const uniqueDonors = [...new Set(donations.map(d => d.donor_id))];
      
      for (const donorId of uniqueDonors) {
        await this.createNotification({
          user_id: donorId,
          title: 'Child Update',
          message: updateMessage,
          type: 'child_update',
          read: false,
          data: { childId }
        });
      }
    }
  }

  // Get notification preferences
  async getNotificationPreferences(userId: string): Promise<NotificationPreferences> {
    const { data, error } = await supabase
      .from('notification_preferences')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (error && error.code !== 'PGRST116') throw error;
    
    // Casting to unknown first to bypass compiler error about insufficient overlap
    if (data) return data as unknown as NotificationPreferences;

    // Return a default object if no preferences are found
    return {
      user_id: userId,
      email_notifications: true,
      push_notifications: true,
      sms_notifications: false,
      email_donations: true,
      email_updates: true,
      push_donations: true,
      push_updates: true,
      sms_critical: false,
      newsletter: true,
      child_updates: true,
      donation_updates: true,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
  }

  // Update notification preferences
  async updateNotificationPreferences(userId: string, preferences: Partial<NotificationPreferences>): Promise<void> {
    const { error } = await supabase
      .from('notification_preferences')
      .upsert({ user_id: userId, ...preferences });

    if (error) throw error;
  }

  // Subscribe to real-time notifications
  subscribeToNotifications(userId: string, callback: (notification: Notification) => void) {
    return supabase
      .channel('notifications')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'notifications',
          filter: `user_id=eq.${userId}`
        },
        (payload) => {
          callback(payload.new as Notification);
        }
      )
      .subscribe();
  }

  // Request browser notification permission
  async requestNotificationPermission(): Promise<boolean> {
    if (!('Notification' in window)) {
      return false;
    }

    if (Notification.permission === 'granted') {
      return true;
    }

    if (Notification.permission !== 'denied') {
      const permission = await Notification.requestPermission();
      return permission === 'granted';
    }

    return false;
  }

  // Show browser notification
  showBrowserNotification(title: string, message: string, icon?: string): void {
    if (Notification.permission === 'granted') {
      new Notification(title, {
        body: message,
        icon: icon || '/favicon.ico',
        badge: '/favicon.ico'
      });
    }
  }
}

export const notificationService = new NotificationService();
export default notificationService;
