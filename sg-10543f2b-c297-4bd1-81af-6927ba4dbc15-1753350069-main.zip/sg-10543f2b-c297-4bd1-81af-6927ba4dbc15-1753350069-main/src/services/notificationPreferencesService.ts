import { supabase } from "@/integrations/supabase/client";

export interface NotificationPreferences {
  id: string;
  user_id: string;
  email_notifications: boolean;
  push_notifications: boolean;
  sms_notifications: boolean;
  donation_updates: boolean;
  child_updates: boolean;
  newsletter: boolean;
  created_at: string;
  updated_at: string;
}

export const notificationPreferencesService = {
  async getPreferences(userId: string) {
    try {
      // Use limit(1) to prevent multiple rows issue and get consistent results
      const { data, error } = await supabase
        .from('notification_preferences')
        .select('*')
        .eq('user_id', userId)
        .limit(1);

      if (error) {
        console.error('Error fetching notification preferences:', error);
        // Return default preferences if there's an error
        return this.getDefaultPreferences();
      }

      // Check if we got results
      if (!data || data.length === 0) {
        console.log('No notification preferences found, creating default ones...');
        // Create default preferences for the user
        return await this.createDefaultPreferences(userId);
      }

      return data[0];
    } catch (error) {
      console.error('Service error fetching notification preferences:', error);
      return this.getDefaultPreferences();
    }
  },

  async createDefaultPreferences(userId: string) {
    try {
      // First check if preferences already exist to prevent duplicates
      const { data: existing } = await supabase
        .from('notification_preferences')
        .select('id')
        .eq('user_id', userId)
        .limit(1);

      if (existing && existing.length > 0) {
        // Preferences already exist, fetch and return them
        return await this.getPreferences(userId);
      }

      const defaultPrefs = {
        user_id: userId,
        email_notifications: true,
        push_notifications: true,
        sms_notifications: false,
        donation_updates: true,
        child_updates: true,
        newsletter: true
      };

      const { data, error } = await supabase
        .from("notification_preferences")
        .insert([defaultPrefs])
        .select()
        .limit(1);

      if (error) {
        console.error("Error creating default notification preferences:", error);
        return this.getDefaultPreferences();
      }

      if (!data || data.length === 0) {
        console.error("Failed to create or retrieve default preferences after insert.");
        return this.getDefaultPreferences();
      }

      return data[0];
    } catch (error) {
      console.error("Service error creating default notification preferences:", error);
      return this.getDefaultPreferences();
    }
  },

  getDefaultPreferences() {
    return {
      id: 'default',
      user_id: '',
      email_notifications: true,
      push_notifications: true,
      sms_notifications: false,
      donation_updates: true,
      child_updates: true,
      newsletter: true,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
  },

  async updatePreferences(userId: string, preferences: Partial<NotificationPreferences>) {
    try {
      const { data, error } = await supabase
        .from('notification_preferences')
        .update({
          ...preferences,
          updated_at: new Date().toISOString()
        })
        .eq('user_id', userId)
        .select()
        .limit(1);

      if (error) {
        console.error('Error updating notification preferences:', error);
        throw error;
      }

      // Check if we got results
      if (!data || data.length === 0) {
        console.log('No preferences found to update, creating new ones...');
        return await this.createDefaultPreferences(userId);
      }

      return data[0];
    } catch (error) {
      console.error('Service error updating notification preferences:', error);
      throw error;
    }
  }
};

export default notificationPreferencesService;
