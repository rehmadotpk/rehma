import { supabase } from "@/integrations/supabase/client";

export interface SystemSettings {
  id: string;
  setting_key: string;
  setting_value: string;
  setting_type: 'string' | 'number' | 'boolean' | 'json';
  description: string;
  category: string;
  updated_at: string;
  updated_by: string;
}

export interface SystemConfig {
  // Platform Settings
  platformName: string;
  platformDescription: string;
  supportEmail: string;
  maintenanceMode: boolean;
  
  // Donation Settings
  minDonationAmount: number;
  maxDonationAmount: number;
  defaultCurrency: string;
  enableRecurringDonations: boolean;
  
  // Email Settings
  emailFromName: string;
  emailFromAddress: string;
  enableEmailNotifications: boolean;
  
  // Security Settings
  requireEmailVerification: boolean;
  passwordMinLength: number;
  enableTwoFactorAuth: boolean;
  sessionTimeout: number;
  
  // Content Settings
  enableUserRegistration: boolean;
  moderateComments: boolean;
  enablePublicProfiles: boolean;
  
  // Payment Settings
  enableStripe: boolean;
  enablePayPal: boolean;
  enableBankTransfer: boolean;
  processingFeePercentage: number;
}

export const systemSettingsService = {
  // Get all system settings
  async getAllSettings(): Promise<SystemSettings[]> {
    try {
      const { data, error } = await supabase
        .from('system_settings')
        .select('*')
        .order('category', { ascending: true });

      if (error) throw error;
      return (data as any[]) || [];
    } catch (error) {
      console.error('Error fetching system settings:', error);
      throw error;
    }
  },

  // Get settings by category
  async getSettingsByCategory(category: string): Promise<SystemSettings[]> {
    try {
      const { data, error } = await supabase
        .from('system_settings')
        .select('*')
        .eq('category', category)
        .order('setting_key', { ascending: true });

      if (error) throw error;
      return (data as any[]) || [];
    } catch (error) {
      console.error(`Error fetching settings for category ${category}:`, error);
      throw error;
    }
  },

  // Get a specific setting
  async getSetting(key: string): Promise<SystemSettings | null> {
    try {
      const { data, error } = await supabase
        .from('system_settings')
        .select('*')
        .eq('setting_key', key)
        .single();

      if (error) {
        if (error.code === 'PGRST116') return null; // Not found
        throw error;
      }
      return data as any;
    } catch (error) {
      console.error(`Error fetching setting ${key}:`, error);
      return null;
    }
  },

  // Update a setting
  async updateSetting(key: string, value: string, updatedBy: string): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('system_settings')
        .update({
          setting_value: value,
          updated_at: new Date().toISOString(),
          updated_by: updatedBy
        })
        .eq('setting_key', key);

      if (error) throw error;
      return true;
    } catch (error) {
      console.error(`Error updating setting ${key}:`, error);
      throw error;
    }
  },

  // Create a new setting
  async createSetting(setting: Omit<SystemSettings, 'id' | 'updated_at'>): Promise<SystemSettings | null> {
    try {
      const { data, error } = await supabase
        .from('system_settings')
        .insert({
          ...setting,
          updated_at: new Date().toISOString()
        })
        .select()
        .single();

      if (error) throw error;
      return data as any;
    } catch (error) {
      console.error('Error creating setting:', error);
      throw error;
    }
  },

  // Get system configuration as a structured object
  async getSystemConfig(): Promise<Partial<SystemConfig>> {
    try {
      const settings = await this.getAllSettings();
      const config: Partial<SystemConfig> = {};

      settings.forEach(setting => {
        const key = setting.setting_key as keyof SystemConfig;
        let parsedValue: string | number | boolean | object;

        // Parse value based on type
        switch (setting.setting_type) {
          case "boolean":
            parsedValue = setting.setting_value === "true";
            break;
          case "number":
            parsedValue = parseFloat(setting.setting_value);
            break;
          case "json":
            try {
              parsedValue = JSON.parse(setting.setting_value);
            } catch {
              parsedValue = setting.setting_value;
            }
            break;
          default:
            parsedValue = setting.setting_value;
        }

        (config as Record<string, unknown>)[key] = parsedValue;
      });

      return config;
    } catch (error) {
      console.error("Error getting system config:", error);
      throw error;
    }
  },

  // Initialize default settings
  async initializeDefaultSettings(adminId: string): Promise<boolean> {
    try {
      const defaultSettings: Omit<SystemSettings, 'id' | 'updated_at'>[] = [
        // Platform Settings
        {
          setting_key: 'platformName',
          setting_value: 'Rehma',
          setting_type: 'string',
          description: 'Name of the platform',
          category: 'platform',
          updated_by: adminId
        },
        {
          setting_key: 'platformDescription',
          setting_value: 'A platform for helping children in need',
          setting_type: 'string',
          description: 'Platform description',
          category: 'platform',
          updated_by: adminId
        },
        {
          setting_key: 'supportEmail',
          setting_value: 'support@rehma.org',
          setting_type: 'string',
          description: 'Support email address',
          category: 'platform',
          updated_by: adminId
        },
        {
          setting_key: 'maintenanceMode',
          setting_value: 'false',
          setting_type: 'boolean',
          description: 'Enable maintenance mode',
          category: 'platform',
          updated_by: adminId
        },
        
        // Donation Settings
        {
          setting_key: 'minDonationAmount',
          setting_value: '5',
          setting_type: 'number',
          description: 'Minimum donation amount',
          category: 'donations',
          updated_by: adminId
        },
        {
          setting_key: 'maxDonationAmount',
          setting_value: '10000',
          setting_type: 'number',
          description: 'Maximum donation amount',
          category: 'donations',
          updated_by: adminId
        },
        {
          setting_key: 'defaultCurrency',
          setting_value: 'USD',
          setting_type: 'string',
          description: 'Default currency for donations',
          category: 'donations',
          updated_by: adminId
        },
        {
          setting_key: 'enableRecurringDonations',
          setting_value: 'true',
          setting_type: 'boolean',
          description: 'Allow recurring donations',
          category: 'donations',
          updated_by: adminId
        },
        
        // Security Settings
        {
          setting_key: 'requireEmailVerification',
          setting_value: 'true',
          setting_type: 'boolean',
          description: 'Require email verification for new accounts',
          category: 'security',
          updated_by: adminId
        },
        {
          setting_key: 'passwordMinLength',
          setting_value: '8',
          setting_type: 'number',
          description: 'Minimum password length',
          category: 'security',
          updated_by: adminId
        },
        {
          setting_key: 'sessionTimeout',
          setting_value: '24',
          setting_type: 'number',
          description: 'Session timeout in hours',
          category: 'security',
          updated_by: adminId
        },
        
        // Payment Settings
        {
          setting_key: 'enableStripe',
          setting_value: 'true',
          setting_type: 'boolean',
          description: 'Enable Stripe payments',
          category: 'payments',
          updated_by: adminId
        },
        {
          setting_key: 'enablePayPal',
          setting_value: 'true',
          setting_type: 'boolean',
          description: 'Enable PayPal payments',
          category: 'payments',
          updated_by: adminId
        },
        {
          setting_key: 'processingFeePercentage',
          setting_value: '2.9',
          setting_type: 'number',
          description: 'Payment processing fee percentage',
          category: 'payments',
          updated_by: adminId
        }
      ];

      // Insert all default settings
      const { error } = await supabase
        .from('system_settings')
        .insert(defaultSettings.map(setting => ({
          ...setting,
          updated_at: new Date().toISOString()
        })));

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error initializing default settings:', error);
      throw error;
    }
  },

  // Check if settings table exists and has data
  async checkSettingsExist(): Promise<boolean> {
    try {
      const { count, error } = await supabase
        .from('system_settings')
        .select('*', { count: 'exact', head: true });

      if (error) {
        // Table might not exist
        return false;
      }
      
      return (count || 0) > 0;
    } catch (error) {
      console.error('Error checking settings existence:', error);
      return false;
    }
  }
};

export default systemSettingsService;
