import { supabase } from "@/integrations/supabase/client";

export interface Doctor {
  id: string;
  name: string;
  specialization: string;
  qualification: string;
  experience_years: number;
  location: string;
  is_available: boolean;
  verified: boolean;
  avatar_url?: string;
  email?: string;
  phone?: string;
}

export interface CreateDoctorRequest {
  name: string;
  specialization: string;
  qualification: string;
  experience_years: number;
  location: string;
  is_available: boolean;
  verified: boolean;
  avatar_url?: string;
  email?: string;
  phone?: string;
}

export const doctorService = {
  async getAllDoctors(page = 1, limit = 20, filters?: {
    verified?: boolean;
    specialization?: string;
    location?: string;
    search?: string;
  }) {
    try {
      let query = supabase
        .from('doctors')
        .select('*');
      
      if (filters?.verified !== undefined) {
        query = query.eq('verified', filters.verified);
      }

      if (filters?.specialization) {
        query = query.ilike('specialization', `%${filters.specialization}%`);
      }

      if (filters?.location) {
        query = query.ilike('location', `%${filters.location}%`);
      }

      if (filters?.search) {
        const searchTerm = filters.search.toLowerCase();
        query = query.or(`name.ilike.%${searchTerm}%,specialization.ilike.%${searchTerm}%,location.ilike.%${searchTerm}%`);
      }

      // Apply pagination
      const offset = (page - 1) * limit;
      query = query.range(offset, offset + limit - 1);
      
      const { data, error, count } = await query;
      
      if (error) {
        console.error('Doctor Service getAllDoctors Error:', error);
        return { doctors: [], total: 0 };
      }
      
      // Add compatibility fields
      const doctorsWithCompat = (data || []).map(doctor => ({
        ...doctor,
        full_name: doctor.name,
        avatar_url: `https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=150&h=150&fit=crop&crop=face`
      }));
      
      return { doctors: doctorsWithCompat, total: count || 0 };
    } catch (error) {
      console.error('Doctor Service getAllDoctors Error:', error);
      return { doctors: [], total: 0 };
    }
  },

  async getVerifiedDoctors(filters: {
    search?: string;
    specialization?: string;
    limit?: number;
  } = {}) {
    try {
      const limit = filters.limit || 10;
      let query = supabase
        .from('doctors')
        .select('*')
        .eq('verified', true)
        .eq('is_available', true);

      if (filters.search) {
        const searchTerm = filters.search.toLowerCase();
        query = query.or(`name.ilike.%${searchTerm}%,specialization.ilike.%${searchTerm}%`);
      }

      if (filters.specialization) {
        query = query.ilike('specialization', `%${filters.specialization}%`);
      }

      query = query.limit(limit);
      
      const { data, error } = await query;
      
      if (error) {
        console.error('Doctor Service getVerifiedDoctors Error:', error);
        return [];
      }
      
      // Add compatibility fields
      const doctorsWithCompat = (data || []).map(doctor => ({
        ...doctor,
        full_name: doctor.name,
        avatar_url: `https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=150&h=150&fit=crop&crop=face`
      }));
      
      return doctorsWithCompat;
    } catch (error) {
      console.error('Doctor Service getVerifiedDoctors Error:', error);
      return [];
    }
  },

  async getDoctorById(id: string) {
    try {
      const { data: doctor, error } = await supabase
        .from('doctors')
        .select('*')
        .eq('id', id)
        .single();

      if (error) {
        console.error('Doctor Service getDoctorById Error:', error);
        throw error;
      }

      // Add compatibility fields
      return {
        ...doctor,
        full_name: doctor.name,
        avatar_url: `https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=150&h=150&fit=crop&crop=face`
      } as Doctor;
    } catch (error) {
      console.error('Doctor Service getDoctorById Error:', error);
      throw error;
    }
  },

  async createDoctorProfile(userId: string, doctorData: CreateDoctorRequest) {
    try {
      const { data, error } = await supabase
        .from('doctors')
        .insert([
          {
            profile_id: userId,
            ...doctorData,
            verified: false,
            is_available: true
          }
        ])
        .select();

      if (error) {
        console.error('Doctor Service createDoctorProfile Error:', error);
        throw error;
      }
      
      const doctor = data[0];
      return {
        ...doctor,
        full_name: doctor.name,
        avatar_url: `https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=150&h=150&fit=crop&crop=face`
      } as Doctor;
    } catch (error) {
      console.error('Doctor Service createDoctorProfile Error:', error);
      throw error;
    }
  },

  async updateDoctorProfile(id: string, updates: Partial<Doctor>) {
    try {
      const { data, error } = await supabase
        .from('doctors')
        .update({
          ...updates,
          updated_at: new Date().toISOString()
        })
        .eq('id', id)
        .select();

      if (error) {
        console.error('Doctor Service updateDoctorProfile Error:', error);
        throw error;
      }
      
      const doctor = data[0];
      return {
        ...doctor,
        full_name: doctor.name,
        avatar_url: `https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=150&h=150&fit=crop&crop=face`
      } as Doctor;
    } catch (error) {
      console.error('Doctor Service updateDoctorProfile Error:', error);
      throw error;
    }
  },

  async verifyDoctor(id: string, verified: boolean) {
    try {
      const { data, error } = await supabase
        .from('doctors')
        .update({ 
          verified,
          updated_at: new Date().toISOString()
        })
        .eq('id', id)
        .select();

      if (error) {
        console.error('Doctor Service verifyDoctor Error:', error);
        throw error;
      }
      
      const doctor = data[0];
      return {
        ...doctor,
        full_name: doctor.name,
        avatar_url: `https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=150&h=150&fit=crop&crop=face`
      } as Doctor;
    } catch (error) {
      console.error('Doctor Service verifyDoctor Error:', error);
      throw error;
    }
  },

  async searchDoctors(query: string, limit = 20) {
    try {
      const { data: doctors, error } = await supabase
        .from('doctors')
        .select('*')
        .eq('verified', true)
        .eq('is_available', true)
        .or(`name.ilike.%${query}%,specialization.ilike.%${query}%,location.ilike.%${query}%`)
        .order('created_at', { ascending: false })
        .limit(limit);

      if (error) {
        console.error('Doctor Service searchDoctors Error:', error);
        throw error;
      }

      // Add compatibility fields
      const doctorsWithCompat = (doctors || []).map(doctor => ({
        ...doctor,
        full_name: doctor.name,
        avatar_url: `https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=150&h=150&fit=crop&crop=face`
      }));

      return doctorsWithCompat as Doctor[];
    } catch (error) {
      console.error('Doctor Service searchDoctors Error:', error);
      throw error;
    }
  }
};

export default doctorService;
