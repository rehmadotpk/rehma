
import { supabase } from "@/integrations/supabase/client";

export interface PaymentGateway {
  id: string;
  gateway_name: string;
  is_enabled: boolean;
  is_test_mode: boolean;
  api_key: string | null;
  api_secret: string | null;
  webhook_secret: string | null;
  config: Record<string, any>;
  created_at: string;
  updated_at: string;
  updated_by: string | null;
}

export const paymentGatewayService = {
  async getAllGateways(): Promise<PaymentGateway[]> {
    const { data, error } = await supabase
      .from("payment_gateways")
      .select("*")
      .order("gateway_name");

    if (error) throw error;
    return (data as any[]) || [];
  },

  async getGateway(gatewayName: string): Promise<PaymentGateway | null> {
    const { data, error } = await supabase
      .from("payment_gateways")
      .select("*")
      .eq("gateway_name", gatewayName)
      .single();

    if (error && error.code !== 'PGRST116') throw error;
    return data as any;
  },

  async updateGateway(
    gatewayName: string,
    updates: Partial<PaymentGateway>,
    userId: string
  ): Promise<PaymentGateway> {
    const { data, error } = await supabase
      .from("payment_gateways")
      .update({
        ...updates,
        updated_at: new Date().toISOString(),
        updated_by: userId,
      })
      .eq("gateway_name", gatewayName)
      .select()
      .single();

    if (error) throw error;
    return data as any;
  },

  async toggleGateway(
    gatewayName: string,
    isEnabled: boolean,
    userId: string
  ): Promise<PaymentGateway> {
    return this.updateGateway(gatewayName, { is_enabled: isEnabled }, userId);
  },

  async toggleTestMode(
    gatewayName: string,
    isTestMode: boolean,
    userId: string
  ): Promise<PaymentGateway> {
    return this.updateGateway(gatewayName, { is_test_mode: isTestMode }, userId);
  },

  async updateApiKeys(
    gatewayName: string,
    apiKey: string,
    apiSecret: string,
    webhookSecret: string | null,
    userId: string
  ): Promise<PaymentGateway> {
    return this.updateGateway(
      gatewayName,
      {
        api_key: apiKey,
        api_secret: apiSecret,
        webhook_secret: webhookSecret,
      },
      userId
    );
  },

  async testConnection(gatewayName: string): Promise<{ success: boolean; message: string }> {
    // This would integrate with actual payment gateway APIs
    // For now, we'll simulate a test
    const gateway = await this.getGateway(gatewayName);
    
    if (!gateway) {
      return { success: false, message: "Gateway not found" };
    }

    if (!gateway.api_key || !gateway.api_secret) {
      return { success: false, message: "API credentials not configured" };
    }

    // Simulate API test (in production, this would call the actual gateway API)
    return { 
      success: true, 
      message: `${gatewayName} connection test successful (${gateway.is_test_mode ? 'Test Mode' : 'Live Mode'})` 
    };
  },
};
