import { supabase } from "@/integrations/supabase/client";

// This helper function is moved out of the class and has no dependency on lib/utils
// to break the complex type inference chain causing the TS error.
async function updateDonationStatusAfterPayment(
  donationId: string, 
  transactionId: string, 
  paymentMethod: "card" | "bank" | "paypal"
) {
  return supabase
    .from("donations" as any)
    .update({
      payment_status: "completed",
      payment_method: paymentMethod,
      transaction_id: transactionId,
      updated_at: new Date().toISOString(),
    })
    .eq("id", donationId);
}

export interface PayProPaymentRequest {
  amount: number;
  currency: string;
  orderId: string;
  description: string;
  customerName: string;
  customerEmail: string;
  customerPhone?: string;
  returnUrl: string;
  cancelUrl: string;
}

export interface PayProPaymentResponse {
  success: boolean;
  paymentUrl?: string;
  transactionId?: string;
  message?: string;
  error?: string;
}

export interface PayProVerificationResponse {
  success: boolean;
  status?: string;
  [key: string]: unknown;
}

export interface PayProWebhookData {
  transaction_id: string;
  order_id: string;
  status: string;
  [key: string]: unknown;
}

class PayProService {
  private baseUrl = "https://api.PayPro.com.pk";
  private clientId = "8rfsemzKXmf3pWv";
  private username = "JLEBI";

  async createPayment(paymentData: PayProPaymentRequest): Promise<PayProPaymentResponse> {
    try {
      const payload = {
        client_id: this.clientId,
        username: this.username,
        amount: paymentData.amount,
        currency: paymentData.currency || "PKR",
        order_id: paymentData.orderId,
        description: paymentData.description,
        customer_name: paymentData.customerName,
        customer_email: paymentData.customerEmail,
        customer_phone: paymentData.customerPhone,
        return_url: paymentData.returnUrl,
        cancel_url: paymentData.cancelUrl,
        timestamp: Date.now()
      };

      const response = await fetch(`${this.baseUrl}/payment/create`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify(payload)
      });

      const result = await response.json();

      if (response.ok && result.success) {
        return {
          success: true,
          paymentUrl: result.payment_url,
          transactionId: result.transaction_id,
          message: result.message
        };
      } else {
        return {
          success: false,
          error: result.message || "Payment creation failed"
        };
      }
    } catch (error) {
      console.error("PayPro payment creation error:", error);
      return {
        success: false,
        error: "Network error occurred while creating payment"
      };
    }
  }

  async verifyPayment(transactionId: string): Promise<PayProVerificationResponse> {
    try {
      const response = await fetch(`${this.baseUrl}/payment/verify`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify({
          client_id: this.clientId,
          username: this.username,
          transaction_id: transactionId
        })
      });

      const result = await response.json();
      return result;
    } catch (error) {
      console.error("PayPro payment verification error:", error);
      return { success: false, error: "Verification failed" };
    }
  }

  async handleWebhook(webhookData: PayProWebhookData): Promise<boolean> {
    try {
      const verification = await this.verifyPayment(webhookData.transaction_id);
      
      if (!verification.success || verification.status !== "completed") {
        console.warn("PayPro webhook verification failed or status not complete.", verification);
        return false;
      }

      const donationRes: any = await supabase
        .from("donations" as any)
        .select("id, child_id, amount")
        .eq("order_id", webhookData.order_id)
        .single();
      const rawDonation = donationRes?.data as { id: string; child_id: string | null; amount: number } | null;
      const fetchError = donationRes?.error as any;

      if (fetchError || !rawDonation) {
        console.error("Webhook Error: Donation not found for order_id:", webhookData.order_id, fetchError);
        return false;
      }

      const donationId: string = rawDonation.id;
      const childId: string | null = rawDonation.child_id;

      const { error: updateError } = await updateDonationStatusAfterPayment(
        donationId,
        webhookData.transaction_id,
        "bank"
      );

      if (updateError) {
        console.error("Database update error:", updateError);
        return false;
      }

      if (childId) {
        const childDonationsRes: any = await supabase
          .from("donations" as any)
          .select("amount")
          .eq("child_id", childId)
          .eq("payment_status", "completed");
        const childDonations = (childDonationsRes?.data as Array<{ amount: number }> | null) || [];

        const totalRaised = childDonations.reduce((sum, d) => sum + Number(d.amount), 0);

        await supabase
          .from("children" as any) 
          .update({ raised_amount: totalRaised })
          .eq("id", childId);
      }

      return true;

    } catch (error) {
      console.error("Webhook handling error:", error);
      return false;
    }
  }

  generateOrderId(): string {
    return `REHMA_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  }
}

export const payproService = new PayProService();
export default payproService;
