import { emailTemplates } from "@/lib/emailTemplates";
import { getEmailProvider } from "@/lib/emailProviders";
import { config } from "@/lib/config";

interface EmailServiceData {
  to: string;
  subject: string;
  html: string;
  text: string;
}

export const emailService = {
  async sendDonationConfirmation(data: {
    donorName: string;
    donorEmail: string;
    childName: string;
    amount: number;
    currency: string;
    donationId: string;
  }) {
    const template = emailTemplates.donationConfirmation({
      donorName: data.donorName,
      childName: data.childName,
      amount: data.amount,
      currency: data.currency,
      donationId: data.donationId,
    });

    return this.sendEmail({
      to: data.donorEmail,
      subject: template.subject,
      html: template.html,
      text: template.text,
    });
  },

  async sendWelcomeEmail(data: {
    userName: string;
    userEmail: string;
  }) {
    const template = emailTemplates.welcomeEmail({
      userName: data.userName,
      userEmail: data.userEmail,
    });

    return this.sendEmail({
      to: data.userEmail,
      subject: template.subject,
      html: template.html,
      text: template.text,
    });
  },

  async sendChildUpdateNotification(data: {
    donorName: string;
    donorEmail: string;
    childName: string;
    updateMessage: string;
  }) {
    const template = emailTemplates.childUpdateNotification({
      donorName: data.donorName,
      childName: data.childName,
      updateMessage: data.updateMessage,
    });

    return this.sendEmail({
      to: data.donorEmail,
      subject: template.subject,
      html: template.html,
      text: template.text,
    });
  },

  async sendAdminNotification(data: {
    subject: string;
    message: string;
    type: 'donation' | 'user_registration' | 'system_alert';
  }) {
    const adminEmails = ['admin@rehma.ai']; // Configure admin emails
    
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h2 style="color: #101c2c;">Admin Notification - ${data.type.replace('_', ' ').toUpperCase()}</h2>
        <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p>${data.message}</p>
        </div>
        <p style="color: #666; font-size: 12px;">
          This is an automated notification from Rehma Foundation platform.
        </p>
      </div>
    `;

    const text = `
      Admin Notification - ${data.type.replace('_', ' ').toUpperCase()}
      
      ${data.message}
      
      This is an automated notification from Rehma Foundation platform.
    `;

    const results = [];
    for (const email of adminEmails) {
      const result = await this.sendEmail({
        to: email,
        subject: `[Rehma Admin] ${data.subject}`,
        html,
        text,
      });
      results.push(result);
    }

    return results;
  },

  async sendPasswordResetEmail(data: {
    userEmail: string;
    resetToken: string;
    userName: string;
  }) {
    const resetUrl = `${config.app.url}/auth/reset-password?token=${data.resetToken}`;
    
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #101c2c;">Password Reset Request</h1>
        </div>
        
        <p>Dear ${data.userName},</p>
        <p>We received a request to reset your password for your Rehma Foundation account.</p>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${resetUrl}" style="background: #d4af37; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold;">Reset Password</a>
        </div>
        
        <p>If you didn't request this password reset, please ignore this email. The link will expire in 1 hour.</p>
        
        <p>For security reasons, please don't share this link with anyone.</p>
        
        <p>Best regards,<br>The Rehma Foundation Team</p>
      </div>
    `;

    const text = `
      Password Reset Request
      
      Dear ${data.userName},
      
      We received a request to reset your password for your Rehma Foundation account.
      
      Please click the following link to reset your password:
      ${resetUrl}
      
      If you didn't request this password reset, please ignore this email. The link will expire in 1 hour.
      
      For security reasons, please don't share this link with anyone.
      
      Best regards,
      The Rehma Foundation Team
    `;

    return this.sendEmail({
      to: data.userEmail,
      subject: 'Reset Your Rehma Foundation Password',
      html,
      text,
    });
  },

  async sendEmail(emailData: EmailServiceData) {
    try {
      // In development, just log the email
      if (config.app.environment === 'development') {
        console.log("📧 Email would be sent:", {
          to: emailData.to,
          subject: emailData.subject,
          preview: emailData.text.substring(0, 100) + "...",
        });

        return {
          success: true,
          messageId: `dev_${Date.now()}`,
        };
      }

      // In production, use the configured email provider
      const provider = getEmailProvider();
      const result = await provider.sendEmail({
        to: emailData.to,
        subject: emailData.subject,
        html: emailData.html,
        text: emailData.text,
      });

      // Log successful emails for monitoring
      if (result.success) {
        console.log(`✅ Email sent successfully to ${emailData.to} - ID: ${result.messageId}`);
      } else {
        console.error(`❌ Email failed to ${emailData.to} - Error: ${result.error}`);
      }

      return result;
    } catch (error) {
      console.error("Email service error:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown email error",
      };
    }
  },

  async sendBulkEmails(emails: EmailServiceData[]) {
    try {
      const provider = getEmailProvider();
      const emailsWithProvider = emails.map(email => ({
        to: email.to,
        subject: email.subject,
        html: email.html,
        text: email.text,
      }));

      const results = await provider.sendBulkEmails(emailsWithProvider);
      
      // Log bulk email results
      const successful = results.filter(r => r.success).length;
      const failed = results.filter(r => !r.success).length;
      
      console.log(`📊 Bulk email results: ${successful} successful, ${failed} failed`);
      
      return results;
    } catch (error) {
      console.error("Bulk email service error:", error);
      return emails.map(() => ({
        success: false,
        error: error instanceof Error ? error.message : "Unknown bulk email error",
      }));
    }
  },
};

export default emailService;
