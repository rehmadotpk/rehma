import { supabase } from "@/integrations/supabase/client";
import { UserProfile } from "./authService";

export interface ApprovalRequest {
  id: string;
  entity_type: 'child' | 'ngo' | 'doctor' | 'shop_owner';
  entity_id: string;
  requester_id: string;
  status: 'pending' | 'approved' | 'rejected' | 'under_review';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  admin_notes?: string;
  rejection_reason?: string;
  approved_by?: string;
  approved_at?: string;
  created_at: string;
  updated_at: string;
  entity_data?: unknown;
  requester_data?: Partial<UserProfile>;
}

export interface CreateApprovalRequest {
  entity_type: 'child' | 'ngo' | 'doctor' | 'shop_owner';
  entity_id: string;
  priority?: 'low' | 'medium' | 'high' | 'urgent';
}

export const approvalService = {
  async createApprovalRequest(data: CreateApprovalRequest): Promise<ApprovalRequest> {
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) throw new Error('User not authenticated');

    const { data: result, error } = await supabase
      .from('approval_requests')
      .insert({
        entity_type: data.entity_type,
        entity_id: data.entity_id,
        requester_id: user.id,
        priority: data.priority || 'medium',
        status: 'pending'
      })
      .select()
      .single();

    if (error) throw error;
    return result as ApprovalRequest;
  },

  async getPendingApprovals(page = 1, limit = 20): Promise<{ requests: ApprovalRequest[], total: number }> {
    const offset = (page - 1) * limit;
    
    const { data, error, count } = await supabase
      .from('approval_requests')
      .select(`
        *,
        requester_data:user_profiles(full_name, email, role)
      `, { count: 'exact' })
      .in('status', ['pending', 'under_review'])
      .range(offset, offset + limit - 1)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return { requests: data as ApprovalRequest[], total: count || 0 };
  },

  async getApprovalsByEntity(entityType: string, entityId: string): Promise<ApprovalRequest[]> {
    const { data, error } = await supabase
      .from('approval_requests')
      .select('*')
      .eq('entity_type', entityType)
      .eq('entity_id', entityId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data as ApprovalRequest[];
  },

  async updateApprovalStatus(
    requestId: string, 
    status: 'approved' | 'rejected' | 'under_review',
    adminNotes?: string,
    rejectionReason?: string
  ): Promise<ApprovalRequest> {
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) throw new Error('User not authenticated');

    const updateData: Partial<ApprovalRequest> = {
      status,
      admin_notes: adminNotes,
      rejection_reason: rejectionReason,
      updated_at: new Date().toISOString()
    };

    if (status === 'approved') {
      updateData.approved_by = user.id;
      updateData.approved_at = new Date().toISOString();
    }

    const { data, error } = await supabase
      .from('approval_requests')
      .update(updateData)
      .eq('id', requestId)
      .select()
      .single();

    if (error) throw error;

    // Update the entity status as well
    const request = data as ApprovalRequest;
    if (status === 'approved') {
      await this.updateEntityStatus(request.entity_type, request.entity_id, 'approved');
    } else if (status === 'rejected') {
      await this.updateEntityStatus(request.entity_type, request.entity_id, 'rejected');
    }

    return request;
  },

  async updateEntityStatus(entityType: string, entityId: string, status: string): Promise<void> {
    let tableName: string;
    switch (entityType) {
      case 'child':
        tableName = 'children';
        break;
      case 'ngo':
        tableName = 'ngos';
        break;
      case 'doctor':
        tableName = 'doctors';
        break;
      // shop_owners table does not exist
      // case 'shop_owner':
      //   tableName = 'shop_owners';
      //   break;
      default:
        console.warn(`Invalid entity type for status update: ${entityType}`);
        return;
    }

    const { error } = await supabase
      .from(tableName as any)
      .update({
        approval_status: status, // Use approval_status which exists on children, ngos, doctors
        updated_at: new Date().toISOString(),
      })
      .eq('id', entityId);

    if (error) {
      console.error(`Failed to update status for ${entityType} ${entityId}:`, error);
      throw error;
    }
  },

  async getApprovalStats(): Promise<{
    pending: number;
    approved: number;
    rejected: number;
    underReview: number;
  }> {
    const { data, error } = await supabase
      .from('approval_requests')
      .select('status');

    if (error) throw error;

    const stats = {
      pending: 0,
      approved: 0,
      rejected: 0,
      underReview: 0
    };

    data?.forEach(request => {
      switch (request.status) {
        case 'pending':
          stats.pending++;
          break;
        case 'approved':
          stats.approved++;
          break;
        case 'rejected':
          stats.rejected++;
          break;
        case 'under_review':
          stats.underReview++;
          break;
      }
    });

    return stats;
  }
};

export default approvalService;
