
import { supabase } from "@/integrations/supabase/client";

export interface NGO {
  id: string;
  profile_id?: string;
  organization_name?: string;
  registration_number?: string;
  description?: string;
  website?: string;
  contact_email?: string;
  contact_phone?: string;
  address?: string;
  contact_person?: string;
  focus_areas?: string[];
  verification_documents?: string[];
  verified: boolean;
  status: string;
  created_at: string;
  updated_at: string;
  user_profile?: {
    full_name: string;
    avatar_url?: string;
    location?: string;
    bio?: string;
  };
}

export interface CreateNGORequest {
  organization_name: string;
  registration_number?: string;
  description?: string;
  website?: string;
  contact_email?: string;
  contact_phone?: string;
  address?: string;
  contact_person?: string;
  focus_areas?: string[];
}

export const ngoService = {
  async getAllNGOs(page = 1, limit = 20, filters?: {
    verified?: boolean;
    search?: string;
  }) {
    try {
      let query = supabase
        .from('ngos')
        .select('*');
      
      if (filters?.verified !== undefined) {
        query = query.eq('verified', filters.verified);
      }

      if (filters?.search) {
        const searchTerm = filters.search.toLowerCase();
        query = query.or(`organization_name.ilike.%${searchTerm}%,description.ilike.%${searchTerm}%`);
      }

      // Apply pagination
      const offset = (page - 1) * limit;
      query = query.range(offset, offset + limit - 1);
      
      const { data, error, count } = await query;
      
      if (error) {
        console.error('NGO Service getAllNGOs Error:', error);
        return { ngos: [], total: 0 };
      }
      
      return { ngos: data || [], total: count || 0 };
    } catch (error) {
      console.error('NGO Service getAllNGOs Error:', error);
      return { ngos: [], total: 0 };
    }
  },

  async getVerifiedNGOs(filters: {
    search?: string;
    limit?: number;
  } = {}) {
    try {
      const limit = filters.limit || 10;
      let query = supabase
        .from('ngos')
        .select('*')
        .eq('verified', true)
        .eq('status', 'approved');

      if (filters.search) {
        const searchTerm = filters.search.toLowerCase();
        query = query.or(`organization_name.ilike.%${searchTerm}%,description.ilike.%${searchTerm}%`);
      }

      query = query.limit(limit);
      
      const { data, error } = await query;
      
      if (error) {
        console.error('NGO Service getVerifiedNGOs Error:', error);
        return [];
      }
      
      return data || [];
    } catch (error) {
      console.error('NGO Service getVerifiedNGOs Error:', error);
      return [];
    }
  },

  async getNGOById(id: string) {
    try {
      const { data: ngo, error } = await supabase
        .from('ngos')
        .select('*')
        .eq('id', id)
        .single();

      if (error) {
        console.error('NGO Service getNGOById Error:', error);
        throw error;
      }

      return ngo as NGO;
    } catch (error) {
      console.error('NGO Service getNGOById Error:', error);
      throw error;
    }
  },

  async createNGOProfile(userId: string, ngoData: CreateNGORequest) {
    try {
      const { data, error } = await supabase
        .from('ngos')
        .insert([
          {
            profile_id: userId,
            ...ngoData,
            verified: false,
            status: 'pending'
          }
        ])
        .select();

      if (error) {
        console.error('NGO Service createNGOProfile Error:', error);
        throw error;
      }
      
      return data[0] as NGO;
    } catch (error) {
      console.error('NGO Service createNGOProfile Error:', error);
      throw error;
    }
  },

  async updateNGOProfile(id: string, updates: Partial<NGO>) {
    try {
      const { data, error } = await supabase
        .from('ngos')
        .update({
          ...updates,
          updated_at: new Date().toISOString()
        })
        .eq('id', id)
        .select();

      if (error) {
        console.error('NGO Service updateNGOProfile Error:', error);
        throw error;
      }
      
      return data[0] as NGO;
    } catch (error) {
      console.error('NGO Service updateNGOProfile Error:', error);
      throw error;
    }
  },

  async verifyNGO(id: string, verified: boolean) {
    try {
      const { data, error } = await supabase
        .from('ngos')
        .update({ 
          verified,
          status: verified ? 'approved' : 'pending',
          updated_at: new Date().toISOString()
        })
        .eq('id', id)
        .select();

      if (error) {
        console.error('NGO Service verifyNGO Error:', error);
        throw error;
      }
      
      return data[0] as NGO;
    } catch (error) {
      console.error('NGO Service verifyNGO Error:', error);
      throw error;
    }
  },

  async searchNGOs(query: string, limit = 20) {
    try {
      const { data: ngos, error } = await supabase
        .from('ngos')
        .select('*')
        .eq('verified', true)
        .eq('status', 'approved')
        .or(`organization_name.ilike.%${query}%,description.ilike.%${query}%`)
        .order('created_at', { ascending: false })
        .limit(limit);

      if (error) {
        console.error('NGO Service searchNGOs Error:', error);
        throw error;
      }

      return (ngos || []) as NGO[];
    } catch (error) {
      console.error('NGO Service searchNGOs Error:', error);
      throw error;
    }
  }
};

export default ngoService;
