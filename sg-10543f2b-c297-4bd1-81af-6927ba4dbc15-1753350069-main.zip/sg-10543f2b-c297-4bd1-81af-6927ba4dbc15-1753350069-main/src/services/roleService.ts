
import { supabase } from "@/integrations/supabase/client";

export const roleService = {
  async getUserRole(userId: string): Promise<"admin" | "user"> {
    try {
      const { data: profileData, error } = await supabase
        .from('user_profiles')
        .select('role')
        .eq('id', userId)
        .single();

      if (error || !profileData) {
        console.error('Error fetching user role from profile:', error?.message);
        return 'user';
      }

      if (profileData.role === 'admin') {
        return 'admin';
      }

      return 'user';
    } catch (error) {
      console.error('Error in getUserRole:', error);
      return 'user';
    }
  },

  async setUserRole(userId: string, role: "admin" | "user"): Promise<boolean> {
    try {
      // Update user_profiles table
      const { error: profileError } = await supabase
        .from('user_profiles')
        .update({ 
          role: role,
          updated_at: new Date().toISOString()
        })
        .eq('id', userId);

      if (profileError) {
        console.error('Error updating profile role:', profileError);
        return false;
      }

      // Also update user_roles table for consistency
      const { error: roleError } = await supabase
        .from('user_roles')
        .upsert({
          user_id: userId,
          role: role,
          updated_at: new Date().toISOString()
        }, { onConflict: 'user_id' });

      if (roleError) {
        console.error('Error setting user role in user_roles:', roleError);
        // Don't return false here, as the primary source (user_profiles) was updated.
      }

      return true;
    } catch (error) {
      console.error('Error in setUserRole:', error);
      return false;
    }
  },

  async isAdmin(userId: string): Promise<boolean> {
    const role = await this.getUserRole(userId);
    return role === 'admin';
  },

  async promoteToAdmin(userId: string): Promise<boolean> {
    return await this.setUserRole(userId, 'admin');
  }
};

export default roleService;
