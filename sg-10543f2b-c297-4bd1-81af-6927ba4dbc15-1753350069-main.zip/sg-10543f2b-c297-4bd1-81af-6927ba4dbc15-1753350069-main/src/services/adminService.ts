import { supabase } from "@/integrations/supabase/client";
import { UserProfile } from "./authService";
import type { User } from "@supabase/supabase-js";

export interface AdminStats {
  totalUsers: number;
  totalChildren: number;
  totalDonations: number;
  totalAmount: number;
  pendingVerifications: number;
  activeNGOs: number;
  activeDoctors: number;
}

export interface AdminUser {
  id: string;
  email: string;
  full_name: string;
  role: string;
  verified: boolean;
  created_at: string;
  last_sign_in_at?: string;
}

export const adminService = {
  // Get admin dashboard statistics
  async getAdminStats(): Promise<AdminStats> {
    try {
      const [
        { count: totalUsers },
        { count: totalChildren },
        { count: totalDonations },
        { data: donationSum },
        { count: pendingVerifications },
        { count: activeNGOs },
        { count: activeDoctors }
      ] = await Promise.all([
        supabase.from('user_profiles').select('*', { count: 'exact', head: true }),
        supabase.from('children').select('*', { count: 'exact', head: true }),
        supabase.from('donations').select('*', { count: 'exact', head: true }),
        supabase.from('donations').select('amount').eq('payment_status', 'completed'),
        supabase.from('children').select('*', { count: 'exact', head: true }).eq('verified', false),
        supabase.from('ngos').select('*', { count: 'exact', head: true }).eq('status', 'approved'),
        supabase.from('doctors').select('*', { count: 'exact', head: true }).eq('status', 'approved')
      ]);

      const totalAmount = donationSum?.reduce((sum, donation) => sum + Number(donation.amount), 0) || 0;

      return {
        totalUsers: totalUsers || 0,
        totalChildren: totalChildren || 0,
        totalDonations: totalDonations || 0,
        totalAmount,
        pendingVerifications: pendingVerifications || 0,
        activeNGOs: activeNGOs || 0,
        activeDoctors: activeDoctors || 0
      };
    } catch (error) {
      console.error('Error fetching admin stats:', error);
      throw error;
    }
  },

  // Get all users for admin management
  async getAllUsers(): Promise<AdminUser[]> {
    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .select(`
          id,
          full_name,
          role,
          verified,
          created_at
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Get auth data for emails
      const { data: authUsers, error: authError } = await supabase.auth.admin.listUsers();
      
      if (authError) {
        console.error('Error fetching auth users:', authError);
      }

      // Combine profile and auth data
      const combinedUsers = data?.map(profile => {
        const authUser = authUsers?.users.find((au: User) => au.id === profile.id);
        return {
          ...profile,
          email: authUser?.email || 'N/A',
          last_sign_in_at: authUser?.last_sign_in_at
        };
      }) || [];

      return combinedUsers;
    } catch (error) {
      console.error('Error fetching all users:', error);
      throw error;
    }
  },

  // Update user role (admin function)
  async updateUserRole(userId: string, newRole: UserProfile['role']): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('user_profiles')
        .update({ 
          role: newRole,
          updated_at: new Date().toISOString()
        })
        .eq('id', userId);

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error updating user role:', error);
      throw error;
    }
  },

  // Verify/unverify user (admin function)
  async updateUserVerification(userId: string, verified: boolean): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('user_profiles')
        .update({ 
          verified,
          updated_at: new Date().toISOString()
        })
        .eq('id', userId);

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error updating user verification:', error);
      throw error;
    }
  },

  // Create admin user (super admin function)
  async createAdminUser(email: string, password: string, fullName: string): Promise<AdminUser | null> {
    try {
      // Create auth user
      const { data: authData, error: authError } = await supabase.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
        user_metadata: {
          full_name: fullName,
          role: 'admin'
        }
      });

      if (authError) throw authError;
      if (!authData.user) throw new Error('Failed to create user');

      // Create profile
      const { error: profileError } = await supabase
        .from('user_profiles')
        .insert({
          id: authData.user.id,
          email,
          full_name: fullName,
          role: 'admin',
          verified: true,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
        .select()
        .single();

      if (profileError) throw profileError;

      return {
        id: authData.user.id,
        email: authData.user.email || email,
        full_name: fullName,
        role: 'admin',
        verified: true,
        created_at: authData.user.created_at
      };
    } catch (error) {
      console.error('Error creating admin user:', error);
      throw error;
    }
  },

  // Check if current user is admin
  async isCurrentUserAdmin(): Promise<boolean> {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return false;

      const { data: profile } = await supabase
        .from('user_profiles')
        .select('role')
        .eq('id', user.id)
        .single();

      return profile?.role === 'admin';
    } catch (error) {
      console.error('Error checking admin status:', error);
      return false;
    }
  }
};

export default adminService;
