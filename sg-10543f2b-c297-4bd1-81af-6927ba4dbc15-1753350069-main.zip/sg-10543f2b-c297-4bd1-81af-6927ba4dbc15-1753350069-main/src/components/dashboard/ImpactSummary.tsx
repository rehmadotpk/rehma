import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Users, 
  Award,
  Target,
  Clock
} from "lucide-react";
import { useCurrency } from "@/contexts/CurrencyContext";

interface ImpactData {
  totalDonated: number;
  childrenHelped: number;
  monthsActive: number;
  averageMonthly: number;
  impactScore: number;
  achievements: string[];
  recentChildren: Array<{
    id: string;
    name: string;
    image?: string;
    progress: number;
    lastUpdate: string;
  }>;
}

interface ImpactSummaryProps {
  data: ImpactData;
  userRole: string;
}

export default function ImpactSummary({ data, userRole }: ImpactSummaryProps) {
  const { formatPrice } = useCurrency();
  const isDonor = userRole === 'donor';

  const getImpactLevel = (score: number) => {
    if (score >= 80) return { level: "Champion", color: "text-purple-600", bg: "bg-purple-100" };
    if (score >= 60) return { level: "Hero", color: "text-blue-600", bg: "bg-blue-100" };
    if (score >= 40) return { level: "Supporter", color: "text-green-600", bg: "bg-green-100" };
    return { level: "Helper", color: "text-yellow-600", bg: "bg-yellow-100" };
  };

  const impactLevel = getImpactLevel(data.impactScore);

  return (
    <div className="space-y-6">
      {/* Impact Overview */}
      <Card className="border-0 shadow-lg bg-gradient-to-br from-[#101c2c] to-yellow-600 text-white">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center">
              <Award className="w-6 h-6 mr-2" />
              Your Impact Summary
            </span>
            <Badge className={`${impactLevel.bg} ${impactLevel.color} border-0`}>
              {impactLevel.level}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold">{formatPrice(data.totalDonated)}</div>
              <div className="text-sm text-yellow-100">
                {isDonor ? 'Total Donated' : 'Support Received'}
              </div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">{data.childrenHelped}</div>
              <div className="text-sm text-yellow-100">
                {isDonor ? 'Children Helped' : 'Active Profiles'}
              </div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">{data.monthsActive}</div>
              <div className="text-sm text-yellow-100">Months Active</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">{formatPrice(data.averageMonthly)}</div>
              <div className="text-sm text-yellow-100">Monthly Average</div>
            </div>
          </div>

          <div>
            <div className="flex justify-between text-sm mb-2">
              <span>Impact Score</span>
              <span>{data.impactScore}/100</span>
            </div>
            <Progress value={data.impactScore} className="h-3 bg-white/20" />
            <p className="text-xs text-yellow-100 mt-2">
              {isDonor 
                ? 'Based on consistency, amount, and engagement'
                : 'Based on profile completeness and community engagement'
              }
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Recent Children Updates */}
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Users className="w-5 h-5 mr-2" />
            {isDonor ? 'Children You\'re Supporting' : 'Your Child Profiles'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {data.recentChildren.map((child) => (
              <div key={child.id} className="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <Avatar className="w-12 h-12">
                  <AvatarImage src={child.image} />
                  <AvatarFallback className="bg-gradient-to-br from-blue-100 to-purple-100">
                    {child.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <h4 className="font-medium">{child.name}</h4>
                  <div className="flex items-center space-x-2 text-sm text-gray-500">
                    <Clock className="w-3 h-3" />
                    <span>Updated {child.lastUpdate}</span>
                  </div>
                  <div className="mt-2">
                    <div className="flex justify-between text-xs mb-1">
                      <span>Progress</span>
                      <span>{child.progress}%</span>
                    </div>
                    <Progress value={child.progress} className="h-1" />
                  </div>
                </div>
                <div className="text-right">
                  <Badge variant="outline" className="text-xs">
                    {child.progress >= 80 ? 'Nearly Complete' : 
                     child.progress >= 50 ? 'Good Progress' : 'Getting Started'}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Achievements */}
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Target className="w-5 h-5 mr-2" />
            Recent Achievements
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3">
            {data.achievements.map((achievement, index) => (
              <div key={index} className="flex items-center space-x-3 p-3 border rounded-lg">
                <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                  <Award className="w-4 h-4 text-yellow-600" />
                </div>
                <div>
                  <p className="font-medium text-sm">{achievement}</p>
                  <p className="text-xs text-gray-500">Unlocked recently</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
