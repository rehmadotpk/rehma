
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  TrendingUp, 
  Heart, 
  Calendar,
  ArrowRight,
  Lightbulb,
  Star,
  Gift
} from "lucide-react";
import { useCurrency } from "@/contexts/CurrencyContext";

interface InsightData {
  donationTrend: 'increasing' | 'stable' | 'decreasing';
  suggestedAmount: number;
  preferredCauses: string[];
  bestDonationTime: string;
  impactPrediction: string;
  recommendations: Array<{
    type: 'child' | 'cause' | 'amount';
    title: string;
    description: string;
    action: string;
  }>;
}

interface PersonalizedInsightsProps {
  data: InsightData;
  userRole: string;
}

export default function PersonalizedInsights({ data, userRole }: PersonalizedInsightsProps) {
  const { formatPrice } = useCurrency();
  const isDonor = userRole === 'donor';

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'increasing': return <TrendingUp className="w-4 h-4 text-green-500" />;
      case 'stable': return <Heart className="w-4 h-4 text-blue-500" />;
      case 'decreasing': return <TrendingUp className="w-4 h-4 text-orange-500 rotate-180" />;
      default: return <Heart className="w-4 h-4 text-gray-500" />;
    }
  };

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case 'increasing': return 'text-green-600';
      case 'stable': return 'text-blue-600';
      case 'decreasing': return 'text-orange-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      {/* Donation Insights */}
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Lightbulb className="w-5 h-5 mr-2" />
            Personal Insights
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="p-4 bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Donation Trend</span>
                {getTrendIcon(data.donationTrend)}
              </div>
              <p className={`text-lg font-bold ${getTrendColor(data.donationTrend)}`}>
                {data.donationTrend.charAt(0).toUpperCase() + data.donationTrend.slice(1)}
              </p>
              <p className="text-xs text-gray-600 mt-1">
                {isDonor ? 'Your giving pattern over time' : 'Support received pattern'}
              </p>
            </div>

            <div className="p-4 bg-gradient-to-br from-green-50 to-yellow-50 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Suggested Amount</span>
                <Gift className="w-4 h-4 text-green-500" />
              </div>
              <p className="text-lg font-bold text-green-600">
                {formatPrice(data.suggestedAmount)}
              </p>
              <p className="text-xs text-gray-600 mt-1">
                Based on your history and capacity
              </p>
            </div>
          </div>

          <div className="p-4 bg-gradient-to-r from-[#101c2c]/5 to-yellow-50 rounded-lg border border-[#101c2c]/10">
            <h4 className="font-medium text-[#101c2c] mb-2 flex items-center">
              <Star className="w-4 h-4 mr-2" />
              Impact Prediction
            </h4>
            <p className="text-sm text-gray-700">{data.impactPrediction}</p>
          </div>

          <div>
            <h4 className="font-medium mb-3">Your Preferred Causes</h4>
            <div className="flex flex-wrap gap-2">
              {data.preferredCauses.map((cause, index) => (
                <Badge key={index} variant="outline" className="border-[#101c2c] text-[#101c2c]">
                  {cause}
                </Badge>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium text-sm">Best Time to Donate</p>
              <p className="text-xs text-gray-600">{data.bestDonationTime}</p>
            </div>
            <Calendar className="w-5 h-5 text-gray-400" />
          </div>
        </CardContent>
      </Card>

      {/* Personalized Recommendations */}
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Star className="w-5 h-5 mr-2" />
            Recommended for You
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {data.recommendations.map((rec, index) => (
              <div key={index} className="flex items-center justify-between p-4 border rounded-lg hover:shadow-md transition-shadow">
                <div className="flex-1">
                  <h4 className="font-medium">{rec.title}</h4>
                  <p className="text-sm text-gray-600 mt-1">{rec.description}</p>
                </div>
                <Button variant="outline" size="sm" className="border-[#101c2c] text-[#101c2c] hover:bg-[#101c2c] hover:text-white">
                  {rec.action}
                  <ArrowRight className="w-3 h-3 ml-1" />
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
