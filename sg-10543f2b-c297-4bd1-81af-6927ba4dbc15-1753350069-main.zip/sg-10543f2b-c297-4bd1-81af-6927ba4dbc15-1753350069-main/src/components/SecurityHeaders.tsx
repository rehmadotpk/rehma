import { useEffect } from "react";

export function SecurityEnhancements() {
  useEffect(() => {
    // Content Security Policy (CSP) headers should be set at server level
    // This is a client-side fallback for additional security measures
    
    // Disable right-click context menu in production (optional)
    if (process.env.NODE_ENV === 'production') {
      const handleContextMenu = (e: MouseEvent) => {
        e.preventDefault();
      };
      
      document.addEventListener('contextmenu', handleContextMenu);
      
      return () => {
        document.removeEventListener('contextmenu', handleContextMenu);
      };
    }
  }, []);

  return null;
}

export function DataProtection() {
  useEffect(() => {
    // Clear sensitive data from memory on page unload
    const handleBeforeUnload = () => {
      // Clear any sensitive form data
      const forms = document.querySelectorAll("form");
      forms.forEach(form => {
        const inputs = form.querySelectorAll('input[type="password"], input[type="email"]');
        inputs.forEach((input) => {
          (input as HTMLInputElement).value = "";
        });
      });
    };

    window.addEventListener("beforeunload", handleBeforeUnload);
    
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, []);

  return null;
}
