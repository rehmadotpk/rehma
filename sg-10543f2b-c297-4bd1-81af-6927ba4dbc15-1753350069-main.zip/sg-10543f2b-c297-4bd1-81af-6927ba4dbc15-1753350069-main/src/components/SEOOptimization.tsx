
import Head from "next/head";
import { useRouter } from "next/router";

interface SEOProps {
  title?: string;
  description?: string;
  image?: string;
  type?: string;
  children?: React.ReactNode;
}

export default function SEOOptimization({
  title = "Rehma - Infinite Blessings Here & After",
  description = "Join our mission to provide life-saving medical care to children in need. Your donation can be the difference between despair and hope.",
  image = "/Logo-Rehma-sqaure.png",
  type = "website",
  children
}: SEOProps) {
  const router = useRouter();
  const canonicalUrl = `https://rehma.ai${router.asPath}`;

  return (
    <Head>
      {/* Primary Meta Tags */}
      <title>{title}</title>
      <meta name="title" content={title} />
      <meta name="description" content={description} />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <link rel="canonical" href={canonicalUrl} />

      {/* Open Graph / Facebook */}
      <meta property="og:type" content={type} />
      <meta property="og:url" content={canonicalUrl} />
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:image" content={image} />
      <meta property="og:site_name" content="Rehma" />

      {/* Twitter */}
      <meta property="twitter:card" content="summary_large_image" />
      <meta property="twitter:url" content={canonicalUrl} />
      <meta property="twitter:title" content={title} />
      <meta property="twitter:description" content={description} />
      <meta property="twitter:image" content={image} />

      {/* Additional Meta Tags */}
      <meta name="robots" content="index, follow" />
      <meta name="language" content="English" />
      <meta name="author" content="Rehma Team" />
      <meta name="theme-color" content="#101c2c" />
      
      {/* Structured Data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Organization",
            "name": "Rehma",
            "description": description,
            "url": "https://rehma.ai",
            "logo": "https://rehma.ai/Logo-Rehma-sqaure.png",
            "sameAs": [
              "https://facebook.com/rehma",
              "https://twitter.com/rehma",
              "https://instagram.com/rehma"
            ],
            "contactPoint": {
              "@type": "ContactPoint",
              "telephone": "+1-555-123-4567",
              "contactType": "customer service",
              "email": "info@rehma.ai"
            }
          })
        }}
      />

      {children}
    </Head>
  );
}
