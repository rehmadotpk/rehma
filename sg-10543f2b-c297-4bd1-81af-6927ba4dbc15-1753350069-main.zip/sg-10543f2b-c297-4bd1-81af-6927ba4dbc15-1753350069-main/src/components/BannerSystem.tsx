
import { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { X, ExternalLink } from "lucide-react";

interface Banner {
  id: string;
  title: string;
  description: string;
  image: string;
  ctaText: string;
  ctaLink: string;
  position: "hero" | "sidebar" | "between-sections" | "footer" | "top";
  priority: number;
  isActive: boolean;
  startDate: string;
  endDate: string;
  targetAudience: string[];
  sponsor: string;
  analytics: {
    impressions: number;
    clicks: number;
    ctr: number;
  };
  bannerType: "image" | "video" | "interactive";
  backgroundColor?: string;
  textColor?: string;
}

const mockBanners: Banner[] = [
  {
    id: "1",
    title: "Support Special Needs Education",
    description: "Join hands with leading NGOs to provide quality education for children with special needs",
    image: "https://images.unsplash.com/photo-1497486751825-1233686d5d80?w=800&h=400&fit=crop",
    ctaText: "Learn More",
    ctaLink: "/ngos",
    position: "hero",
    priority: 1,
    isActive: true,
    startDate: "2025-01-01",
    endDate: "2025-03-31",
    targetAudience: ["donors", "parents", "educators"],
    sponsor: "UNESCO Pakistan",
    analytics: {
      impressions: 45230,
      clicks: 1847,
      ctr: 4.08
    },
    bannerType: "image",
    backgroundColor: "#3B82F6",
    textColor: "#FFFFFF"
  },
  {
    id: "2", 
    title: "Therapy Equipment Drive",
    description: "Help us reach our goal of Rs 500,000 for essential therapy equipment",
    image: "https://images.unsplash.com/photo-1559027615-cd4628902d4a?w=600&h=300&fit=crop",
    ctaText: "Donate Now",
    ctaLink: "/children",
    position: "between-sections",
    priority: 2,
    isActive: true,
    startDate: "2025-01-15",
    endDate: "2025-02-28",
    targetAudience: ["donors", "medical-professionals"],
    sponsor: "Hope Foundation",
    analytics: {
      impressions: 32150,
      clicks: 2341,
      ctr: 7.28
    },
    bannerType: "image",
    backgroundColor: "#10B981",
    textColor: "#FFFFFF"
  },
  {
    id: "3",
    title: "Find Specialized Doctors",
    description: "Connect with verified medical professionals in your area",
    image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400&h=300&fit=crop",
    ctaText: "Book Consultation",
    ctaLink: "/doctors",
    position: "sidebar",
    priority: 3,
    isActive: true,
    startDate: "2025-01-01",
    endDate: "2025-12-31",
    targetAudience: ["parents", "caregivers"],
    sponsor: "Medical Association Pakistan",
    analytics: {
      impressions: 28940,
      clicks: 1456,
      ctr: 5.03
    },
    bannerType: "image",
    backgroundColor: "#8B5CF6",
    textColor: "#FFFFFF"
  },
  {
    id: "4",
    title: "Art Therapy Success Stories",
    description: "See how art therapy is transforming lives of special needs children",
    image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=600&h=200&fit=crop",
    ctaText: "View Gallery",
    ctaLink: "/shop",
    position: "footer",
    priority: 4,
    isActive: true,
    startDate: "2025-01-10",
    endDate: "2025-06-30",
    targetAudience: ["art-lovers", "donors", "therapists"],
    sponsor: "Creative Minds Foundation",
    analytics: {
      impressions: 19875,
      clicks: 892,
      ctr: 4.49
    },
    bannerType: "image",
    backgroundColor: "#F59E0B",
    textColor: "#FFFFFF"
  },
  {
    id: "5",
    title: "Urgent Appeal",
    description: "A new critical case has been added. Your immediate support can save a life.",
    image: "",
    ctaText: "View Case",
    ctaLink: "/children/critical-case-id",
    position: "top",
    priority: 1,
    isActive: true,
    startDate: "2025-01-01",
    endDate: "2025-12-31",
    targetAudience: ["all"],
    sponsor: "Rehma Foundation",
    analytics: {
      impressions: 100000,
      clicks: 5000,
      ctr: 5.0
    },
    bannerType: "image",
    backgroundColor: "#EF4444",
    textColor: "#FFFFFF"
  }
];

type BannerPosition = "top" | "footer" | "hero" | "sidebar" | "between-sections";

interface BannerSystemProps {
  position: BannerPosition;
}

export default function BannerSystem({ position }: BannerSystemProps) {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [currentBannerIndex, setCurrentBannerIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const activeBanners = mockBanners
      .filter(banner => 
        banner.position === position && 
        banner.isActive &&
        new Date(banner.startDate) <= new Date() &&
        new Date(banner.endDate) >= new Date()
      )
      .sort((a, b) => a.priority - b.priority);

    setBanners(activeBanners);
  }, [position]);

  useEffect(() => {
    if (banners.length > 1) {
      const interval = setInterval(() => {
        setCurrentBannerIndex((prev) => (prev + 1) % banners.length);
      }, 8000);
      return () => clearInterval(interval);
    }
  }, [banners.length]);

  const handleBannerClick = (banner: Banner) => {
    console.log(`Banner clicked: ${banner.id} - ${banner.title}`);
    setBanners(prev => prev.map(b => 
      b.id === banner.id 
        ? { ...b, analytics: { ...b.analytics, clicks: b.analytics.clicks + 1 } }
        : b
    ));
  };

  const handleBannerClose = () => {
    setIsVisible(false);
  };

  if (!isVisible || banners.length === 0) return null;

  const currentBanner = banners[currentBannerIndex];

  const renderBanner = () => {
    switch (position) {
      case "top":
        return (
            <div className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white p-3">
                <div className="max-w-7xl mx-auto flex items-center justify-between">
                    <p className="text-sm font-medium">
                        <span className="font-bold">{currentBanner.title}:</span> {currentBanner.description}
                    </p>
                    <div className="flex items-center gap-4">
                        <Link href={currentBanner.ctaLink}>
                            <Button 
                                size="sm" 
                                variant="outline"
                                className="bg-transparent text-white border-white hover:bg-white hover:text-blue-600"
                                onClick={() => handleBannerClick(currentBanner)}
                            >
                                {currentBanner.ctaText}
                            </Button>
                        </Link>
                        <Button
                            variant="ghost"
                            size="sm"
                            className="hover:bg-white/20"
                            onClick={handleBannerClose}
                        >
                            <X className="w-4 h-4" />
                        </Button>
                    </div>
                </div>
            </div>
        );
      case "hero":
        return (
          <div className="relative w-full h-64 md:h-80 rounded-2xl overflow-hidden shadow-xl mb-8">
            <Image
              src={currentBanner.image}
              alt={currentBanner.title}
              fill
              className="object-cover"
            />
            <div 
              className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent flex items-center"
              style={{ backgroundColor: `${currentBanner.backgroundColor}CC` }}
            >
              <div className="max-w-2xl px-8">
                <Badge className="mb-4 bg-white/20 text-white">
                  Sponsored by {currentBanner.sponsor}
                </Badge>
                <h2 
                  className="text-3xl md:text-4xl font-bold mb-4"
                  style={{ color: currentBanner.textColor }}
                >
                  {currentBanner.title}
                </h2>
                <p 
                  className="text-lg mb-6 opacity-90"
                  style={{ color: currentBanner.textColor }}
                >
                  {currentBanner.description}
                </p>
                <Link href={currentBanner.ctaLink}>
                  <Button 
                    size="lg" 
                    className="bg-white text-gray-900 hover:bg-gray-100"
                    onClick={() => handleBannerClick(currentBanner)}
                  >
                    {currentBanner.ctaText}
                    <ExternalLink className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="absolute top-4 right-4 text-white hover:bg-white/20"
              onClick={handleBannerClose}
            >
              <X className="w-4 h-4" />
            </Button>
            {banners.length > 1 && (
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                {banners.map((_, index) => (
                  <button
                    key={index}
                    className={`w-2 h-2 rounded-full transition-all ${
                      index === currentBannerIndex ? "bg-white" : "bg-white/50"
                    }`}
                    onClick={() => setCurrentBannerIndex(index)}
                  />
                ))}
              </div>
            )}
          </div>
        );
      case "sidebar":
        return (
          <Card className="p-4 mb-6 border-0 shadow-lg overflow-hidden">
            <div className="relative">
              <Image
                src={currentBanner.image}
                alt={currentBanner.title}
                width={400}
                height={200}
                className="w-full h-32 object-cover rounded-lg mb-3"
              />
              <Badge className="absolute top-2 right-2 bg-blue-500 text-white text-xs">
                Sponsored
              </Badge>
            </div>
            <h3 className="font-semibold text-sm mb-2">{currentBanner.title}</h3>
            <p className="text-xs text-gray-600 mb-3 line-clamp-2">{currentBanner.description}</p>
            <Link href={currentBanner.ctaLink}>
              <Button 
                size="sm" 
                className="w-full text-xs"
                onClick={() => handleBannerClick(currentBanner)}
              >
                {currentBanner.ctaText}
              </Button>
            </Link>
          </Card>
        );
      case "between-sections":
        return (
          <div className="w-full my-12">
            <Card className="p-6 border-0 shadow-lg bg-gradient-to-r from-blue-50 to-purple-50">
              <div className="flex flex-col md:flex-row items-center gap-6">
                <div className="flex-shrink-0">
                  <Image
                    src={currentBanner.image}
                    alt={currentBanner.title}
                    width={200}
                    height={120}
                    className="rounded-lg object-cover"
                  />
                </div>
                <div className="flex-1 text-center md:text-left">
                  <Badge className="mb-2 bg-blue-100 text-blue-800">
                    {currentBanner.sponsor}
                  </Badge>
                  <h3 className="text-xl font-bold mb-2">{currentBanner.title}</h3>
                  <p className="text-gray-600 mb-4">{currentBanner.description}</p>
                  <Link href={currentBanner.ctaLink}>
                    <Button 
                      className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                      onClick={() => handleBannerClick(currentBanner)}
                    >
                      {currentBanner.ctaText}
                      <ExternalLink className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="absolute top-2 right-2 md:relative md:top-0 md:right-0"
                  onClick={handleBannerClose}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </Card>
          </div>
        );
      case "footer":
        return (
          <div className="w-full bg-gradient-to-r from-orange-100 to-pink-100 p-4 rounded-lg mb-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Image
                  src={currentBanner.image}
                  alt={currentBanner.title}
                  width={80}
                  height={60}
                  className="rounded object-cover"
                />
                <div>
                  <h4 className="font-semibold text-sm">{currentBanner.title}</h4>
                  <p className="text-xs text-gray-600">{currentBanner.description}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Link href={currentBanner.ctaLink}>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => handleBannerClick(currentBanner)}
                  >
                    {currentBanner.ctaText}
                  </Button>
                </Link>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleBannerClose}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return renderBanner();
}
