import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Heart } from "lucide-react";
import { useCurrency } from "@/contexts/CurrencyContext";
import { Child } from "@/services/childrenService";
import DonationModal from "@/components/DonationModal";
import LoadingSpinner from "@/components/LoadingSpinner";
import { formatRelativeDate } from "@/lib/dateUtils";
import Image from "next/image";

interface EnhancedChildCardProps {
  child: Child;
  onDonationSuccess?: () => void;
}

export default function EnhancedChildCard({ child, onDonationSuccess }: EnhancedChildCardProps) {
  const { formatPrice } = useCurrency();
  const [showDonationModal, setShowDonationModal] = useState(false);
  const [donating, setDonating] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const progressPercentage = Math.min(100, (child.raised_amount / child.target_amount) * 100);
  const remainingAmount = child.target_amount - child.raised_amount;

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'high': return 'bg-red-500 text-white';
      case 'medium': return 'bg-yellow-500 text-white';
      case 'low': return 'bg-green-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const handleDonationSuccess = () => {
    setShowDonationModal(false);
    setDonating(false);
    if (onDonationSuccess) {
      onDonationSuccess();
    }
  };

  const handleQuickDonate = () => {
    setDonating(true);
    setShowDonationModal(true);
    setDonating(false);
  };

  return (
    <>
      <Card className="group hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border-0 shadow-lg overflow-hidden bg-white">
        <div className="relative overflow-hidden">
          <Image
            src={child.image || "/api/placeholder/400/300"}
            alt={child.name}
            width={400}
            height={300}
            className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.src = "/api/placeholder/400/300";
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          <div className="absolute top-4 right-4">
            <Badge className={`${getUrgencyColor(child.urgency)} shadow-lg`}>
              {child.urgency} priority
            </Badge>
          </div>
        </div>

        <CardContent className="p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-2">{child.name}</h3>
          <p className="text-gray-600 mb-3 line-clamp-2">{child.story}</p>
          <div className="mb-4">
            <div className="flex justify-between text-sm text-gray-600 mb-1">
              <span>Progress</span>
              <span className="font-bold text-[#101c2c]">{Math.round(progressPercentage)}%</span>
            </div>
            
            <div className="relative w-full bg-gray-200 rounded-full h-3 overflow-hidden">
              <div 
                className="absolute top-0 left-0 h-full bg-gradient-to-r from-[#101c2c] via-yellow-500 to-yellow-600 rounded-full transition-all duration-1000 ease-out"
                style={{ width: `${progressPercentage}%` }}
              >
                <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
              </div>
            </div>
            
            <div className="flex justify-between text-sm mt-2">
              <span className="text-green-600 font-semibold">
                {formatPrice(child.raised_amount)} raised
              </span>
              <span className="text-gray-600">
                {formatPrice(child.target_amount)} goal
              </span>
            </div>
            
            {remainingAmount > 0 && (
              <p className="text-xs text-red-600 mt-1 font-medium">
                {formatPrice(remainingAmount)} still needed
              </p>
            )}
          </div>

          <div className="grid grid-cols-3 gap-2 mb-4">
            {[1000, 2500, 5000].map((amount) => (
              <Button
                key={amount}
                variant="outline"
                size="sm"
                onClick={() => handleQuickDonate()}
                disabled={donating}
                className="text-xs hover:bg-yellow-50 hover:border-yellow-300 hover:text-[#101c2c] transition-all duration-300"
              >
                {donating ? <LoadingSpinner size="sm" /> : formatPrice(amount)}
              </Button>
            ))}
          </div>

          <Button 
            className="w-full bg-gradient-to-r from-[#101c2c] to-yellow-600 hover:from-[#1e293b] hover:to-yellow-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
            onClick={() => setShowDonationModal(true)}
            disabled={donating}
          >
            {donating ? (
              <>
                <LoadingSpinner size="sm" className="mr-2" />
                Processing...
              </>
            ) : (
              <>
                <Heart className="w-4 h-4 mr-2" />
                Help {child.name}
              </>
            )}
          </Button>

          <div className="flex justify-between items-center mt-3 text-xs text-gray-500">
            <span>{Math.floor(Math.random() * 50) + 10} donors</span>
            <span>{mounted ? formatRelativeDate(child.created_at) : 'Recently added'}</span>
          </div>
        </CardContent>
      </Card>

      {showDonationModal && (
        <DonationModal
          child={child}
          isOpen={showDonationModal}
          onClose={() => setShowDonationModal(false)}
          onSuccess={handleDonationSuccess}
        />
      )}
    </>
  );
}
