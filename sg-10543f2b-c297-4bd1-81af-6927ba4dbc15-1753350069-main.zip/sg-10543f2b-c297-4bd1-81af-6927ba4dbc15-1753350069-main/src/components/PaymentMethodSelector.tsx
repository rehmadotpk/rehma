import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CreditCard, Building2, ArrowLeft } from "lucide-react";
import dynamic from "next/dynamic";
import { formatNumber } from "@/lib/number";

const PayProPaymentForm = dynamic(() => import("./PayProPaymentForm"), { ssr: false });
const StripePaymentForm = dynamic(() => import("./StripePaymentForm"), { ssr: false });
const BankTransferForm = dynamic(() => import("./BankTransferForm"), { ssr: false });
const GooglePayPaymentForm = dynamic(() => import("./GooglePayPaymentForm"), { ssr: false });

interface PaymentMethodSelectorProps {
  amount: number;
  childId: string;
  childName: string;
  anonymous: boolean;
  message: string;
  onError: (error: string) => void;
  onSuccess: () => void;
  onBack: () => void;
}

type PaymentMethod = "googlepay" | "paypro" | "stripe" | "bank" | null;

export default function PaymentMethodSelector({
  amount,
  childId,
  childName,
  anonymous,
  message,
  onError,
  onSuccess,
  onBack,
}: PaymentMethodSelectorProps) {
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod>(null);

  if (selectedMethod === "paypro") {
    return (
      <div className="space-y-4">
        <Button variant="ghost" onClick={() => setSelectedMethod(null)} className="mb-4">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Payment Methods
        </Button>
        <PayProPaymentForm
          amount={amount}
          childId={childId}
          childName={childName}
          anonymous={anonymous}
          message={message}
          onError={onError}
          onSuccess={onSuccess}
        />
      </div>
    );
  }

  if (selectedMethod === "googlepay") {
    return (
      <div className="space-y-4">
        <Button variant="ghost" onClick={() => setSelectedMethod(null)} className="mb-4">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Payment Methods
        </Button>
        <GooglePayPaymentForm
          amount={amount}
          childId={childId}
          childName={childName}
          anonymous={anonymous}
          message={message}
          onError={onError}
          onSuccess={onSuccess}
        />
      </div>
    );
  }

  if (selectedMethod === "stripe") {
    return (
      <div className="space-y-4">
        <Button variant="ghost" onClick={() => setSelectedMethod(null)} className="mb-4">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Payment Methods
        </Button>
        <StripePaymentForm
          amount={amount}
          childId={childId}
          anonymous={anonymous}
          message={message}
          onError={onError}
          onSuccess={onSuccess}
        />
      </div>
    );
  }

  if (selectedMethod === "bank") {
    return (
      <div className="space-y-4">
        <Button variant="ghost" onClick={() => setSelectedMethod(null)} className="mb-4">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Payment Methods
        </Button>
        <BankTransferForm
          amount={amount}
          childId={childId}
          anonymous={anonymous}
          message={message}
          onError={onError}
          onSuccess={onSuccess}
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-xl font-semibold mb-2">Choose Payment Method</h3>
        <p className="text-gray-600">Select your preferred way to donate PKR {formatNumber(amount)}</p>
      </div>

      <div className="grid gap-4">
        <Card className="cursor-pointer hover:shadow-md transition-shadow border-2 hover:border-[#d4af37]" onClick={() => setSelectedMethod("googlepay")}>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-black/5 rounded-lg flex items-center justify-center">
                  <span className="text-sm font-semibold">G Pay</span>
                </div>
                <div>
                  <h4 className="font-semibold">Google Pay</h4>
                  <p className="text-sm text-gray-600">Fast checkout on supported devices</p>
                </div>
              </div>
              <Badge variant="secondary">Wallet</Badge>
            </CardTitle>
          </CardHeader>
        </Card>

        <Card className="cursor-pointer hover:shadow-md transition-shadow border-2 hover:border-[#d4af37]" onClick={() => setSelectedMethod("paypro")}>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <CreditCard className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h4 className="font-semibold">PayPro Gateway</h4>
                  <p className="text-sm text-gray-600">Cards, Mobile Wallets, Bank Transfer</p>
                </div>
              </div>
              <Badge className="bg-green-100 text-green-800">Recommended</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="flex gap-2 text-xs">
              <span className="bg-gray-100 px-2 py-1 rounded">Visa</span>
              <span className="bg-gray-100 px-2 py-1 rounded">Mastercard</span>
              <span className="bg-gray-100 px-2 py-1 rounded">EasyPaisa</span>
              <span className="bg-gray-100 px-2 py-1 rounded">JazzCash</span>
            </div>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-md transition-shadow border-2 hover:border-[#d4af37]" onClick={() => setSelectedMethod("stripe")}>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <CreditCard className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <h4 className="font-semibold">Stripe Payment</h4>
                  <p className="text-sm text-gray-600">International Cards</p>
                </div>
              </div>
              <Badge variant="secondary">Global</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="flex gap-2 text-xs">
              <span className="bg-gray-100 px-2 py-1 rounded">Visa</span>
              <span className="bg-gray-100 px-2 py-1 rounded">Mastercard</span>
              <span className="bg-gray-100 px-2 py-1 rounded">Amex</span>
            </div>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-md transition-shadow border-2 hover:border-[#d4af37]" onClick={() => setSelectedMethod("bank")}>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <Building2 className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h4 className="font-semibold">Direct Bank Transfer</h4>
                  <p className="text-sm text-gray-600">Manual bank transfer</p>
                </div>
              </div>
              <Badge variant="outline">Manual</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <p className="text-xs text-gray-600">Transfer directly to our bank account</p>
          </CardContent>
        </Card>
      </div>

      <div className="flex gap-3">
        <Button variant="outline" onClick={onBack} className="flex-1">
          Back
        </Button>
      </div>
    </div>
  );
}
