import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CreditCard } from "lucide-react";
import { paymentService } from "@/services/paymentService";
import { donationService } from "@/services/donationService";
import { useAuth } from "@/contexts/AuthContext";

interface StripePaymentFormProps {
  amount: number;
  childId: string;
  anonymous: boolean;
  message: string;
  onError: (error: string) => void;
  onSuccess: (data: { client_secret: string, payment_method: "card" }) => void;
}

export default function StripePaymentForm({
  amount,
  childId,
  anonymous,
  message,
  onError,
  onSuccess,
}: StripePaymentFormProps) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [messageState, setMessage] = useState<string | null>(null);
  const [donorInfo, setDonorInfo] = useState({
    name: user?.user_metadata?.full_name || "",
    email: user?.email || "",
  });

  const handlePayment = async () => {
    if (!donorInfo.name || !donorInfo.email) {
      onError("Please fill in all required fields");
      return;
    }

    setLoading(true);

    try {
      const donation = await donationService.createDonation({
        child_id: childId,
        donor_id: user?.id || null,
        amount: amount,
        currency: "USD",
        donor_name: donorInfo.name,
        donor_email: donorInfo.email,
        donor_phone: "",
        payment_status: "pending",
        donation_type: "one-time",
        payment_method: "card",
        anonymous: anonymous,
        message: message,
      });

      if (!donation) {
        throw new Error("Failed to create donation record");
      }

      const paymentIntent = await paymentService.createPaymentIntent({
        amount: amount,
        currency: "USD",
        child_id: childId,
        donor_email: donorInfo.email,
        donor_name: donorInfo.name,
        message: message,
        is_anonymous: anonymous,
        is_recurring: false,
      });

      try {
        onSuccess({
          client_secret: paymentIntent.client_secret,
          payment_method: "card",
        });
      } catch (error) {
        setMessage("An unexpected error occurred. Please try again.");
      }
    } catch (error) {
      console.error("Payment error:", error);
      onError(error instanceof Error ? error.message : "Payment failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CreditCard className="h-5 w-5" />
          Secure Payment - Stripe
        </CardTitle>
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Amount:</span>
          <Badge variant="secondary" className="text-lg font-bold">
            USD {(amount / 280).toFixed(2)}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="donor-name">Full Name *</Label>
          <Input
            id="donor-name"
            type="text"
            placeholder="Enter your full name"
            value={donorInfo.name}
            onChange={(e) => setDonorInfo({ ...donorInfo, name: e.target.value })}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="donor-email">Email Address *</Label>
          <Input
            id="donor-email"
            type="email"
            placeholder="Enter your email"
            value={donorInfo.email}
            onChange={(e) => setDonorInfo({ ...donorInfo, email: e.target.value })}
            required
          />
        </div>

        <Button
          onClick={handlePayment}
          disabled={loading || !donorInfo.name || !donorInfo.email}
          className="w-full"
          size="lg"
        >
          {loading ? "Processing..." : `Donate USD ${(amount / 280).toFixed(2)}`}
        </Button>

        <p className="text-xs text-muted-foreground text-center">
          You will be redirected to Stripe's secure payment page.
          International cards accepted.
        </p>
      </CardContent>
    </Card>
  );
}
