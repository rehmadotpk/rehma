import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  TrendingUp, TrendingDown, Minus, Search, Target, BarChart3, 
  Mail, Settings, Loader2, Plus, Trash2, AlertCircle, CheckCircle2,
  RefreshCw, Calendar, ArrowUp, ArrowDown
} from "lucide-react";
import { seoService, SEOKeyword, SEOReport, SEOSettings } from "@/services/seoService";
import { toast } from "@/hooks/use-toast";
import { formatDate } from "@/lib/dateUtils";

export function SEOManagement() {
  const [activeTab, setActiveTab] = useState("keywords");
  const [keywords, setKeywords] = useState<SEOKeyword[]>([]);
  const [reports, setReports] = useState<SEOReport[]>([]);
  const [settings, setSettings] = useState<SEOSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [newKeyword, setNewKeyword] = useState("");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [keywordsData, reportsData, settingsData] = await Promise.all([
        seoService.getAllKeywords(),
        seoService.getReports(10),
        seoService.getSettings(),
      ]);
      setKeywords(keywordsData);
      setReports(reportsData);
      setSettings(settingsData);
    } catch (error) {
      console.error("Failed to load SEO data:", error);
      toast({
        title: "Error",
        description: "Failed to load SEO data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleAddKeyword = async () => {
    const trimmedKeyword = newKeyword.trim();
    
    if (!trimmedKeyword) {
      toast({
        title: "Invalid Input",
        description: "Please enter a keyword to track",
        variant: "destructive",
      });
      return;
    }

    // Basic validation
    if (trimmedKeyword.length < 2) {
      toast({
        title: "Keyword Too Short",
        description: "Keywords must be at least 2 characters long",
        variant: "destructive",
      });
      return;
    }

    if (trimmedKeyword.length > 200) {
      toast({
        title: "Keyword Too Long",
        description: "Keywords must be less than 200 characters",
        variant: "destructive",
      });
      return;
    }

    try {
      setLoading(true);
      
      // Check if keyword already exists
      const exists = await seoService.checkKeywordExists(trimmedKeyword);
      if (exists) {
        toast({
          title: "Duplicate Keyword",
          description: `"${trimmedKeyword}" is already in your tracking list`,
          variant: "destructive",
        });
        setLoading(false);
        return;
      }

      const newKeywordData = {
        keyword: trimmedKeyword,
        is_active: true,
        search_volume: null,
        difficulty: null,
        current_position: null,
        previous_position: null,
        target_url: null,
      };
      
      await seoService.addKeyword(newKeywordData);
      setNewKeyword("");
      await loadData();
      
      toast({
        title: "Success",
        description: `Keyword "${trimmedKeyword}" added successfully`,
      });
    } catch (error) {
      console.error("Failed to add keyword:", error);
      
      const errorMessage = error instanceof Error ? error.message : "Unknown error occurred";
      
      if (errorMessage.includes("DUPLICATE_KEYWORD")) {
        toast({
          title: "Duplicate Keyword",
          description: errorMessage.replace("DUPLICATE_KEYWORD: ", ""),
          variant: "destructive",
        });
      } else if (errorMessage.includes("23505")) {
        toast({
          title: "Duplicate Keyword",
          description: `This keyword already exists in your tracking list`,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error",
          description: `Failed to add keyword: ${errorMessage}`,
          variant: "destructive",
        });
      }
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteKeyword = async (id: string) => {
    try {
      await seoService.deleteKeyword(id);
      await loadData();
      toast({
        title: "Success",
        description: "Keyword deleted successfully",
      });
    } catch (error) {
      console.error("Failed to delete keyword:", error);
      toast({
        title: "Error",
        description: "Failed to delete keyword",
        variant: "destructive",
      });
    }
  };

  const handleToggleKeyword = async (id: string, isActive: boolean) => {
    try {
      await seoService.updateKeyword(id, { is_active: isActive });
      await loadData();
      toast({
        title: "Success",
        description: `Keyword ${isActive ? "activated" : "deactivated"}`,
      });
    } catch (error) {
      console.error("Failed to toggle keyword:", error);
      toast({
        title: "Error",
        description: "Failed to update keyword",
        variant: "destructive",
      });
    }
  };

  const handleRunKeywordResearch = async () => {
    try {
      setProcessing(true);
      const newKeywords = await seoService.performKeywordResearch();
      
      for (const keyword of newKeywords) {
        const newKeywordData = {
          keyword,
          is_active: true,
          // Add missing properties to satisfy the type
          search_volume: null,
          difficulty: null,
          current_position: null,
          previous_position: null,
          target_url: null,
        };
        await seoService.addKeyword(newKeywordData);
      }

      await loadData();
      toast({
        title: "Success",
        description: `Found and added ${newKeywords.length} new keywords`,
      });
    } catch (error) {
      console.error("Failed to run keyword research:", error);
      toast({
        title: "Error",
        description: "Failed to run keyword research",
        variant: "destructive",
      });
    } finally {
      setProcessing(false);
    }
  };

  const handleCheckRankings = async () => {
    try {
      setProcessing(true);
      const result = await seoService.checkAllRankings();
      await loadData();
      toast({
        title: "Rankings Updated",
        description: `Successfully checked ${result.success} keywords${result.failed > 0 ? `, ${result.failed} failed` : ""}`,
      });
    } catch (error) {
      console.error("Failed to check rankings:", error);
      toast({
        title: "Error",
        description: "Failed to check rankings",
        variant: "destructive",
      });
    } finally {
      setProcessing(false);
    }
  };

  const handleGenerateReport = async () => {
    try {
      setProcessing(true);
      await seoService.generateDailyReport();
      await loadData();
      toast({
        title: "Success",
        description: "Daily report generated successfully",
      });
    } catch (error) {
      console.error("Failed to generate report:", error);
      toast({
        title: "Error",
        description: "Failed to generate report",
        variant: "destructive",
      });
    } finally {
      setProcessing(false);
    }
  };

  const handleRunAutomation = async () => {
    try {
      setProcessing(true);
      const resp = await fetch("/api/seo/run-daily", {
        method: "POST",
        headers: { "Content-Type": "application/json" }
      });
      if (!resp.ok) {
        const data = await resp.json().catch(() => ({}));
        throw new Error(data?.error || "Automation run failed");
      }
      await loadData();
      toast({
        title: "Automation Completed",
        description: "Keyword research, rankings, and report have been processed."
      });
    } catch (error) {
      console.error("Automation error:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to run automation",
        variant: "destructive"
      });
    } finally {
      setProcessing(false);
    }
  };

  const handleUpdateSettings = async (updates: Partial<SEOSettings>) => {
    try {
      await seoService.updateSettings(updates);
      await loadData();
      toast({
        title: "Success",
        description: "Settings updated successfully",
      });
    } catch (error) {
      console.error("Failed to update settings:", error);
      toast({
        title: "Error",
        description: "Failed to update settings",
        variant: "destructive",
      });
    }
  };

  const getRankingTrend = (keyword: SEOKeyword) => {
    if (!keyword.current_position || !keyword.previous_position) {
      return <Minus className="h-4 w-4 text-muted-foreground" />;
    }
    if (keyword.current_position < keyword.previous_position) {
      return <TrendingUp className="h-4 w-4 text-green-500" />;
    }
    if (keyword.current_position > keyword.previous_position) {
      return <TrendingDown className="h-4 w-4 text-red-500" />;
    }
    return <Minus className="h-4 w-4 text-muted-foreground" />;
  };

  const getPositionBadge = (position: number | null) => {
    if (!position) return <Badge variant="secondary">Not Ranked</Badge>;
    if (position <= 3) return <Badge className="bg-green-500">#{position}</Badge>;
    if (position <= 10) return <Badge className="bg-blue-500">#{position}</Badge>;
    if (position <= 20) return <Badge className="bg-yellow-500">#{position}</Badge>;
    return <Badge variant="secondary">#{position}</Badge>;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const activeKeywords = keywords.filter(k => k.is_active).length;
  const avgPosition = keywords.length > 0 
    ? keywords.reduce((sum, k) => sum + (k.current_position || 0), 0) / keywords.filter(k => k.current_position).length 
    : 0;
  const topRankings = keywords.filter(k => k.current_position && k.current_position <= 10).length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">SEO Management & Automation</h2>
          <p className="text-muted-foreground">Advanced SEO with automated keyword research and ranking tracking</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={handleCheckRankings} disabled={processing} variant="outline">
            {processing ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <RefreshCw className="h-4 w-4 mr-2" />}
            Check Rankings
          </Button>
          <Button onClick={handleGenerateReport} disabled={processing}>
            {processing ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Mail className="h-4 w-4 mr-2" />}
            Generate Report
          </Button>
          <Button onClick={handleRunAutomation} disabled={processing} variant="secondary">
            {processing ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <RefreshCw className="h-4 w-4 mr-2" />}
            Run Automation
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Total Keywords</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{keywords.length}</div>
            <p className="text-xs text-muted-foreground">{activeKeywords} active</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Top 10 Rankings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{topRankings}</div>
            <p className="text-xs text-muted-foreground">First page results</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Average Position</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{avgPosition > 0 ? avgPosition.toFixed(1) : "-"}</div>
            <p className="text-xs text-muted-foreground">Across all keywords</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Automation Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              {settings?.auto_ranking_check ? (
                <CheckCircle2 className="h-5 w-5 text-green-500" />
              ) : (
                <AlertCircle className="h-5 w-5 text-yellow-500" />
              )}
              <span className="text-sm font-medium">
                {settings?.auto_ranking_check ? "Active" : "Inactive"}
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="keywords">
            <Target className="h-4 w-4 mr-2" />
            Keywords
          </TabsTrigger>
          <TabsTrigger value="reports">
            <BarChart3 className="h-4 w-4 mr-2" />
            Reports
          </TabsTrigger>
          <TabsTrigger value="settings">
            <Settings className="h-4 w-4 mr-2" />
            Settings
          </TabsTrigger>
        </TabsList>

        <TabsContent value="keywords" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Keyword Tracking</CardTitle>
                  <CardDescription>Monitor and manage your SEO keywords</CardDescription>
                </div>
                <Button onClick={handleRunKeywordResearch} disabled={processing}>
                  {processing ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Search className="h-4 w-4 mr-2" />}
                  Auto Research
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Input
                  placeholder="Add new keyword..."
                  value={newKeyword}
                  onChange={(e) => setNewKeyword(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      handleAddKeyword();
                    }
                  }}
                  disabled={loading}
                  maxLength={200}
                />
                <Button 
                  onClick={handleAddKeyword} 
                  disabled={!newKeyword.trim() || loading}
                >
                  {loading ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Plus className="h-4 w-4 mr-2" />
                  )}
                  Add
                </Button>
              </div>

              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Keyword</TableHead>
                      <TableHead>Position</TableHead>
                      <TableHead>Trend</TableHead>
                      <TableHead>Search Volume</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {keywords.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                          No keywords yet. Add your first keyword above or run auto research.
                        </TableCell>
                      </TableRow>
                    ) : (
                      keywords.map((keyword) => (
                        <TableRow key={keyword.id}>
                          <TableCell className="font-medium">{keyword.keyword}</TableCell>
                          <TableCell>{getPositionBadge(keyword.current_position)}</TableCell>
                          <TableCell>{getRankingTrend(keyword)}</TableCell>
                          <TableCell>{keyword.search_volume || "-"}</TableCell>
                          <TableCell>
                            <Switch
                              checked={keyword.is_active}
                              onCheckedChange={(checked) => handleToggleKeyword(keyword.id, checked)}
                            />
                          </TableCell>
                          <TableCell className="text-right">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteKeyword(keyword.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>SEO Reports</CardTitle>
              <CardDescription>Historical performance reports</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {reports.length === 0 ? (
                  <div className="text-center text-muted-foreground py-8">
                    No reports yet. Generate your first report above.
                  </div>
                ) : (
                  reports.map((report) => (
                    <Card key={report.id}>
                      <CardContent className="pt-6">
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium">{formatDate(report.report_date, "yyyy-MM-dd")}</span>
                          </div>
                          {report.sent_at && (
                            <Badge variant="secondary">
                              <Mail className="h-3 w-3 mr-1" />
                              Sent
                            </Badge>
                          )}
                        </div>
                        <div className="grid grid-cols-4 gap-4">
                          <div>
                            <p className="text-sm text-muted-foreground">Total Keywords</p>
                            <p className="text-2xl font-bold">{report.total_keywords}</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Improved</p>
                            <p className="text-2xl font-bold text-green-500 flex items-center">
                              <ArrowUp className="h-4 w-4 mr-1" />
                              {report.improved_keywords}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Declined</p>
                            <p className="text-2xl font-bold text-red-500 flex items-center">
                              <ArrowDown className="h-4 w-4 mr-1" />
                              {report.declined_keywords}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Avg Position</p>
                            <p className="text-2xl font-bold">{report.average_position.toFixed(1)}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Automation Settings</CardTitle>
              <CardDescription>Configure automated SEO features</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Automation runs daily at midnight UTC. Email reports are sent to the configured address.
                </AlertDescription>
              </Alert>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Auto Keyword Research</Label>
                    <p className="text-sm text-muted-foreground">Automatically discover new relevant keywords</p>
                  </div>
                  <Switch
                    checked={settings?.auto_keyword_research || false}
                    onCheckedChange={(checked) => handleUpdateSettings({ auto_keyword_research: checked })}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Auto Ranking Check</Label>
                    <p className="text-sm text-muted-foreground">Daily automated ranking position updates</p>
                  </div>
                  <Switch
                    checked={settings?.auto_ranking_check || false}
                    onCheckedChange={(checked) => handleUpdateSettings({ auto_ranking_check: checked })}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Report Email Address</Label>
                  <Input
                    type="email"
                    placeholder="admin@example.com"
                    value={settings?.daily_report_email || ""}
                    onChange={(e) => handleUpdateSettings({ daily_report_email: e.target.value })}
                  />
                  <p className="text-xs text-muted-foreground">
                    Daily SEO reports will be sent to this email
                  </p>
                </div>

                <div className="space-y-2">
                  <Label>Target Keywords Count</Label>
                  <Input
                    type="number"
                    value={settings?.target_keywords_count || 50}
                    onChange={(e) => handleUpdateSettings({ target_keywords_count: parseInt(e.target.value) })}
                  />
                  <p className="text-xs text-muted-foreground">
                    Maximum number of keywords to track
                  </p>
                </div>

                <div className="space-y-2">
                  <Label>Minimum Search Volume</Label>
                  <Input
                    type="number"
                    value={settings?.min_search_volume || 100}
                    onChange={(e) => handleUpdateSettings({ min_search_volume: parseInt(e.target.value) })}
                  />
                  <p className="text-xs text-muted-foreground">
                    Only add keywords with this minimum monthly search volume
                  </p>
                </div>

                <div className="space-y-2">
                  <Label>Maximum Difficulty</Label>
                  <Input
                    type="number"
                    value={settings?.max_difficulty || 70}
                    onChange={(e) => handleUpdateSettings({ max_difficulty: parseInt(e.target.value) })}
                  />
                  <p className="text-xs text-muted-foreground">
                    Only add keywords below this difficulty score (1-100)
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
