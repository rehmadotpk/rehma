import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Plus, Edit, Trash2, BarChart3, Eye, MousePointer, TrendingUp } from "lucide-react";

interface BannerAnalytics {
  impressions: number;
  clicks: number;
  ctr: number;
  revenue: number;
  conversions: number;
}

interface Banner {
  id: string;
  title: string;
  description: string;
  image: string;
  ctaText: string;
  ctaLink: string;
  position: "hero" | "sidebar" | "between-sections" | "footer";
  priority: number;
  isActive: boolean;
  startDate: string;
  endDate: string;
  sponsor: string;
  analytics: BannerAnalytics;
  bannerType: "image" | "video" | "interactive";
  backgroundColor?: string;
  textColor?: string;
}

export function BannerManagement() {
  const [banners, setBanners] = useState<Banner[]>([
    {
      id: "1",
      title: "Support Special Needs Education",
      description: "Join hands with leading NGOs to provide quality education",
      image: "https://images.unsplash.com/photo-1497486751825-1233686d5d80?w=800&h=400&fit=crop",
      ctaText: "Learn More",
      ctaLink: "/ngos",
      position: "hero",
      priority: 1,
      isActive: true,
      startDate: "2025-01-01",
      endDate: "2025-03-31",
      sponsor: "UNESCO Pakistan",
      analytics: {
        impressions: 45230,
        clicks: 1847,
        ctr: 4.08,
        revenue: 12500,
        conversions: 234
      },
      bannerType: "image",
      backgroundColor: "#3B82F6",
      textColor: "#FFFFFF"
    }
  ]);

  const [selectedBanner, setSelectedBanner] = useState<Banner | null>(null);
  const [isCreateMode, setIsCreateMode] = useState(false);

  const handleCreateBanner = () => {
    setSelectedBanner({
      id: "",
      title: "",
      description: "",
      image: "",
      ctaText: "",
      ctaLink: "",
      position: "hero",
      priority: 10,
      isActive: false,
      startDate: new Date().toISOString().split("T")[0],
      endDate: new Date(new Date().setDate(new Date().getDate() + 30)).toISOString().split("T")[0],
      sponsor: "",
      analytics: {
        impressions: 0,
        clicks: 0,
        ctr: 0,
        revenue: 0,
        conversions: 0,
      },
      bannerType: "image",
    });
    setIsCreateMode(true);
  };

  const handleSaveBanner = (banner: Banner) => {
    if (isCreateMode) {
      const newBanner = { ...banner, id: Date.now().toString() };
      setBanners(prev => [...prev, newBanner]);
    } else {
      setBanners(prev => prev.map(b => b.id === banner.id ? banner : b));
    }
    setSelectedBanner(null);
    setIsCreateMode(false);
  };

  const handleDeleteBanner = (id: string) => {
    setBanners(prev => prev.filter(b => b.id !== id));
  };

  const toggleBannerStatus = (id: string) => {
    setBanners(prev => prev.map(b => 
      b.id === id ? { ...b, isActive: !b.isActive } : b
    ));
  };

  const getPositionColor = (position: string) => {
    switch (position) {
      case "hero": return "bg-blue-100 text-blue-800";
      case "sidebar": return "bg-green-100 text-green-800";
      case "between-sections": return "bg-purple-100 text-purple-800";
      case "footer": return "bg-orange-100 text-orange-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Banner Management</h1>
          <p className="text-gray-600">Manage advertising banners and track performance</p>
        </div>
        <Button onClick={handleCreateBanner} className="bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4 mr-2" />
          Create Banner
        </Button>
      </div>

      {/* Analytics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Eye className="w-8 h-8 text-blue-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Impressions</p>
                <p className="text-2xl font-bold text-gray-900">
                  {banners.reduce((sum, b) => sum + b.analytics.impressions, 0).toLocaleString()}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <MousePointer className="w-8 h-8 text-green-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Clicks</p>
                <p className="text-2xl font-bold text-gray-900">
                  {banners.reduce((sum, b) => sum + b.analytics.clicks, 0).toLocaleString()}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <TrendingUp className="w-8 h-8 text-purple-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Average CTR</p>
                <p className="text-2xl font-bold text-gray-900">
                  {(banners.reduce((sum, b) => sum + b.analytics.ctr, 0) / banners.length).toFixed(2)}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <BarChart3 className="w-8 h-8 text-orange-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Revenue</p>
                <p className="text-2xl font-bold text-gray-900">
                  Rs {banners.reduce((sum, b) => sum + b.analytics.revenue, 0).toLocaleString()}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Banner List */}
      <div className="grid gap-6">
        {banners.map((banner) => (
          <Card key={banner.id} className="overflow-hidden">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <h3 className="text-lg font-semibold">{banner.title}</h3>
                    <Badge className={getPositionColor(banner.position)}>
                      {banner.position.replace("-", " ").toUpperCase()}
                    </Badge>
                    <Badge variant={banner.isActive ? "default" : "secondary"}>
                      {banner.isActive ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                  
                  <p className="text-gray-600 mb-3">{banner.description}</p>
                  
                  <div className="flex items-center gap-6 text-sm text-gray-500">
                    <span>Sponsor: {banner.sponsor}</span>
                    <span>Priority: {banner.priority}</span>
                    <span>Start: {banner.startDate}</span>
                    <span>End: {banner.endDate}</span>
                  </div>

                  {/* Analytics */}
                  <div className="grid grid-cols-4 gap-4 mt-4 p-4 bg-gray-50 rounded-lg">
                    <div className="text-center">
                      <p className="text-lg font-semibold text-blue-600">
                        {banner.analytics.impressions.toLocaleString()}
                      </p>
                      <p className="text-xs text-gray-600">Impressions</p>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-semibold text-green-600">
                        {banner.analytics.clicks.toLocaleString()}
                      </p>
                      <p className="text-xs text-gray-600">Clicks</p>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-semibold text-purple-600">
                        {banner.analytics.ctr}%
                      </p>
                      <p className="text-xs text-gray-600">CTR</p>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-semibold text-orange-600">
                        Rs {banner.analytics.revenue.toLocaleString()}
                      </p>
                      <p className="text-xs text-gray-600">Revenue</p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 ml-6">
                  <Switch
                    checked={banner.isActive}
                    onCheckedChange={() => toggleBannerStatus(banner.id)}
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSelectedBanner(banner);
                      setIsCreateMode(false);
                    }}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDeleteBanner(banner.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Banner Form Dialog */}
      <Dialog open={!!selectedBanner} onOpenChange={() => setSelectedBanner(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {isCreateMode ? "Create New Banner" : "Edit Banner"}
            </DialogTitle>
          </DialogHeader>
          
          {selectedBanner && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    value={selectedBanner.title}
                    onChange={(e) => setSelectedBanner({
                      ...selectedBanner,
                      title: e.target.value
                    })}
                  />
                </div>
                <div>
                  <Label htmlFor="sponsor">Sponsor</Label>
                  <Input
                    id="sponsor"
                    value={selectedBanner.sponsor}
                    onChange={(e) => setSelectedBanner({
                      ...selectedBanner,
                      sponsor: e.target.value
                    })}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={selectedBanner.description}
                  onChange={(e) => setSelectedBanner({
                    ...selectedBanner,
                    description: e.target.value
                  })}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="position">Position</Label>
                  <Select
                    value={selectedBanner.position}
                    onValueChange={(value: "hero" | "sidebar" | "between-sections" | "footer") => setSelectedBanner({
                      ...selectedBanner,
                      position: value
                    })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hero">Hero</SelectItem>
                      <SelectItem value="sidebar">Sidebar</SelectItem>
                      <SelectItem value="between-sections">Between Sections</SelectItem>
                      <SelectItem value="footer">Footer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="priority">Priority</Label>
                  <Input
                    id="priority"
                    type="number"
                    value={selectedBanner.priority}
                    onChange={(e) => setSelectedBanner({
                      ...selectedBanner,
                      priority: parseInt(e.target.value)
                    })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="ctaText">CTA Text</Label>
                  <Input
                    id="ctaText"
                    value={selectedBanner.ctaText}
                    onChange={(e) => setSelectedBanner({
                      ...selectedBanner,
                      ctaText: e.target.value
                    })}
                  />
                </div>
                <div>
                  <Label htmlFor="ctaLink">CTA Link</Label>
                  <Input
                    id="ctaLink"
                    value={selectedBanner.ctaLink}
                    onChange={(e) => setSelectedBanner({
                      ...selectedBanner,
                      ctaLink: e.target.value
                    })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="startDate">Start Date</Label>
                  <Input
                    id="startDate"
                    type="date"
                    value={selectedBanner.startDate}
                    onChange={(e) => setSelectedBanner({
                      ...selectedBanner,
                      startDate: e.target.value
                    })}
                  />
                </div>
                <div>
                  <Label htmlFor="endDate">End Date</Label>
                  <Input
                    id="endDate"
                    type="date"
                    value={selectedBanner.endDate}
                    onChange={(e) => setSelectedBanner({
                      ...selectedBanner,
                      endDate: e.target.value
                    })}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="image">Image URL</Label>
                <Input
                  id="image"
                  value={selectedBanner.image}
                  onChange={(e) => setSelectedBanner({
                    ...selectedBanner,
                    image: e.target.value
                  })}
                />
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  id="isActive"
                  checked={selectedBanner.isActive}
                  onCheckedChange={(checked) => setSelectedBanner({
                    ...selectedBanner,
                    isActive: checked
                  })}
                />
                <Label htmlFor="isActive">Active</Label>
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <Button variant="outline" onClick={() => setSelectedBanner(null)}>
                  Cancel
                </Button>
                <Button onClick={() => handleSaveBanner(selectedBanner)}>
                  {isCreateMode ? "Create" : "Save"} Banner
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
