import { useState, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DatePickerWithRange } from "@/components/ui/date-picker";
import { Progress } from "@/components/ui/progress";
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  Heart, 
  Download,
  DollarSign,
  Target,
  Activity,
  PieChart,
  LineChart
} from "lucide-react";
import { analyticsService, AnalyticsData } from "@/services/analyticsService";
import { useCurrency } from "@/contexts/CurrencyContext";
import { useToast } from "@/hooks/use-toast";
import { DateRange } from "react-day-picker";

export function AdvancedAnalytics() {
  const { formatPrice } = useCurrency();
  const { toast } = useToast();
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: new Date(Date.now() - 365 * 24 * 60 * 60 * 1000),
    to: new Date()
  });
  const [activeTab, setActiveTab] = useState("overview");
  const [exportFormat, setExportFormat] = useState<'csv' | 'json'>('csv');

  const loadAnalyticsData = useCallback(async () => {
    setLoading(true);
    try {
      const apiDateRange = dateRange?.from ? {
        startDate: dateRange.from.toISOString(),
        endDate: dateRange.to ? dateRange.to.toISOString() : new Date().toISOString(),
      } : undefined;
      const data = await analyticsService.getAnalyticsData(apiDateRange);
      setAnalyticsData(data);
    } catch (error) {
      console.error('Failed to load analytics:', error);
      toast({
        title: "Error",
        description: "Failed to load analytics data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  }, [dateRange, toast]);

  useEffect(() => {
    loadAnalyticsData();
  }, [loadAnalyticsData]);

  const handleExportData = async () => {
    try {
      const apiDateRange = dateRange?.from ? {
        startDate: dateRange.from.toISOString(),
        endDate: dateRange.to ? dateRange.to.toISOString() : new Date().toISOString(),
      } : undefined;
      const exportData = await analyticsService.exportAnalyticsData(exportFormat, apiDateRange);
      const blob = new Blob([exportData], { 
        type: exportFormat === 'csv' ? 'text/csv' : 'application/json' 
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `rehma-analytics-${new Date().toISOString().split('T')[0]}.${exportFormat}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast({
        title: "Success",
        description: "Analytics data exported successfully"
      });
    } catch (error) {
      console.error("Failed to export data", error);
      toast({
        title: "Error",
        description: "Failed to export analytics data",
        variant: "destructive"
      });
    }
  };

  if (loading || !analyticsData) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-gray-200 rounded mb-2"></div>
                <div className="h-8 bg-gray-200 rounded mb-2"></div>
                <div className="h-3 bg-gray-200 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const { donations, children, users, performance } = analyticsData;

  return (
    <div className="space-y-6">
      {/* Header with Controls */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-[#101c2c]">Advanced Analytics</h2>
          <p className="text-gray-600">Comprehensive insights and performance metrics</p>
        </div>
        <div className="flex items-center space-x-3">
          <DatePickerWithRange date={dateRange} setDate={setDateRange} />
          <Select value={exportFormat} onValueChange={(value: 'csv' | 'json') => setExportFormat(value)}>
            <SelectTrigger className="w-24">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="csv">CSV</SelectItem>
              <SelectItem value="json">JSON</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={handleExportData} variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Revenue</p>
                <p className="text-2xl font-bold text-green-600">
                  {formatPrice(donations.totalAmount)}
                </p>
                <div className="flex items-center mt-2">
                  <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
                  <span className="text-sm text-green-600">+12.5% vs last period</span>
                </div>
              </div>
              <div className="p-3 bg-green-100 rounded-full">
                <DollarSign className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Children</p>
                <p className="text-2xl font-bold text-blue-600">{children.totalActive}</p>
                <div className="flex items-center mt-2">
                  <Target className="w-4 h-4 text-blue-500 mr-1" />
                  <span className="text-sm text-blue-600">{children.completionRate.toFixed(1)}% completion rate</span>
                </div>
              </div>
              <div className="p-3 bg-blue-100 rounded-full">
                <Heart className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Users</p>
                <p className="text-2xl font-bold text-purple-600">{users.totalUsers}</p>
                <div className="flex items-center mt-2">
                  <Users className="w-4 h-4 text-purple-500 mr-1" />
                  <span className="text-sm text-purple-600">+{users.newUsersThisMonth} this month</span>
                </div>
              </div>
              <div className="p-3 bg-purple-100 rounded-full">
                <Users className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Conversion Rate</p>
                <p className="text-2xl font-bold text-orange-600">{performance.conversionRate}%</p>
                <div className="flex items-center mt-2">
                  <Activity className="w-4 h-4 text-orange-500 mr-1" />
                  <span className="text-sm text-orange-600">Platform efficiency</span>
                </div>
              </div>
              <div className="p-3 bg-orange-100 rounded-full">
                <BarChart3 className="w-6 h-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Analytics Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 bg-white shadow-sm border">
          <TabsTrigger value="overview" className="data-[state=active]:bg-[#101c2c] data-[state=active]:text-white">
            Overview
          </TabsTrigger>
          <TabsTrigger value="donations" className="data-[state=active]:bg-[#101c2c] data-[state=active]:text-white">
            Donations
          </TabsTrigger>
          <TabsTrigger value="children" className="data-[state=active]:bg-[#101c2c] data-[state=active]:text-white">
            Children
          </TabsTrigger>
          <TabsTrigger value="users" className="data-[state=active]:bg-[#101c2c] data-[state=active]:text-white">
            Users
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Monthly Trend */}
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <LineChart className="w-5 h-5 mr-2" />
                  Monthly Donation Trend
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {donations.monthlyTrend.slice(-6).map((month) => (
                    <div key={month.month} className="flex items-center justify-between">
                      <span className="text-sm font-medium">{month.month}</span>
                      <div className="flex items-center space-x-3">
                        <div className="w-32">
                          <Progress 
                            value={(month.amount / Math.max(...donations.monthlyTrend.map(m => m.amount))) * 100} 
                            className="h-2"
                          />
                        </div>
                        <span className="text-sm font-semibold text-green-600 w-20 text-right">
                          {formatPrice(month.amount)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Performance Metrics */}
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Activity className="w-5 h-5 mr-2" />
                  Performance Metrics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Platform Growth Rate</span>
                    <Badge className="bg-green-100 text-green-800">
                      +{performance.platformGrowthRate}%
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">User Retention Rate</span>
                    <Badge className="bg-blue-100 text-blue-800">
                      {users.retentionRate}%
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Avg. Time to First Donation</span>
                    <Badge className="bg-purple-100 text-purple-800">
                      {performance.averageTimeToFirstDonation} days
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Success Stories</span>
                    <Badge className="bg-orange-100 text-orange-800">
                      {performance.successStories}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="donations" className="space-y-6">
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Top Donors */}
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Top Donors</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {donations.topDonors.slice(0, 10).map((donor, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                          {index + 1}
                        </div>
                        <div>
                          <p className="font-medium">{donor.name}</p>
                          <p className="text-sm text-gray-500">{donor.donations} donations</p>
                        </div>
                      </div>
                      <span className="font-semibold text-green-600">
                        {formatPrice(donor.amount)}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Payment Methods */}
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <PieChart className="w-5 h-5 mr-2" />
                  Payment Methods
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {donations.paymentMethods.map((method) => (
                    <div key={method.method} className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm font-medium capitalize">
                          {method.method.replace('_', ' ')}
                        </span>
                        <span className="text-sm text-gray-600">
                          {method.percentage.toFixed(1)}%
                        </span>
                      </div>
                      <Progress value={method.percentage} className="h-2" />
                      <div className="text-right">
                        <span className="text-sm font-semibold text-green-600">
                          {formatPrice(method.amount)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="children" className="space-y-6">
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Urgency Distribution */}
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Urgency Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {children.urgencyDistribution.map((urgency) => (
                    <div key={urgency.urgency} className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm font-medium capitalize">{urgency.urgency} Priority</span>
                        <span className="text-sm text-gray-600">{urgency.count} children</span>
                      </div>
                      <Progress value={urgency.percentage} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Location Distribution */}
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Geographic Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {children.locationDistribution.slice(0, 8).map((location) => (
                    <div key={location.location} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium">{location.location}</p>
                        <p className="text-sm text-gray-500">{location.count} children</p>
                      </div>
                      <span className="font-semibold text-blue-600">
                        {formatPrice(location.amount)}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="users" className="space-y-6">
          <div className="grid lg:grid-cols-2 gap-6">
            {/* User Roles */}
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>User Distribution by Role</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {users.usersByRole.map((role) => (
                    <div key={role.role} className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm font-medium capitalize">{role.role}s</span>
                        <span className="text-sm text-gray-600">{role.count} users</span>
                      </div>
                      <Progress value={role.percentage} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Engagement Metrics */}
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Engagement Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <span className="text-sm font-medium">Avg. Session Time</span>
                    <Badge className="bg-blue-100 text-blue-800">
                      {users.engagementMetrics.averageSessionTime} min
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <span className="text-sm font-medium">Avg. Donations per User</span>
                    <Badge className="bg-green-100 text-green-800">
                      {users.engagementMetrics.averageDonationsPerUser}
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <span className="text-sm font-medium">Return Visitor Rate</span>
                    <Badge className="bg-purple-100 text-purple-800">
                      {users.engagementMetrics.returnVisitorRate}%
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
