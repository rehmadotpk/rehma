import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CreditCard, Shield, Check, AlertCircle, Loader2 } from "lucide-react";
import { paymentGatewayService, PaymentGateway } from "@/services/paymentGatewayService";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";
import { Separator } from "@/components/ui/separator";
import { Copy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export function PaymentGatewayManagement() {
  const { user } = useAuth();
  const [gateways, setGateways] = useState<PaymentGateway[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [testing, setTesting] = useState<string | null>(null);

  const [formData, setFormData] = useState<Record<string, {
    apiKey: string;
    apiSecret: string;
    webhookSecret: string;
  }>>({});

  const { toast: toastUtil } = useToast();

  const copyToClipboard = async (text: string, label?: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toastUtil({
        title: "Copied",
        description: label ? `${label} copied to clipboard` : "Copied to clipboard",
      });
    } catch {
      toastUtil({
        title: "Copy failed",
        description: "Could not copy to clipboard",
        variant: "destructive",
      });
    }
  };

  const testGateway = async (name: string) => {
    try {
      const result = await paymentGatewayService.testConnection(name);
      toastUtil({
        title: result.success ? "Connection Successful" : "Connection Failed",
        description: result.message,
        variant: result.success ? "default" : "destructive",
      });
    } catch (e) {
      toastUtil({
        title: "Test Failed",
        description: e instanceof Error ? e.message : "Unknown error",
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    loadGateways();
  }, []);

  const loadGateways = async () => {
    try {
      setLoading(true);
      const data = await paymentGatewayService.getAllGateways();
      setGateways(data);
      
      const initialFormData: typeof formData = {};
      data.forEach((gateway) => {
        initialFormData[gateway.gateway_name] = {
          apiKey: gateway.api_key || "",
          apiSecret: gateway.api_secret || "",
          webhookSecret: gateway.webhook_secret || "",
        };
      });
      setFormData(initialFormData);
    } catch (error) {
      console.error("Failed to load payment gateways:", error);
      toast({
        title: "Error",
        description: "Failed to load payment gateways",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleToggleEnabled = async (gatewayName: string, isEnabled: boolean) => {
    if (!user) return;
    
    try {
      await paymentGatewayService.toggleGateway(gatewayName, isEnabled, user.id);
      setGateways(gateways.map(g => 
        g.gateway_name === gatewayName ? { ...g, is_enabled: isEnabled } : g
      ));
      toast({
        title: "Success",
        description: `${gatewayName} ${isEnabled ? "enabled" : "disabled"}`,
      });
    } catch (error) {
      console.error("Failed to toggle gateway:", error);
      toast({
        title: "Error",
        description: "Failed to update gateway status",
        variant: "destructive",
      });
    }
  };

  const handleToggleTestMode = async (gatewayName: string, isTestMode: boolean) => {
    if (!user) return;
    
    try {
      await paymentGatewayService.toggleTestMode(gatewayName, isTestMode, user.id);
      setGateways(gateways.map(g => 
        g.gateway_name === gatewayName ? { ...g, is_test_mode: isTestMode } : g
      ));
      toast({
        title: "Success",
        description: `${gatewayName} switched to ${isTestMode ? "test" : "live"} mode`,
      });
    } catch (error) {
      console.error("Failed to toggle test mode:", error);
      toast({
        title: "Error",
        description: "Failed to update test mode",
        variant: "destructive",
      });
    }
  };

  const handleSaveApiKeys = async (gatewayName: string) => {
    if (!user) return;
    
    try {
      setSaving(gatewayName);
      const data = formData[gatewayName];
      await paymentGatewayService.updateApiKeys(
        gatewayName,
        data.apiKey,
        data.apiSecret,
        data.webhookSecret || null,
        user.id
      );
      await loadGateways();
      toast({
        title: "Success",
        description: `${gatewayName} API keys saved successfully`,
      });
    } catch (error) {
      console.error("Failed to save API keys:", error);
      toast({
        title: "Error",
        description: "Failed to save API keys",
        variant: "destructive",
      });
    } finally {
      setSaving(null);
    }
  };

  const handleTestConnection = async (gatewayName: string) => {
    try {
      setTesting(gatewayName);
      const result = await paymentGatewayService.testConnection(gatewayName);
      toast({
        title: result.success ? "Connection Test Successful" : "Connection Test Failed",
        description: result.message,
        variant: result.success ? "default" : "destructive",
      });
    } catch (error) {
      console.error("Failed to test connection:", error);
      toast({
        title: "Error",
        description: "Failed to test connection",
        variant: "destructive",
      });
    } finally {
      setTesting(null);
    }
  };

  const getGatewayIcon = (name: string) => {
    switch (name) {
      case "stripe": return "💳";
      case "paypal": return "🅿️";
      case "paypro": return "💰";
      default: return "💵";
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Payment Gateway Management</h2>
        <p className="text-muted-foreground">Configure and manage payment gateway integrations</p>
      </div>

      <Tabs defaultValue={gateways[0]?.gateway_name || "stripe"} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          {gateways.map((gateway) => (
            <TabsTrigger key={gateway.gateway_name} value={gateway.gateway_name} className="capitalize">
              {getGatewayIcon(gateway.gateway_name)} {gateway.gateway_name}
            </TabsTrigger>
          ))}
        </TabsList>

        {gateways.map((gateway) => (
          <TabsContent key={gateway.gateway_name} value={gateway.gateway_name}>
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="text-3xl">{getGatewayIcon(gateway.gateway_name)}</div>
                    <div>
                      <CardTitle className="capitalize">{gateway.gateway_name}</CardTitle>
                      <CardDescription>Configure {gateway.gateway_name} payment integration</CardDescription>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <Badge variant={gateway.is_test_mode ? "secondary" : "default"}>
                      {gateway.is_test_mode ? "Test Mode" : "Live Mode"}
                    </Badge>
                    <Badge variant={gateway.is_enabled ? "default" : "secondary"}>
                      {gateway.is_enabled ? <><Check className="h-3 w-3 mr-1" /> Enabled</> : "Disabled"}
                    </Badge>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-6">
                <Alert>
                  <Shield className="h-4 w-4" />
                  <AlertDescription>
                    API keys are stored securely and encrypted. Never share your secret keys publicly.
                  </AlertDescription>
                </Alert>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Enable Gateway</Label>
                      <p className="text-sm text-muted-foreground">Allow customers to pay using {gateway.gateway_name}</p>
                    </div>
                    <Switch
                      checked={gateway.is_enabled}
                      onCheckedChange={(checked) => handleToggleEnabled(gateway.gateway_name, checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Test Mode</Label>
                      <p className="text-sm text-muted-foreground">Use test API keys for development</p>
                    </div>
                    <Switch
                      checked={gateway.is_test_mode}
                      onCheckedChange={(checked) => handleToggleTestMode(gateway.gateway_name, checked)}
                    />
                  </div>
                </div>

                <div className="space-y-4 border-t pt-4">
                  <h3 className="font-semibold">API Configuration</h3>

                  <div className="space-y-2">
                    <Label>API Key / Publishable Key</Label>
                    <Input
                      type="password"
                      placeholder="pk_test_..."
                      value={formData[gateway.gateway_name]?.apiKey || ""}
                      onChange={(e) => setFormData({
                        ...formData,
                        [gateway.gateway_name]: {
                          ...formData[gateway.gateway_name],
                          apiKey: e.target.value,
                        },
                      })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>API Secret / Secret Key</Label>
                    <Input
                      type="password"
                      placeholder="sk_test_..."
                      value={formData[gateway.gateway_name]?.apiSecret || ""}
                      onChange={(e) => setFormData({
                        ...formData,
                        [gateway.gateway_name]: {
                          ...formData[gateway.gateway_name],
                          apiSecret: e.target.value,
                        },
                      })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Webhook Secret (Optional)</Label>
                    <Input
                      type="password"
                      placeholder="whsec_..."
                      value={formData[gateway.gateway_name]?.webhookSecret || ""}
                      onChange={(e) => setFormData({
                        ...formData,
                        [gateway.gateway_name]: {
                          ...formData[gateway.gateway_name],
                          webhookSecret: e.target.value,
                        },
                      })}
                    />
                    <p className="text-xs text-muted-foreground">
                      Used to verify webhook signatures from {gateway.gateway_name}
                    </p>
                  </div>

                  <div className="flex gap-2 pt-4">
                    <Button
                      onClick={() => handleSaveApiKeys(gateway.gateway_name)}
                      disabled={saving === gateway.gateway_name}
                    >
                      {saving === gateway.gateway_name ? (
                        <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Saving...</>
                      ) : (
                        "Save API Keys"
                      )}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => handleTestConnection(gateway.gateway_name)}
                      disabled={testing === gateway.gateway_name || !gateway.api_key}
                    >
                      {testing === gateway.gateway_name ? (
                        <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Testing...</>
                      ) : (
                        <><CreditCard className="h-4 w-4 mr-2" /> Test Connection</>
                      )}
                    </Button>
                  </div>
                </div>

                {gateway.gateway_name === "stripe" && (
                  <Alert>
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      <strong>Stripe Setup:</strong> Get your API keys from the{" "}
                      <a href="https://dashboard.stripe.com/apikeys" target="_blank" rel="noopener noreferrer" className="underline">
                        Stripe Dashboard
                      </a>
                      <br />
                      <strong>Google Pay via Stripe:</strong> Enable Google Pay in Stripe → Payments → Wallets. No separate keys required.
                      If Stripe asks for domain verification, follow the on-screen instructions. Your existing webhook at
                      <code className="mx-1">{`${typeof window !== "undefined" ? window.location.origin : ""}/api/payments/webhook`}</code>
                      remains unchanged.
                    </AlertDescription>
                  </Alert>
                )}

                {gateway.gateway_name === "paypal" && (
                  <Alert>
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      <strong>PayPal Setup:</strong> Get your credentials from{" "}
                      <a href="https://developer.paypal.com/" target="_blank" rel="noopener noreferrer" className="underline">
                        PayPal Developer Dashboard
                      </a>
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>

      <div className="space-y-6 mt-6">
        <Separator />
        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>API & Webhooks</CardTitle>
              <CardDescription>Use these endpoints when configuring gateways</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Stripe Webhook URL</Label>
                <div className="flex gap-2 mt-1">
                  <Input readOnly value={`${window.location.origin}/api/payments/webhook`} />
                  <Button type="button" variant="outline" onClick={() => copyToClipboard(`${window.location.origin}/api/payments/webhook`, "Stripe webhook URL")}>
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Add this URL in your Stripe Dashboard → Developers → Webhooks
                </p>
              </div>

              <div>
                <Label>PayPro Webhook URL</Label>
                <div className="flex gap-2 mt-1">
                  <Input readOnly value={`${window.location.origin}/api/payments/paypro-webhook`} />
                  <Button type="button" variant="outline" onClick={() => copyToClipboard(`${window.location.origin}/api/payments/paypro-webhook`, "PayPro webhook URL")}>
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Configure this URL in your PayPro merchant settings
                </p>
              </div>

              <div>
                <Label>PayPal Endpoints</Label>
                <div className="space-y-2 mt-1">
                  <div className="flex gap-2">
                    <Input readOnly value={`${window.location.origin}/api/payments/paypal/create-order`} />
                    <Button type="button" variant="outline" onClick={() => copyToClipboard(`${window.location.origin}/api/payments/paypal/create-order`, "PayPal create order URL")}>
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="flex gap-2">
                    <Input readOnly value={`${window.location.origin}/api/payments/paypal/capture-order`} />
                    <Button type="button" variant="outline" onClick={() => copyToClipboard(`${window.location.origin}/api/payments/paypal/capture-order`, "PayPal capture order URL")}>
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Use these endpoints from your client integration or server-to-server flow
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Environment Variables</CardTitle>
              <CardDescription>Set these in your project environment</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <Label>Stripe</Label>
                <ul className="list-disc pl-5 text-sm text-muted-foreground">
                  <li>NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY</li>
                  <li>STRIPE_SECRET_KEY</li>
                  <li>STRIPE_WEBHOOK_SECRET</li>
                </ul>
              </div>
              <div>
                <Label>PayPal</Label>
                <ul className="list-disc pl-5 text-sm text-muted-foreground">
                  <li>PAYPAL_CLIENT_ID</li>
                  <li>PAYPAL_SECRET</li>
                  <li>PAYPAL_ENV (sandbox|live)</li>
                </ul>
              </div>
              <div>
                <Label>PayPro</Label>
                <ul className="list-disc pl-5 text-sm text-muted-foreground">
                  <li>PAYPRO_CLIENT_ID</li>
                  <li>PAYPRO_USERNAME</li>
                  <li>PAYPRO_BASE_URL</li>
                </ul>
              </div>
              <div className="flex gap-2">
                <Button type="button" variant="outline" onClick={() => testGateway("stripe")}>
                  Test Stripe
                </Button>
                <Button type="button" variant="outline" onClick={() => testGateway("paypal")}>
                  Test PayPal
                </Button>
                <Button type="button" variant="outline" onClick={() => testGateway("paypro")}>
                  Test PayPro
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Google Pay Setup</CardTitle>
              <CardDescription>How to enable Google Pay via your chosen provider</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <Alert>
                <AlertDescription>
                  Google Pay is a wallet that must be routed through a payment processor. Choose and enable a provider in the tabs above (e.g., PayPro, Braintree, Adyen, or Stripe). The Google Pay button will only initialize for the provider you enable.
                </AlertDescription>
              </Alert>
              <div className="space-y-2">
                <p className="font-medium">Steps:</p>
                <ol className="list-decimal pl-5 space-y-1">
                  <li>Select and enable your provider in the tabs above.</li>
                  <li>Add the provider credentials in “API Configuration” and click “Save API Keys”.</li>
                  <li>Enable Google Pay/wallets in your provider dashboard (if required by provider).</li>
                  <li>Return here and use “Test Connection” to validate.</li>
                </ol>
                <p className="text-xs text-muted-foreground">
                  Stripe is not available in Pakistan; if you are in Pakistan, consider a local gateway or a provider with Google Pay support for your region.
                </p>
              </div>
              <div className="space-y-2">
                <p className="font-medium">Common provider variables:</p>
                <ul className="list-disc pl-5 text-xs text-muted-foreground">
                  <li>Braintree: BRAINTREE_MERCHANT_ID, BRAINTREE_PUBLIC_KEY, BRAINTREE_PRIVATE_KEY</li>
                  <li>Adyen: ADYEN_API_KEY, ADYEN_MERCHANT_ACCOUNT</li>
                  <li>Stripe (optional): NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY, STRIPE_SECRET_KEY</li>
                </ul>
                <p className="text-xs text-muted-foreground">
                  Exact keys vary by provider. After you confirm your provider, I’ll wire the end-to-end token handling for Google Pay using that provider only.
                </p>
              </div>
            </CardContent>
          </Card>
          <div />
        </div>
      </div>
    </div>
  );
}
