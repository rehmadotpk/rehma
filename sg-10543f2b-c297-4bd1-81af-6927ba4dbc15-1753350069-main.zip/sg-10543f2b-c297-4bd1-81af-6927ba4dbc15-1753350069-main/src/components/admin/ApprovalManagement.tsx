import { useState, useEffect, useCallback } from "react";
import { approvalService, ApprovalRequest } from "@/services/approvalService";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, CheckCircle, XCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";

export function ApprovalManagement() {
  const [requests, setRequests] = useState<ApprovalRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [rejectionReason, setRejectionReason] = useState("");
  const { toast } = useToast();

  const fetchRequests = useCallback(async () => {
    setLoading(true);
    try {
      const { requests: data } = await approvalService.getPendingApprovals();
      setRequests(data);
    } catch (error) {
      toast({
        title: "Error fetching requests",
        description: error instanceof Error ? error.message : "Could not fetch approval requests.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchRequests();
  }, [fetchRequests]);

  const handleUpdateStatus = async (
    id: string,
    status: "approved" | "rejected",
    reason?: string
  ) => {
    try {
      await approvalService.updateApprovalStatus(id, status, undefined, reason);
      toast({
        title: "Success",
        description: `Request has been ${status}.`,
      });
      fetchRequests(); // Refresh list
    } catch (error) {
      toast({
        title: "Error updating status",
        description: error instanceof Error ? error.message : "Could not update request status.",
        variant: "destructive",
      });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="secondary">Pending</Badge>;
      case "under_review":
        return <Badge variant="outline">Under Review</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-40">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Approval Requests</CardTitle>
      </CardHeader>
      <CardContent>
        {requests.length === 0 ? (
          <p>No pending approval requests.</p>
        ) : (
          <div className="space-y-4">
            {requests.map((req) => (
              <div key={req.id} className="p-4 border rounded-lg">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-semibold">
                      {req.entity_type.toUpperCase()} - {req.entity_id.slice(0, 8)}
                    </h3>
                    <p className="text-sm text-gray-500">
                      Requester: {req.requester_data?.full_name || req.requester_data?.email || "N/A"}
                    </p>
                    <p className="text-xs text-gray-400">
                      Requested on: {new Date(req.created_at).toLocaleDateString()}
                    </p>
                  </div>
                  {getStatusBadge(req.status)}
                </div>
                <div className="mt-4 flex items-center gap-4">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleUpdateStatus(req.id, "approved")}
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Approve
                  </Button>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button size="sm" variant="destructive">
                        <XCircle className="w-4 h-4 mr-2" />
                        Reject
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Reject Request</DialogTitle>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <Label htmlFor="rejection_reason">Reason for rejection</Label>
                        <Textarea
                          id="rejection_reason"
                          value={rejectionReason}
                          onChange={(e) => setRejectionReason(e.target.value)}
                          placeholder="Provide a reason for rejection..."
                        />
                      </div>
                      <DialogFooter>
                        <DialogClose asChild>
                          <Button
                            type="button"
                            onClick={() => {
                              handleUpdateStatus(req.id, "rejected", rejectionReason);
                              setRejectionReason("");
                            }}
                          >
                            Confirm Rejection
                          </Button>
                        </DialogClose>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
