import { useState, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Trash2,
  CheckCircle,
  XCircle,
  Search,
  ChevronDown,
  Loader2,
  Edit,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { childrenService, Child } from "@/services/childrenService";
import Image from "next/image";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { CheckedState } from "@radix-ui/react-checkbox";

export function ChildrenManagement() {
  const { toast } = useToast();
  const [children, setChildren] = useState<Child[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isUpdating, setIsUpdating] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [selectedChild, setSelectedChild] = useState<Child | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedChildren, setSelectedChildren] = useState<string[]>([]);

  const fetchChildren = useCallback(async () => {
    setIsLoading(true);
    try {
      const response = await childrenService.getAllChildren(1, 100, {
        status: filterStatus === "all" ? undefined : filterStatus,
        search: searchTerm,
      });
      setChildren(response.children);
    } catch (error) {
      console.error("Failed to fetch children profiles:", error);
      toast({
        title: "Error",
        description: "Failed to fetch children profiles.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [filterStatus, searchTerm, toast]);

  useEffect(() => {
    fetchChildren();
  }, [fetchChildren]);

  const handleUpdate = async () => {
    if (!selectedChild) return;
    setIsUpdating(true);
    try {
      const { id, ...updateData } = selectedChild;
      await childrenService.updateChildById(id, updateData);
      toast({
        title: "Success",
        description: "Child profile updated successfully",
      });
      fetchChildren();
      setIsDialogOpen(false);
      setSelectedChild(null);
    } catch (error) {
      console.error("Failed to update child:", error);
      toast({
        title: "Error",
        description: "Failed to update child profile",
        variant: "destructive",
      });
    } finally {
      setIsUpdating(false);
    }
  };

  const handleDelete = async (childId: string) => {
    if (!confirm("Are you sure you want to delete this child profile? This action cannot be undone.")) return;
    
    try {
      await childrenService.deleteChildById(childId);
      toast({
        title: "Success",
        description: "Child profile deleted successfully",
      });
      fetchChildren();
    } catch (error) {
      console.error("Failed to delete child:", error);
      toast({
        title: "Error",
        description: "Failed to delete child profile",
        variant: "destructive",
      });
    }
  };

  const handleSelectChild = (childId: string, checked: CheckedState) => {
    setSelectedChildren((prev) =>
      checked
        ? [...prev, childId]
        : prev.filter((id) => id !== childId)
    );
  };

  const handleSelectAll = (checked: CheckedState) => {
    if (checked) {
      setSelectedChildren(children.map((c) => c.id));
    } else {
      setSelectedChildren([]);
    }
  };

  const handleBulkAction = async (action: "approve" | "reject" | "delete") => {
    if (selectedChildren.length === 0) {
      toast({
        title: "No selection",
        description: "Please select children to perform a bulk action.",
      });
      return;
    }

    const confirmAction = confirm(`Are you sure you want to ${action} ${selectedChildren.length} selected profiles?`);
    if (!confirmAction) return;

    setIsUpdating(true);
    try {
      for (const childId of selectedChildren) {
        if (action === "approve") {
          await childrenService.updateChildById(childId, { status: "active", verified: true });
        } else if (action === "reject") {
          await childrenService.updateChildById(childId, { status: "rejected" });
        } else if (action === "delete") {
          await childrenService.deleteChildById(childId);
        }
      }
      toast({
        title: "Success",
        description: `Bulk action '${action}' completed successfully.`,
      });
      fetchChildren();
      setSelectedChildren([]);
    } catch (error) {
      console.error("Failed to perform bulk action:", error);
      toast({
        title: "Error",
        description: `Failed to perform bulk action.`,
        variant: "destructive",
      });
    } finally {
      setIsUpdating(false);
    }
  };

  const openEditDialog = (child: Child) => {
    setSelectedChild(child);
    setIsDialogOpen(true);
  };

  return (
    <>
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-[#101c2c]">Children Profiles</CardTitle>
            <div className="flex items-center space-x-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search by name, condition..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" disabled={selectedChildren.length === 0}>
                    Bulk Actions <ChevronDown className="w-4 h-4 ml-2" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={() => handleBulkAction("approve")}>
                    <CheckCircle className="w-4 h-4 mr-2" /> Approve Selected
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleBulkAction("reject")}>
                    <XCircle className="w-4 h-4 mr-2" /> Reject Selected
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => handleBulkAction("delete")}
                    className="text-red-600"
                  >
                    <Trash2 className="w-4 h-4 mr-2" /> Delete Selected
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>
                    <Checkbox
                      checked={
                        children.length > 0 &&
                        selectedChildren.length === children.length
                      }
                      onCheckedChange={handleSelectAll}
                    />
                  </TableHead>
                  <TableHead>Child</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Urgency</TableHead>
                  <TableHead>Raised</TableHead>
                  <TableHead>Goal</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center">
                      <Loader2 className="w-6 h-6 animate-spin mx-auto my-4" />
                    </TableCell>
                  </TableRow>
                ) : children.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center">
                      No children profiles found.
                    </TableCell>
                  </TableRow>
                ) : (
                  children.map((child) => (
                    <TableRow key={child.id}>
                      <TableCell>
                        <Checkbox
                          checked={selectedChildren.includes(child.id)}
                          onCheckedChange={(checked) => handleSelectChild(child.id, checked)}
                        />
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-3">
                          <Image
                            src={child.image || "/api/placeholder/40/40"}
                            alt={child.name}
                            width={40}
                            height={40}
                            className="w-10 h-10 rounded-full object-cover"
                          />
                          <div>
                            <div className="font-medium">{child.name}</div>
                            <div className="text-sm text-gray-500">
                              {child.age} years old
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            child.status === "active" ? "default"
                            : child.status === "completed" ? "default"
                            : child.status === "pending" ? "secondary"
                            : "destructive"
                          }
                          className={child.status === 'active' ? 'bg-green-100 text-green-800' : ''}
                        >
                          {child.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                          className={
                            child.urgency === "high" ? "bg-red-100 text-red-800"
                            : child.urgency === "medium" ? "bg-yellow-100 text-yellow-800"
                            : "bg-green-100 text-green-800"
                          }
                        >
                          {child.urgency}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {new Intl.NumberFormat("en-US", { style: "currency", currency: "PKR" }).format(child.raised_amount)}
                      </TableCell>
                      <TableCell>
                        {new Intl.NumberFormat("en-US", { style: "currency", currency: "PKR" }).format(child.target_amount)}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-1">
                          <Button size="sm" variant="ghost" onClick={() => openEditDialog(child)}>
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => handleDelete(child.id)} className="text-red-500 hover:text-red-700">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {selectedChild && (
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit Child Profile: {selectedChild.name}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-name">Name</Label>
                  <Input id="edit-name" value={selectedChild.name} onChange={(e) => setSelectedChild(prev => prev ? { ...prev, name: e.target.value } : null)} />
                </div>
                <div>
                  <Label htmlFor="edit-age">Age</Label>
                  <Input id="edit-age" type="number" value={selectedChild.age} onChange={(e) => setSelectedChild(prev => prev ? { ...prev, age: parseInt(e.target.value) || 0 } : null)} />
                </div>
              </div>
              <div>
                <Label htmlFor="edit-condition">Medical Condition</Label>
                <Input id="edit-condition" value={selectedChild.condition} onChange={(e) => setSelectedChild(prev => prev ? { ...prev, condition: e.target.value } : null)} />
              </div>
              <div>
                <Label htmlFor="edit-location">Location</Label>
                <Input id="edit-location" value={selectedChild.location} onChange={(e) => setSelectedChild(prev => prev ? { ...prev, location: e.target.value } : null)} />
              </div>
              <div>
                <Label htmlFor="edit-story">Story</Label>
                <Textarea id="edit-story" value={selectedChild.story} onChange={(e) => setSelectedChild(prev => prev ? { ...prev, story: e.target.value } : null)} rows={4} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-target">Target Amount (PKR)</Label>
                  <Input id="edit-target" type="number" value={selectedChild.target_amount} onChange={(e) => setSelectedChild(prev => prev ? { ...prev, target_amount: parseFloat(e.target.value) || 0 } : null)} />
                </div>
                <div>
                  <Label htmlFor="edit-monthly">Monthly Needs (PKR)</Label>
                  <Input id="edit-monthly" type="number" value={selectedChild.monthly_needs} onChange={(e) => setSelectedChild(prev => prev ? { ...prev, monthly_needs: parseFloat(e.target.value) || 0 } : null)} />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="edit-status">Status</Label>
                  <Select value={selectedChild.status} onValueChange={(value: 'pending' | 'active' | 'completed' | 'rejected' | 'inactive') => setSelectedChild(prev => prev ? { ...prev, status: value } : null)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="rejected">Rejected</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="edit-urgency">Urgency</Label>
                  <Select value={selectedChild.urgency} onValueChange={(value: 'low' | 'medium' | 'high') => setSelectedChild(prev => prev ? { ...prev, urgency: value } : null)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center space-x-2 pt-6">
                  <Checkbox id="edit-verified" checked={selectedChild.verified} onCheckedChange={(checked) => setSelectedChild(prev => prev ? { ...prev, verified: !!checked } : null)} />
                  <Label htmlFor="edit-verified">Verified</Label>
                </div>
              </div>
              <div className="flex justify-end space-x-3 pt-4">
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
                <Button onClick={handleUpdate} disabled={isUpdating}>
                  {isUpdating ? (<><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Updating...</>) : "Update Profile"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}
