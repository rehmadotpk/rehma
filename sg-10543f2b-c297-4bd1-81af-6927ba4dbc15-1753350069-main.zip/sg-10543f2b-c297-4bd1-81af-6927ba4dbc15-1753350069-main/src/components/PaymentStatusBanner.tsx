import { useState, useEffect } from "react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { AlertTriangle, X } from "lucide-react";

export default function PaymentStatusBanner() {
  const [isVisible, setIsVisible] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);

  useEffect(() => {
    // Check if PayPro is configured - since PayPro credentials are hardcoded in the service,
    // we can assume the payment system is always ready
    const checkPaymentConfig = () => {
      // PayPro service has hardcoded credentials, so payment system is ready
      // Only show banner if there's a specific configuration issue
      const hasPaymentIssue = false; // Set to true if you want to show maintenance message
      
      if (hasPaymentIssue && !isDismissed) {
        setIsVisible(true);
      }
    };

    checkPaymentConfig();
  }, [isDismissed]);

  const handleDismiss = () => {
    setIsDismissed(true);
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <Alert className="border-orange-200 bg-orange-50 mb-4">
      <AlertTriangle className="w-4 h-4 text-orange-600" />
      <AlertDescription className="text-orange-800 flex items-center justify-between">
        <span>
          Payment system is currently under maintenance. Donations will be available soon.
        </span>
        <Button
          variant="ghost"
          size="sm"
          onClick={handleDismiss}
          className="text-orange-600 hover:text-orange-800 p-1"
        >
          <X className="w-4 h-4" />
        </Button>
      </AlertDescription>
    </Alert>
  );
}
