import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Collapsible, CollapsibleContent } from "@/components/ui/collapsible";
import { 
  Search, 
  Filter, 
  X, 
  MapPin, 
  Calendar,
  Heart,
  Users,
  ChevronDown,
  ChevronUp,
  Sliders
} from "lucide-react";

interface FilterOptions {
  search?: string;
  location?: string;
  ageRange?: [number, number];
  condition?: string[];
  urgency?: string;
  fundingStatus?: string;
  sortBy?: string;
  verified?: boolean;
}

interface SearchAndFilterProps {
  onFiltersChange: (filters: FilterOptions) => void;
  showAdvanced?: boolean;
  placeholder?: string;
}

export default function SearchAndFilter({ 
  onFiltersChange, 
  showAdvanced = true,
  placeholder = "Search children by name, condition, or location..."
}: SearchAndFilterProps) {
  const [filters, setFilters] = useState<FilterOptions>({
    search: "",
    location: "",
    ageRange: [0, 18],
    condition: [],
    urgency: "",
    fundingStatus: "",
    sortBy: "urgency",
    verified: false
  });

  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [activeFiltersCount, setActiveFiltersCount] = useState(0);

  const locations = [
    "Karachi", "Lahore", "Islamabad", "Rawalpindi", "Faisalabad", 
    "Multan", "Peshawar", "Quetta", "Sialkot", "Gujranwala"
  ];

  const conditions = [
    "Cerebral Palsy", "Autism", "Down Syndrome", "Spina Bifida",
    "Muscular Dystrophy", "Epilepsy", "Hearing Impairment", "Visual Impairment",
    "Intellectual Disability", "Speech Disorders", "Heart Conditions", "Cancer"
  ];

  useEffect(() => {
    // Count active filters
    let count = 0;
    if (filters.search) count++;
    if (filters.location) count++;
    if (filters.ageRange && (filters.ageRange[0] > 0 || filters.ageRange[1] < 18)) count++;
    if (filters.condition && filters.condition.length > 0) count++;
    if (filters.urgency) count++;
    if (filters.fundingStatus) count++;
    if (filters.verified) count++;
    
    setActiveFiltersCount(count);
    onFiltersChange(filters);
  }, [filters, onFiltersChange]);

  const handleFilterChange = (key: keyof FilterOptions, value: string | number[] | boolean) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleConditionToggle = (condition: string) => {
    setFilters(prev => ({
      ...prev,
      condition: prev.condition?.includes(condition)
        ? prev.condition.filter(c => c !== condition)
        : [...(prev.condition || []), condition]
    }));
  };

  const clearAllFilters = () => {
    setFilters({
      search: "",
      location: "",
      ageRange: [0, 18],
      condition: [],
      urgency: "",
      fundingStatus: "",
      sortBy: "urgency",
      verified: false
    });
  };

  const removeFilter = (filterKey: keyof FilterOptions) => {
    switch (filterKey) {
      case 'condition':
        handleFilterChange('condition', []);
        break;
      case 'ageRange':
        handleFilterChange('ageRange', [0, 18]);
        break;
      default:
        handleFilterChange(filterKey, filterKey === 'verified' ? false : '');
    }
  };

  return (
    <div className="space-y-4">
      {/* Main Search Bar */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <Input
            placeholder={placeholder}
            value={filters.search || ""}
            onChange={(e) => handleFilterChange('search', e.target.value)}
            className="pl-10 h-12 text-base"
          />
        </div>
        
        <div className="flex gap-2">
          <Select value={filters.sortBy || ""} onValueChange={(value) => handleFilterChange('sortBy', value)}>
            <SelectTrigger className="w-48 h-12">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="urgency">Most Urgent</SelectItem>
              <SelectItem value="progress">Funding Progress</SelectItem>
              <SelectItem value="recent">Recently Added</SelectItem>
              <SelectItem value="age_asc">Age (Youngest First)</SelectItem>
              <SelectItem value="age_desc">Age (Oldest First)</SelectItem>
              <SelectItem value="location">Location</SelectItem>
            </SelectContent>
          </Select>

          {showAdvanced && (
            <Button
              variant="outline"
              onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
              className="h-12 px-4 border-[#101c2c] text-[#101c2c] hover:bg-[#101c2c] hover:text-white"
            >
              <Sliders className="w-4 h-4 mr-2" />
              Filters
              {activeFiltersCount > 0 && (
                <Badge className="ml-2 bg-yellow-500 text-white text-xs">
                  {activeFiltersCount}
                </Badge>
              )}
              {showAdvancedFilters ? <ChevronUp className="w-4 h-4 ml-2" /> : <ChevronDown className="w-4 h-4 ml-2" />}
            </Button>
          )}
        </div>
      </div>

      {/* Active Filters Display */}
      {activeFiltersCount > 0 && (
        <div className="flex flex-wrap gap-2 items-center">
          <span className="text-sm text-gray-600">Active filters:</span>
          
          {filters.search && (
            <Badge variant="secondary" className="flex items-center gap-1">
              Search: "{filters.search}"
              <X className="w-3 h-3 cursor-pointer" onClick={() => removeFilter('search')} />
            </Badge>
          )}
          
          {filters.location && (
            <Badge variant="secondary" className="flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              {filters.location}
              <X className="w-3 h-3 cursor-pointer" onClick={() => removeFilter('location')} />
            </Badge>
          )}
          
          {filters.ageRange && (filters.ageRange[0] > 0 || filters.ageRange[1] < 18) && (
            <Badge variant="secondary" className="flex items-center gap-1">
              Age: {filters.ageRange[0]}-{filters.ageRange[1]}
              <X className="w-3 h-3 cursor-pointer" onClick={() => removeFilter('ageRange')} />
            </Badge>
          )}
          
          {filters.condition && filters.condition.length > 0 && (
            <Badge variant="secondary" className="flex items-center gap-1">
              Conditions: {filters.condition.length}
              <X className="w-3 h-3 cursor-pointer" onClick={() => removeFilter('condition')} />
            </Badge>
          )}
          
          {filters.urgency && (
            <Badge variant="secondary" className="flex items-center gap-1">
              Urgency: {filters.urgency}
              <X className="w-3 h-3 cursor-pointer" onClick={() => removeFilter('urgency')} />
            </Badge>
          )}
          
          {filters.fundingStatus && (
            <Badge variant="secondary" className="flex items-center gap-1">
              Status: {filters.fundingStatus}
              <X className="w-3 h-3 cursor-pointer" onClick={() => removeFilter('fundingStatus')} />
            </Badge>
          )}
          
          {filters.verified && (
            <Badge variant="secondary" className="flex items-center gap-1">
              Verified Only
              <X className="w-3 h-3 cursor-pointer" onClick={() => removeFilter('verified')} />
            </Badge>
          )}
          
          <Button variant="ghost" size="sm" onClick={clearAllFilters} className="text-red-600 hover:text-red-700">
            Clear All
          </Button>
        </div>
      )}

      {/* Advanced Filters */}
      <Collapsible open={showAdvancedFilters} onOpenChange={setShowAdvancedFilters}>
        <CollapsibleContent>
          <Card className="border-[#101c2c]/20">
            <CardHeader className="pb-4">
              <CardTitle className="text-lg flex items-center">
                <Filter className="w-5 h-5 mr-2" />
                Advanced Filters
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* Location Filter */}
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center">
                    <MapPin className="w-4 h-4 mr-2" />
                    Location
                  </label>
                  <Select value={filters.location || ""} onValueChange={(value) => handleFilterChange('location', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select location" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All Locations</SelectItem>
                      {locations.map(location => (
                        <SelectItem key={location} value={location}>{location}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Urgency Filter */}
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center">
                    <Heart className="w-4 h-4 mr-2" />
                    Urgency Level
                  </label>
                  <Select value={filters.urgency || ""} onValueChange={(value) => handleFilterChange('urgency', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select urgency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All Levels</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Funding Status Filter */}
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center">
                    <Users className="w-4 h-4 mr-2" />
                    Funding Status
                  </label>
                  <Select value={filters.fundingStatus || ""} onValueChange={(value) => handleFilterChange('fundingStatus', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All Status</SelectItem>
                      <SelectItem value="new">Just Started (0-25%)</SelectItem>
                      <SelectItem value="progress">In Progress (25-75%)</SelectItem>
                      <SelectItem value="almost">Almost There (75-95%)</SelectItem>
                      <SelectItem value="urgent">Needs Urgent Help</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Age Range Slider */}
              <div className="space-y-4">
                <label className="text-sm font-medium flex items-center">
                  <Calendar className="w-4 h-4 mr-2" />
                  Age Range: {filters.ageRange?.[0]} - {filters.ageRange?.[1]} years
                </label>
                <Slider
                  value={filters.ageRange || [0, 18]}
                  onValueChange={(value) => handleFilterChange('ageRange', value)}
                  max={18}
                  min={0}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-500">
                  <span>0 years</span>
                  <span>18 years</span>
                </div>
              </div>

              {/* Medical Conditions */}
              <div className="space-y-3">
                <label className="text-sm font-medium">Medical Conditions</label>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                  {conditions.map(condition => (
                    <div key={condition} className="flex items-center space-x-2">
                      <Checkbox
                        id={condition}
                        checked={filters.condition?.includes(condition) || false}
                        onCheckedChange={() => handleConditionToggle(condition)}
                      />
                      <label htmlFor={condition} className="text-sm cursor-pointer">
                        {condition}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Verified Only */}
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="verified"
                  checked={filters.verified || false}
                  onCheckedChange={(checked) => handleFilterChange('verified', checked)}
                />
                <label htmlFor="verified" className="text-sm cursor-pointer">
                  Show only verified profiles
                </label>
              </div>

              {/* Filter Actions */}
              <div className="flex justify-between pt-4 border-t">
                <Button variant="outline" onClick={clearAllFilters}>
                  Clear All Filters
                </Button>
                <Button 
                  onClick={() => setShowAdvancedFilters(false)}
                  className="bg-gradient-to-r from-[#101c2c] to-yellow-600 hover:from-[#1e293b] hover:to-yellow-700"
                >
                  Apply Filters
                </Button>
              </div>
            </CardContent>
          </Card>
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
}
