import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Building2, Copy } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { formatNumber } from "@/lib/number";

interface BankTransferFormProps {
  amount: number;
  childId: string;
  anonymous: boolean;
  message: string;
  onError: (error: string) => void;
  onSuccess: (data: { transaction_id: string, payment_method: "bank" }) => void;
}

export default function BankTransferForm({
  amount,
  childId,
  anonymous,
  message,
  onError,
  onSuccess,
}: BankTransferFormProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [donorInfo, setDonorInfo] = useState({
    name: user?.user_metadata?.full_name || "",
    email: user?.email || "",
    phone: "",
  });

  const bankDetails = {
    bankName: "Meezan Bank",
    accountTitle: "Rehma Foundation",
    accountNumber: "0123456789012345",
    iban: "PK36MEZN0000123456789012",
    branchCode: "1234",
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: `${label} copied to clipboard`,
    });
  };

  const validateForm = () => {
    if (!donorInfo.name || !donorInfo.email) {
      setError("Please fill in your name and email.");
      return false;
    }
    setError(null);
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;
    setIsSubmitting(true);

    try {
      // Simulate bank transfer processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      onSuccess({
        transaction_id: `bt_${Date.now()}`,
        payment_method: "bank",
      });
    } catch (error) {
      setError(error instanceof Error ? error.message : "An unexpected error occurred.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Building2 className="h-5 w-5" />
          Bank Transfer Details
        </CardTitle>
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Amount:</span>
          <Badge variant="secondary" className="text-lg font-bold">
            PKR {formatNumber(amount)}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="bg-blue-50 p-4 rounded-lg space-y-3">
          <h4 className="font-medium text-blue-900">Transfer to:</h4>
          
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm text-blue-700">Bank Name:</span>
              <div className="flex items-center gap-2">
                <span className="font-medium">{bankDetails.bankName}</span>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => copyToClipboard(bankDetails.bankName, "Bank Name")}
                >
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-sm text-blue-700">Account Title:</span>
              <div className="flex items-center gap-2">
                <span className="font-medium">{bankDetails.accountTitle}</span>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => copyToClipboard(bankDetails.accountTitle, "Account Title")}
                >
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-sm text-blue-700">Account Number:</span>
              <div className="flex items-center gap-2">
                <span className="font-medium font-mono">{bankDetails.accountNumber}</span>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => copyToClipboard(bankDetails.accountNumber, "Account Number")}
                >
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-sm text-blue-700">IBAN:</span>
              <div className="flex items-center gap-2">
                <span className="font-medium font-mono text-sm">{bankDetails.iban}</span>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => copyToClipboard(bankDetails.iban, "IBAN")}
                >
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        <Separator />

        <div className="space-y-2">
          <Label htmlFor="donor-name">Full Name *</Label>
          <Input
            id="donor-name"
            type="text"
            placeholder="Enter your full name"
            value={donorInfo.name}
            onChange={(e) => setDonorInfo({ ...donorInfo, name: e.target.value })}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="donor-email">Email Address *</Label>
          <Input
            id="donor-email"
            type="email"
            placeholder="Enter your email"
            value={donorInfo.email}
            onChange={(e) => setDonorInfo({ ...donorInfo, email: e.target.value })}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="donor-phone">Phone Number (Optional)</Label>
          <Input
            id="donor-phone"
            type="tel"
            placeholder="03XX-XXXXXXX"
            value={donorInfo.phone}
            onChange={(e) => setDonorInfo({ ...donorInfo, phone: e.target.value })}
          />
        </div>

        <Button
          onClick={handleSubmit}
          disabled={isSubmitting || !donorInfo.name || !donorInfo.email}
          className="w-full"
          size="lg"
        >
          {isSubmitting ? "Recording..." : "Record Donation"}
        </Button>

        <div className="bg-yellow-50 p-3 rounded-lg">
          <p className="text-xs text-yellow-800">
            <strong>Important:</strong> After transferring, please keep your receipt. 
            We'll verify your donation within 24 hours and send you a confirmation email.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
