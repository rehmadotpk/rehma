import { useEffect, useRef, useState } from "react";
import { loadStripe, Stripe, PaymentRequest, PaymentRequestPaymentMethodEvent } from "@stripe/stripe-js";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CreditCard, Smartphone, Loader2, Shield } from "lucide-react";
import { donationService } from "@/services/donationService";
import { useAuth } from "@/contexts/AuthContext";
import { useRouter } from "next/router";
import { formatNumber } from "@/lib/number";
import { paymentGatewayService } from "@/services/paymentGatewayService";

interface GooglePayPaymentFormProps {
  amount: number;
  childId: string;
  childName: string;
  anonymous: boolean;
  message: string;
  onError: (error: string) => void;
  onSuccess: () => void;
}

/**
 * Google Pay via Stripe Payment Request API
 * - No extra Google Pay keys; uses Stripe publishable key
 * - Shows Payment Request Button (Google Pay button on supported devices/browsers)
 */
export default function GooglePayPaymentForm({
  amount,
  childId,
  childName,
  anonymous,
  message,
  onError,
  onSuccess,
}: GooglePayPaymentFormProps) {
  const { user } = useAuth();
  const router = useRouter();
  const buttonRef = useRef<HTMLDivElement | null>(null);

  const [stripe, setStripe] = useState<Stripe | null>(null);
  const [paymentRequest, setPaymentRequest] = useState<PaymentRequest | null>(null);
  const [clientSecret, setClientSecret] = useState<string>("");
  const [donationId, setDonationId] = useState<string>("");
  const [ready, setReady] = useState(false);
  const [unavailableReason, setUnavailableReason] = useState<string>("");
  const [stripeEnabled, setStripeEnabled] = useState<boolean>(false);

  const publishableKey = process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY;

  useEffect(() => {
    let isMounted = true;

    async function setup() {
      try {
        // Check if Stripe gateway is enabled before attempting any Stripe-based Google Pay flow
        try {
          const gateway = await paymentGatewayService.getGateway("stripe");
          if (!isMounted) return;
          if (!gateway || !gateway.is_enabled) {
            setStripeEnabled(false);
            setUnavailableReason("Google Pay requires a configured provider. Choose your provider in Admin → Payments. Stripe is currently disabled.");
            return;
          }
          setStripeEnabled(true);
        } catch {
          if (!isMounted) return;
          setStripeEnabled(false);
          setUnavailableReason("Unable to read payment gateway settings. Please open Admin → Payments and verify configuration.");
          return;
        }

        if (!publishableKey) {
          setUnavailableReason("Stripe is not configured. Please set NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY or choose another provider.");
          return;
        }

        // 1) Load Stripe
        const s = await loadStripe(publishableKey);
        if (!s) {
          setUnavailableReason("Failed to initialize Stripe.");
          return;
        }
        if (!isMounted) return;
        setStripe(s);

        // 2) Create donation record first
        const donation = await donationService.createDonation({
          child_id: childId,
          donor_id: user?.id || null,
          amount: amount,
          currency: "PKR",
          donor_name: user?.user_metadata?.full_name || "Guest",
          donor_email: user?.email || "",
          donor_phone: "",
          payment_status: "pending",
          donation_type: "one-time",
          payment_method: "card",
          anonymous,
          message,
        });
        if (!donation) {
          setUnavailableReason("Failed to create donation record.");
          return;
        }
        if (!isMounted) return;
        setDonationId(donation.id);

        // 3) Create a PaymentIntent
        const intentResp = await fetch("/api/payments/create-intent", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            amount,
            currency: "PKR",
            childId,
            donorId: user?.id || donation.donor_id || "guest",
            donationType: "one-time",
            donorName: user?.user_metadata?.full_name || "Guest",
            donorEmail: user?.email || "",
          }),
        });

        if (!intentResp.ok) {
          const data = await intentResp.json().catch(() => ({}));
          setUnavailableReason(data?.error || "Failed to create payment intent.");
          return;
        }
        const intentData = await intentResp.json();
        if (!isMounted) return;
        setClientSecret(intentData.client_secret);

        // 4) Configure Payment Request (amount in smallest currency unit)
        const amountInPaisa = Math.round(amount * 100);
        const pr = s.paymentRequest({
          country: "PK",
          currency: "pkr",
          total: {
            label: childName ? `Donation to ${childName}` : "Donation",
            amount: amountInPaisa,
          },
          requestPayerName: true,
          requestPayerEmail: true,
        });

        const canPay = await pr.canMakePayment();
        if (!isMounted) return;

        if (!canPay || (!canPay.googlePay && !canPay.applePay)) {
          setUnavailableReason("Google Pay isn’t available on this device or browser.");
          setPaymentRequest(null);
          setReady(false);
          return;
        }

        pr.on("paymentmethod", async (ev: PaymentRequestPaymentMethodEvent) => {
          if (!clientSecret) {
            ev.complete("fail");
            onError("Payment not ready. Please try again.");
            return;
          }
          try {
            // Confirm payment using received payment method
            const result = await s.confirmCardPayment(clientSecret, {
              payment_method: ev.paymentMethod.id,
            }, { handleActions: true });

            if (result.error) {
              ev.complete("fail");
              onError(result.error.message || "Payment failed.");
              return;
            }

            if (result.paymentIntent && result.paymentIntent.status === "requires_action") {
              const next = await s.confirmCardPayment(clientSecret);
              if (next.error) {
                ev.complete("fail");
                onError(next.error.message || "Payment failed.");
                return;
              }
            }

            ev.complete("success");
            onSuccess();
            router.push(`/payment/success?donation_id=${donation.id}`);
          } catch (e) {
            ev.complete("fail");
            onError(e instanceof Error ? e.message : "Payment failed.");
          }
        });

        setPaymentRequest(pr);
        setReady(true);

        // 5) Mount the Payment Request Button using Stripe Elements (no react-stripe-js dependency)
        const elements = s.elements();
        const prButton = elements.create("paymentRequestButton", {
          paymentRequest: pr,
          style: {
            paymentRequestButton: {
              type: "default",
              theme: "dark",
              height: "48px",
            },
          },
        });

        if (buttonRef.current) {
          prButton.mount(buttonRef.current);
        }
      } catch (err) {
        setUnavailableReason(err instanceof Error ? err.message : "Initialization error.");
      }
    }

    setup();
    return () => { isMounted = false; };
  }, [publishableKey, amount, childId, childName, anonymous, message, onError, onSuccess, user]);

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Smartphone className="h-5 w-5" />
          Google Pay
        </CardTitle>
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Amount:</span>
          <Badge variant="secondary" className="text-lg font-bold">
            PKR {formatNumber(amount)}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {!stripeEnabled && (
          <Alert>
            <AlertDescription>
              Google Pay requires a configured provider. Open Admin → Payments, enable your desired gateway, and follow the Google Pay setup steps. I will only use Stripe here if Stripe is explicitly enabled.
            </AlertDescription>
          </Alert>
        )}
        {!publishableKey && stripeEnabled && (
          <Alert>
            <AlertDescription>
              Stripe is enabled but the publishable key is missing. Set NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY to enable Google Pay via Stripe, or select a different provider.
            </AlertDescription>
          </Alert>
        )}

        {unavailableReason && (
          <Alert>
            <AlertDescription>{unavailableReason}</AlertDescription>
          </Alert>
        )}

        {!unavailableReason && (
          <>
            {!ready && (
              <div className="flex items-center justify-center py-6">
                <Loader2 className="h-6 w-6 animate-spin" />
              </div>
            )}

            <div ref={buttonRef} className={!ready ? "hidden" : ""} />

            <div className="text-xs text-muted-foreground flex items-center gap-2">
              <Shield className="h-3 w-3" />
              Secured by Stripe. Google Pay availability depends on device/browser.
            </div>
          </>
        )}

        <div className="text-xs text-muted-foreground flex items-center gap-2">
          <CreditCard className="h-3 w-3" />
          If Google Pay isn’t shown, please choose Stripe or PayPro.
        </div>
      </CardContent>
    </Card>
  );
}