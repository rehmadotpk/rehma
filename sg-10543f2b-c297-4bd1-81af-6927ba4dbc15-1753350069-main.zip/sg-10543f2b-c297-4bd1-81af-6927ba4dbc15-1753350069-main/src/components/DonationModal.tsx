import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Heart, CreditCard, CheckCircle, AlertCircle } from "lucide-react";
import { useCurrency } from "@/contexts/CurrencyContext";
import { Child } from "@/services/childrenService";
import PaymentMethodSelector from "./PaymentMethodSelector";

interface DonationModalProps {
  child: Child;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

interface DonationFormData {
  amount: string;
  anonymous: boolean;
  message: string;
}

function DonationForm({ child, onClose, onSuccess }: Omit<DonationModalProps, "isOpen">) {
  const { currency, formatPrice } = useCurrency();

  const [formData, setFormData] = useState<DonationFormData>({
    amount: "5000",
    anonymous: false,
    message: "",
  });

  const [error, setError] = useState("");
  const [paymentStep, setPaymentStep] = useState<"details" | "payment" | "success">("details");

  const predefinedAmounts = [1000, 2500, 5000, 10000, 25000, 50000];

  const handleInputChange = (
    field: keyof DonationFormData,
    value: string | boolean
  ) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleProceedToPayment = () => {
    const amount = parseFloat(formData.amount);
    if (!amount || amount <= 0) {
      setError("Please enter a valid donation amount.");
      return;
    }
    setError("");
    setPaymentStep("payment");
  };

  const handlePaymentError = (errorMessage: string) => {
    setError(errorMessage);
    setPaymentStep("details");
  };

  const handlePaymentSuccess = () => {
    setPaymentStep("success");
    onSuccess();
  };

  const handleBackToDetails = () => {
    setPaymentStep("details");
    setError("");
  };

  if (paymentStep === "success") {
    return (
      <div className="text-center py-8">
        <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
        <h3 className="text-xl font-semibold text-green-800 mb-2">
          Thank You!
        </h3>
        <p className="text-gray-600">
          You are being redirected to complete your donation.
        </p>
      </div>
    );
  }

  if (paymentStep === "payment") {
    return (
      <PaymentMethodSelector
        amount={parseFloat(formData.amount)}
        childId={child.id}
        childName={child.name}
        anonymous={formData.anonymous}
        message={formData.message}
        onError={handlePaymentError}
        onSuccess={handlePaymentSuccess}
        onBack={handleBackToDetails}
      />
    );
  }

  return (
    <div className="space-y-6">
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="bg-gradient-to-r from-[#101c2c]/5 to-yellow-600/5 p-4 rounded-lg border border-[#101c2c]/10">
        <h3 className="font-semibold text-[#101c2c]">
          {child.name}, {child.age} years old
        </h3>
        <p className="text-gray-700 text-sm">{child.condition}</p>
        <div className="mt-2 text-sm text-gray-600">
          <span>Goal: {formatPrice(child.target_amount)}</span>
          <span className="mx-2">•</span>
          <span>Raised: {formatPrice(child.raised_amount || 0)}</span>
        </div>
      </div>

      <div className="space-y-4">
        <div className="bg-[#d4af37]/10 backdrop-blur-sm rounded-lg p-4 border border-[#d4af37]/20">
          <p className="text-[#101c2c] text-sm">
            <strong>Transparency Notice:</strong> From every donation, 10% goes to Rehma Portal to cover daily operations and platform maintenance. This ensures sustainable operations and continued service to help more children.
          </p>
        </div>

        <div className="grid grid-cols-3 gap-2">
          {predefinedAmounts.map((amount) => (
            <Button
              key={amount}
              variant="outline"
              onClick={() => handleInputChange("amount", amount.toString())}
              className={`${
                parseFloat(formData.amount) === amount
                  ? "bg-[#d4af37] text-white border-[#d4af37]"
                  : "border-gray-300 hover:border-[#d4af37]"
              }`}
            >
              {formatPrice(amount)}
            </Button>
          ))}
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="amount">Or Enter Custom Amount ({currency})</Label>
        <Input
          id="amount"
          type="number"
          placeholder="Enter amount"
          value={formData.amount}
          onChange={(e) => handleInputChange("amount", e.target.value)}
          min="100"
          required
        />
      </div>

      <div className="flex items-center justify-between">
        <div>
          <Label htmlFor="anonymous">Anonymous Donation</Label>
          <p className="text-sm text-gray-600">
            Hide your name from public donation list
          </p>
        </div>
        <Switch
          id="anonymous"
          checked={formData.anonymous}
          onCheckedChange={(checked) => handleInputChange("anonymous", checked)}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="message">Message (Optional)</Label>
        <Textarea
          id="message"
          placeholder="Leave a message of support..."
          value={formData.message}
          onChange={(e) => handleInputChange("message", e.target.value)}
          rows={3}
        />
      </div>

      <div className="flex gap-3">
        <Button
          type="button"
          variant="outline"
          onClick={onClose}
          className="flex-1"
        >
          Cancel
        </Button>
        <Button
          type="button"
          onClick={handleProceedToPayment}
          disabled={!formData.amount}
          className="flex-1 bg-gradient-to-r from-[#101c2c] to-yellow-600 hover:from-[#1a2b3d] hover:to-yellow-700 text-white"
        >
          <CreditCard className="w-4 h-4 mr-2" />
          <span>
            Choose Payment Method{" "}
            {formData.amount
              ? formatPrice(parseFloat(formData.amount))
              : ""}
          </span>
        </Button>
      </div>
    </div>
  );
}

export default function DonationModal({
  child,
  isOpen,
  onClose,
  onSuccess,
}: DonationModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-red-500" />
            Donate to {child.name}
          </DialogTitle>
        </DialogHeader>

        <Card className="border-0 shadow-none">
          <CardContent className="p-0">
            <DonationForm
              child={child}
              onClose={onClose}
              onSuccess={onSuccess}
            />
          </CardContent>
        </Card>
      </DialogContent>
    </Dialog>
  );
}
