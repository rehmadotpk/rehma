
import { useEffect } from "react";
import { useRouter } from "next/router";

export function usePerformanceMonitoring() {
  const router = useRouter();

  useEffect(() => {
    const startTime = performance.now();
    
    const handleRouteChangeComplete = () => {
      const endTime = performance.now();
      const loadTime = endTime - startTime;
      
      if (process.env.NODE_ENV === "development") {
        console.log(`Route load time: ${loadTime.toFixed(2)}ms`);
      }
      
      if (process.env.NODE_ENV === "production" && typeof window !== "undefined" && window.gtag) {
        window.gtag("event", "page_load_time", {
          value: Math.round(loadTime),
          custom_parameter: router.pathname
        });
      }
    };

    router.events.on("routeChangeComplete", handleRouteChangeComplete);
    
    return () => {
      router.events.off("routeChangeComplete", handleRouteChangeComplete);
    };
  }, [router]);
}

export function PreloadCriticalResources() {
  useEffect(() => {
    const fontLink = document.createElement("link");
    fontLink.rel = "preload";
    fontLink.href = "/fonts/inter-var.woff2";
    fontLink.as = "font";
    fontLink.type = "font/woff2";
    fontLink.crossOrigin = "anonymous";
    document.head.appendChild(fontLink);

    const logoLink = document.createElement("link");
    logoLink.rel = "preload";
    logoLink.href = "/Logo-Rehma-sqaure.png";
    logoLink.as = "image";
    document.head.appendChild(logoLink);

    return () => {
      if (document.head.contains(fontLink)) {
        document.head.removeChild(fontLink);
      }
      if (document.head.contains(logoLink)) {
        document.head.removeChild(logoLink);
      }
    };
  }, []);

  return null;
}
