import { useState, useCallback, useEffect, useMemo } from "react";
import Link from "next/link";
import { useRouter } from "next/router";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { 
  Menu, 
  X, 
  Heart, 
  Phone, 
  Mail, 
  MapPin,
  Facebook,
  Twitter,
  Instagram,
  Linkedin,
  LogOut,
  User as UserIcon
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Avatar } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/contexts/AuthContext";
import { useCurrency } from "@/contexts/CurrencyContext";
import dynamic from "next/dynamic";
const NotificationCenter = dynamic(() => import("@/components/NotificationCenter"), { ssr: false });
import ClientOnlyDate from "@/components/ClientOnlyDate";

interface LayoutProps {
  children: React.ReactNode;
}

const navLinks = [
  { name: "Home", href: "/" },
  { name: "About", href: "/about" },
  { name: "Children", href: "/children" },
  { name: "Shop", href: "/shop" },
  { name: "NGOs", href: "/ngos" },
  { name: "Doctors", href: "/doctors" },
  { name: "Help", href: "/help" },
  { name: "Contact", href: "/contact" },
];

// Footer-specific links for Track and Stories
const footerLinks = [
  { name: "Track", href: "/track" },
  { name: "Stories", href: "/stories" },
];

export default function Layout({ children }: LayoutProps) {
  const { user, userProfile, isAdmin, loading, error, initialized, signOut, clearError } = useAuth();
  const { currency, setCurrency } = useCurrency();
  const router = useRouter();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Stable navigation handler - consistent pattern
  const handleNavigation = useCallback((href: string) => {
    setIsMenuOpen(false);
    router.push(href);
  }, [router]);

  // Stable sign out handler
  const handleSignOut = useCallback(async () => {
    try {
      setIsMenuOpen(false);
      await signOut();
      router.push('/');
    } catch (error) {
      console.error('Sign out error:', error);
    }
  }, [signOut, router]);

  // Close mobile menu on route change
  useEffect(() => {
    const handleRouteChange = () => {
      setIsMenuOpen(false);
    };

    router.events.on('routeChangeComplete', handleRouteChange);
    router.events.on('routeChangeError', handleRouteChange);

    return () => {
      router.events.off('routeChangeComplete', handleRouteChange);
      router.events.off('routeChangeError', handleRouteChange);
    };
  }, [router.events]);

  // Close mobile menu on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Element;
      if (isMenuOpen && !target.closest('header')) {
        setIsMenuOpen(false);
      }
    };

    if (isMenuOpen) {
      document.addEventListener('click', handleClickOutside);
      return () => document.removeEventListener('click', handleClickOutside);
    }
  }, [isMenuOpen]);

  // Auto-clear auth errors after 5 seconds
  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => {
        clearError();
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [error, clearError]);

  // Memoized auth section for desktop - prevents unnecessary re-renders
  const authSection = useMemo(() => {
    // Show loading only when not initialized
    if (!initialized && loading) {
      return <Skeleton className="h-10 w-24 rounded-md bg-gray-600" />;
    }

    // Show user menu if authenticated
    if (user && initialized) {
      return (
        <div className="flex items-center space-x-2">
          <NotificationCenter />
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                className="relative h-10 w-10 rounded-full text-white hover:bg-white/10 focus:ring-2 focus:ring-[#d4af37]"
              >
                <Avatar>
                  <UserIcon className="w-4 h-4" />
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem onClick={() => handleNavigation("/dashboard")}>
                Dashboard
              </DropdownMenuItem>
              {isAdmin && (
                <DropdownMenuItem onClick={() => handleNavigation("/admin")}>
                  Admin Panel
                </DropdownMenuItem>
              )}
              <DropdownMenuItem onClick={() => handleNavigation("/profile")}>
                Profile
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleNavigation("/settings")}>
                Settings
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleSignOut} className="text-red-600">
                <LogOut className="w-4 h-4 mr-2" />
                Sign Out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      );
    }

    // Default: show login button for non-authenticated users
    return (
      <Button
        onClick={() => handleNavigation("/auth/login")}
        className="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white focus:ring-2 focus:ring-[#d4af37]"
      >
        Login
      </Button>
    );
  }, [user, initialized, loading, handleNavigation, handleSignOut, isAdmin]);

  // Memoized mobile auth section - prevents unnecessary re-renders
  const mobileAuthSection = useMemo(() => {
    // Show loading skeleton when not initialized
    if (!initialized && loading) {
      return (
        <div className="space-y-2 px-4 pb-4">
          <Skeleton className="w-full h-8 bg-gray-700 rounded" />
          <Skeleton className="w-full h-8 bg-gray-700 rounded" />
        </div>
      );
    }

    // Show user menu if authenticated
    if (user && initialized) {
      const displayName = userProfile?.full_name || user.email?.split('@')[0] || 'User';
      
      return (
        <div className="space-y-2 px-4 pb-4">
          <div className="px-3 py-2 text-sm text-gray-400 border-b border-gray-700">
            Welcome, {displayName}
            {isAdmin && <span className="ml-2 text-xs bg-yellow-600 text-white px-2 py-1 rounded">Admin</span>}
          </div>
          <Button
            variant="ghost"
            onClick={() => handleNavigation("/dashboard")}
            className="w-full justify-start text-gray-300 hover:text-white hover:bg-white/10"
          >
            Dashboard
          </Button>
          {isAdmin && (
            <Button
              variant="ghost"
              onClick={() => handleNavigation("/admin")}
              className="w-full justify-start text-gray-300 hover:text-white hover:bg-white/10"
            >
              Admin Panel
            </Button>
          )}
          <Button
            variant="ghost"
            onClick={() => handleNavigation("/profile")}
            className="w-full justify-start text-gray-300 hover:text-white hover:bg-white/10"
          >
            Profile
          </Button>
          <Button
            onClick={() => handleNavigation("/children")}
            className="w-full bg-[#d4af37] hover:bg-[#b8941f] text-white"
          >
            <Heart className="w-4 h-4 mr-2" />
            Donate
          </Button>
          <Button
            variant="ghost"
            onClick={handleSignOut}
            className="w-full justify-start text-red-400 hover:text-red-300 hover:bg-red-900/20"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Sign Out
          </Button>
        </div>
      );
    }

    // Default: show auth buttons for non-authenticated users
    return (
      <div className="space-y-2 px-4 pb-4">
        <Button
          variant="ghost"
          onClick={() => handleNavigation("/auth/login")}
          className="w-full justify-start text-gray-300 hover:text-white hover:bg-white/10"
        >
          Sign In
        </Button>
        <Button
          onClick={() => handleNavigation("/auth/register")}
          className="w-full bg-[#d4af37] hover:bg-[#b8941f] text-white"
        >
          Get Started
        </Button>
      </div>
    );
  }, [user, userProfile, initialized, loading, handleNavigation, handleSignOut, isAdmin]);

  return (
    <div className="min-h-screen bg-white">
      <header className="bg-[#101c2c] shadow-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center">
              <Link 
                href="/" 
                className="flex items-center space-x-3 hover:opacity-80 transition-opacity focus:outline-none focus:ring-2 focus:ring-[#d4af37] rounded-md p-1"
              >
                <Image 
                  src="/Logo-Rehma-sqaure.png" 
                  alt="Rehma" 
                  width={40}
                  height={40}
                  className="h-10 w-10 object-contain"
                />
                <div className="text-white">
                  <h1 className="text-xl font-bold">Rehma</h1>
                  <p className="text-xs text-gray-300">Infinite Blessings Here & After</p>
                </div>
              </Link>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-8">
              {navLinks.map((item) => (
                <Link 
                  key={item.name} 
                  href={item.href}
                  prefetch={false}
                  className={`text-sm font-medium transition-all duration-200 hover:scale-105 transform focus:outline-none focus:ring-2 focus:ring-[#d4af37] rounded px-2 py-1 ${
                    router.pathname === item.href
                      ? "text-[#d4af37] border-b-2 border-[#d4af37] pb-1"
                      : "text-gray-300 hover:text-white"
                  }`}
                >
                  {item.name}
                </Link>
              ))}
            </nav>

            {/* Desktop Actions */}
            <div className="hidden md:flex items-center space-x-4">
              <Select value={currency} onValueChange={setCurrency}>
                <SelectTrigger className="w-24 bg-transparent text-white border-gray-600 hover:bg-white/10">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="PKR">PKR</SelectItem>
                  <SelectItem value="USD">USD</SelectItem>
                </SelectContent>
              </Select>
              {authSection}
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-gray-300 hover:text-white hover:bg-white/10 focus:outline-none focus:ring-2 focus:ring-[#d4af37]"
                aria-label="Toggle mobile menu"
                aria-expanded={isMenuOpen}
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </Button>
            </div>
          </div>

          {/* Mobile Menu */}
          <div className={`md:hidden border-t border-gray-700 transition-all duration-300 ease-in-out ${
            isMenuOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0 overflow-hidden'
          }`}>
            {/* Mobile Navigation Links */}
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              {navLinks.map((item) => (
                <Link 
                  key={item.name}
                  href={item.href} 
                  prefetch={false}
                  className={`block px-3 py-2 text-base font-medium rounded-md transition-colors ${
                    router.pathname === item.href
                      ? "text-[#d4af37] bg-white/10"
                      : "text-gray-300 hover:text-white hover:bg-white/10"
                  }`}
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.name}
                </Link>
              ))}
            </div>

            {/* Mobile Currency Selector */}
            <div className="px-4 pb-2 border-t border-gray-700">
              <div className="py-2">
                <Select value={currency} onValueChange={setCurrency}>
                  <SelectTrigger className="w-full bg-transparent text-white border-gray-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="PKR">PKR</SelectItem>
                    <SelectItem value="USD">USD</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Mobile Auth Section */}
            <div className="border-t border-gray-700">
              {mobileAuthSection}
            </div>
          </div>
        </div>
      </header>

      <main>{children}</main>

      {/* Footer */}
      <footer className="bg-[#101c2c] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <Link 
                href="/" 
                className="flex items-center space-x-3 mb-4 hover:opacity-80 transition-opacity focus:outline-none focus:ring-2 focus:ring-[#d4af37] rounded-md p-1"
              >
                <Image 
                  src="/Logo-Rehma-sqaure.png" 
                  alt="Rehma" 
                  width={32}
                  height={32}
                  className="h-8 w-8 object-contain"
                />
                <div>
                  <h3 className="text-lg font-bold">Rehma</h3>
                  <p className="text-xs text-gray-400">Infinite Blessings Here & After</p>
                </div>
              </Link>
              <p className="text-gray-400 mb-4 max-w-md">
                Connecting hearts and changing lives through compassionate giving. 
                Every donation brings hope and healing to children in need.
              </p>
              <div className="flex space-x-4">
                <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white hover:bg-white/10">
                  <Facebook className="h-5 w-5" />
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white hover:bg-white/10">
                  <Twitter className="h-5 w-5" />
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white hover:bg-white/10">
                  <Instagram className="h-5 w-5" />
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white hover:bg-white/10">
                  <Linkedin className="h-5 w-5" />
                </Button>
              </div>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                {navLinks.map((item) => (
                  <li key={item.name}>
                    <Link 
                      href={item.href}
                      prefetch={false}
                      className="text-gray-400 hover:text-white transition-colors duration-200 text-left hover:underline focus:outline-none focus:ring-2 focus:ring-[#d4af37] rounded px-1"
                    >
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Resources</h4>
              <ul className="space-y-2">
                {footerLinks.map((item) => (
                  <li key={item.name}>
                    <Link 
                      href={item.href}
                      prefetch={false}
                      className="text-gray-400 hover:text-white transition-colors duration-200 text-left hover:underline focus:outline-none focus:ring-2 focus:ring-[#d4af37] rounded px-1"
                    >
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
              <div className="mt-4 space-y-2">
                <Link 
                  href="/privacy"
                  prefetch={false}
                  className="block text-gray-400 hover:text-white text-sm transition-colors duration-200 hover:underline focus:outline-none focus:ring-2 focus:ring-[#d4af37] rounded px-1"
                >
                  Privacy Policy
                </Link>
                <Link 
                  href="/terms"
                  prefetch={false}
                  className="block text-gray-400 hover:text-white text-sm transition-colors duration-200 hover:underline focus:outline-none focus:ring-2 focus:ring-[#d4af37] rounded px-1"
                >
                  Terms of Service
                </Link>
              </div>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Contact</h4>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <Mail className="h-4 w-4 text-gray-400" />
                  <span className="text-gray-400">info@rehma.ai</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Phone className="h-4 w-4 text-gray-400" />
                  <span className="text-gray-400">+1 (555) 123-4567</span>
                </div>
                <div className="flex items-center space-x-3">
                  <MapPin className="h-4 w-4 text-gray-400" />
                  <span className="text-gray-400">Global Operations</span>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-700 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2025 Rehma. All rights reserved.
            </p>
            <div className="flex flex-wrap justify-center md:justify-end gap-4 mt-4 md:mt-0">
              <span className="text-gray-500 text-sm">Made with ❤️ for children in need</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
