import { useState, useEffect } from "react";
import { formatDate } from "@/lib/dateUtils";

interface ClientOnlyDateProps {
  date: string | Date;
  format?: (date: Date) => string;
}

const ClientOnlyDate: React.FC<ClientOnlyDateProps> = ({ date, format }) => {
  const [hasMounted, setHasMounted] = useState(false);

  useEffect(() => {
    setHasMounted(true);
  }, []);

  if (!hasMounted) {
    // Render a placeholder on the server and during initial client render
    return <span>...</span>;
  }

  const dateObj = typeof date === "string" ? new Date(date) : date;

  if (isNaN(dateObj.getTime())) {
    return <span>Invalid date</span>;
  }

  // Use a provided format function, otherwise default to a safe, non-locale format
  const displayDate = format ? format(dateObj) : formatDate(dateObj, "yyyy-MM-dd");

  return <span>{displayDate}</span>;
};

export default ClientOnlyDate;