import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { CreditCard, Smartphone, Building2, Banknote } from "lucide-react";
import { payproService } from "@/services/payproService";
import { useAuth } from "@/contexts/AuthContext";
import { formatNumber } from "@/lib/number";

interface PayProPaymentFormProps {
  amount: number;
  childId: string;
  childName: string;
  anonymous: boolean;
  message: string;
  onError: (error: string) => void;
  onSuccess: (data: { order_id: string, payment_method: "bank" }) => void;
}

export default function PayProPaymentForm({
  amount,
  childId,
  childName,
  anonymous,
  message,
  onError,
  onSuccess,
}: PayProPaymentFormProps) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [donorInfo, setDonorInfo] = useState({
    name: user?.user_metadata?.full_name || "",
    email: user?.email || "",
    phone: "",
  });

  const handlePayment = async () => {
    if (!donorInfo.name || !donorInfo.email) {
      onError("Please fill in all required fields");
      return;
    }

    setLoading(true);

    try {
      const orderId = payproService.generateOrderId();
      // Directly call onSuccess to pass data to the parent DonationModal
      onSuccess({ 
        order_id: orderId, 
        payment_method: "bank" 
      });
    } catch (error) {
      console.error("Error initiating PayPro payment", error);
      onError("Failed to initiate PayPro payment. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CreditCard className="h-5 w-5" />
          Secure Payment - PayPro
        </CardTitle>
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Amount:</span>
          <Badge variant="secondary" className="text-lg font-bold">
            PKR {formatNumber(amount)}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="donor-name">Full Name *</Label>
          <Input
            id="donor-name"
            type="text"
            placeholder="Enter your full name"
            value={donorInfo.name}
            onChange={(e) => setDonorInfo({ ...donorInfo, name: e.target.value })}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="donor-email">Email Address *</Label>
          <Input
            id="donor-email"
            type="email"
            placeholder="Enter your email"
            value={donorInfo.email}
            onChange={(e) => setDonorInfo({ ...donorInfo, email: e.target.value })}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="donor-phone">Phone Number (Optional)</Label>
          <Input
            id="donor-phone"
            type="tel"
            placeholder="03XX-XXXXXXX"
            value={donorInfo.phone}
            onChange={(e) => setDonorInfo({ ...donorInfo, phone: e.target.value })}
          />
        </div>

        <Separator />

        <div className="space-y-3">
          <h4 className="font-medium text-sm">Available Payment Methods:</h4>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="flex items-center gap-2 p-2 bg-muted rounded">
              <CreditCard className="h-4 w-4" />
              <span>Credit/Debit Cards</span>
            </div>
            <div className="flex items-center gap-2 p-2 bg-muted rounded">
              <Smartphone className="h-4 w-4" />
              <span>Mobile Wallets</span>
            </div>
            <div className="flex items-center gap-2 p-2 bg-muted rounded">
              <Building2 className="h-4 w-4" />
              <span>Bank Transfer</span>
            </div>
            <div className="flex items-center gap-2 p-2 bg-muted rounded">
              <Banknote className="h-4 w-4" />
              <span>Easy Paisa</span>
            </div>
          </div>
        </div>

        <Button
          onClick={handlePayment}
          disabled={loading || !donorInfo.name || !donorInfo.email}
          className="w-full"
          size="lg"
        >
          {loading ? "Processing..." : `Donate PKR ${formatNumber(amount)}`}
        </Button>

        <p className="text-xs text-muted-foreground text-center">
          You will be redirected to PayPro's secure payment page to complete your donation.
          Your payment is protected by bank-level security.
        </p>
      </CardContent>
    </Card>
  );
}
