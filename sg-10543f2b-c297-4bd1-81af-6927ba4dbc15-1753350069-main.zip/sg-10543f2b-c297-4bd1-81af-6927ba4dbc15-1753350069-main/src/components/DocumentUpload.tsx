import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Upload, File, X, CheckCircle, Clock, XCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Tables } from "@/integrations/supabase/types";

interface DocumentUploadProps {
  entityType: "child" | "doctor" | "ngo" | "shop" | "parent";
  entityId: string;
  requiredDocuments: DocumentRequirement[];
  onUploadComplete?: () => void;
}

interface DocumentRequirement {
  type: string;
  label: string;
  description: string;
  required: boolean;
  acceptedFormats: string[];
  maxSize: number; // in MB
}

type UploadedDocument = Tables<"documents">;

export default function DocumentUpload({ 
  entityType, 
  entityId, 
  requiredDocuments, 
  onUploadComplete 
}: DocumentUploadProps) {
  const { user } = useAuth();
  const [uploadedDocs, setUploadedDocs] = useState<UploadedDocument[]>([]);
  const [uploading, setUploading] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRefs = useRef<{ [key: string]: HTMLInputElement | null }>({});

  const handleFileUpload = async (docType: string, file: File) => {
    if (!user) return;

    setUploading(docType);
    setError(null);

    try {
      // Upload file to Supabase Storage
      const fileExt = file.name.split(".").pop();
      const fileName = `${entityType}/${entityId}/${docType}_${Date.now()}.${fileExt}`;
      
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from("documents")
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      // Save document record to database
      const { data: docData, error: docError } = await supabase
        .from("documents")
        .insert({
          entity_type: entityType,
          entity_id: entityId,
          document_type: docType,
          file_name: file.name,
          file_path: uploadData.path,
          file_size: file.size,
          mime_type: file.type,
          uploaded_by: user.id,
        })
        .select()
        .single();

      if (docError) throw docError;

      // Update local state
      if (docData) {
        setUploadedDocs(prev => [...prev, docData]);
      }
      
      // Clear file input
      const inputRef = fileInputRefs.current[docType];
      if (inputRef) {
        inputRef.value = "";
      }

      onUploadComplete?.();
    } catch (err) {
      console.error("Upload error:", err);
      setError(err instanceof Error ? err.message : "Upload failed");
    } finally {
      setUploading(null);
    }
  };

  const removeDocument = async (docId: string) => {
    try {
      const { error } = await supabase
        .from("documents")
        .delete()
        .eq("id", docId);

      if (error) throw error;

      setUploadedDocs(prev => prev.filter(doc => doc.id !== docId));
    } catch (err) {
      console.error("Remove error:", err);
      setError(err instanceof Error ? err.message : "Failed to remove document");
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "approved":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "rejected":
        return <XCircle className="h-4 w-4 text-red-500" />;
      default:
        return <Clock className="h-4 w-4 text-yellow-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved":
        return "bg-green-100 text-green-800";
      case "rejected":
        return "bg-red-100 text-red-800";
      default:
        return "bg-yellow-100 text-yellow-800";
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Upload className="h-5 w-5" />
          Document Upload
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {requiredDocuments.map((requirement) => {
          const uploadedDoc = uploadedDocs.find(doc => doc.document_type === requirement.type);
          const isUploading = uploading === requirement.type;

          return (
            <div key={requirement.type} className="space-y-3">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <Label className="text-sm font-medium">
                    {requirement.label}
                    {requirement.required && <span className="text-red-500 ml-1">*</span>}
                  </Label>
                  <p className="text-xs text-gray-600 mt-1">{requirement.description}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    Accepted: {requirement.acceptedFormats.join(", ")} | Max size: {requirement.maxSize}MB
                  </p>
                </div>
              </div>

              {uploadedDoc ? (
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <File className="h-4 w-4 text-gray-500" />
                    <div>
                      <p className="text-sm font-medium">{uploadedDoc.file_name}</p>
                      <div className="flex items-center gap-2 mt-1">
                        {getStatusIcon(uploadedDoc.status)}
                        <Badge variant="secondary" className={getStatusColor(uploadedDoc.status)}>
                          {uploadedDoc.status}
                        </Badge>
                      </div>
                      {uploadedDoc.review_notes && (
                        <p className="text-xs text-gray-600 mt-1">{uploadedDoc.review_notes}</p>
                      )}
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeDocument(uploadedDoc.id)}
                    className="text-red-500 hover:text-red-700"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <div className="flex items-center gap-3">
                  <Input
                    ref={(el) => { fileInputRefs.current[requirement.type] = el; }}
                    type="file"
                    accept={requirement.acceptedFormats.map(format => `.${format}`).join(",")}
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        if (file.size > requirement.maxSize * 1024 * 1024) {
                          setError(`File size exceeds ${requirement.maxSize}MB limit`);
                          return;
                        }
                        handleFileUpload(requirement.type, file);
                      }
                    }}
                    disabled={isUploading}
                    className="flex-1"
                  />
                  {isUploading && (
                    <div className="text-sm text-blue-600">Uploading...</div>
                  )}
                </div>
              )}
            </div>
          );
        })}

        <div className="pt-4 border-t">
          <p className="text-sm text-gray-600">
            All required documents must be uploaded and approved before your {entityType} profile becomes active.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
