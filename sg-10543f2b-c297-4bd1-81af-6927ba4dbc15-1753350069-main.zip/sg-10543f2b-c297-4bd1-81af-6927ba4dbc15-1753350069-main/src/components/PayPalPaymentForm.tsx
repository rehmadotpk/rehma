
import { useState } from "react";
import { PayPalScriptProvider, PayPalButtons } from "@paypal/react-paypal-js";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// Define the type locally to avoid import issues
interface OnApproveData {
  orderID: string;
  payerID?: string;
  paymentID?: string;
  billingToken?: string;
  subscriptionID?: string;
}

interface PayPalPaymentFormProps {
  amount: number;
  currency: string;
  childId: string;
  donorName: string;
  donorEmail: string;
  donorPhone?: string;
  message?: string;
  anonymous?: boolean;
  onSuccess: (transactionId: string) => void;
  onError: (error: string) => void;
}

export default function PayPalPaymentForm({
  amount,
  currency,
  childId,
  donorName,
  donorEmail,
  donorPhone,
  message,
  anonymous,
  onSuccess,
  onError
}: PayPalPaymentFormProps) {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const paypalOptions = {
    clientId: process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID || "",
    currency: currency,
    intent: "capture"
  };

  const createOrder = async () => {
    try {
      const response = await fetch('/api/payments/paypal/create-order', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount,
          currency,
          childId,
          donorName,
          donorEmail,
          donorPhone,
          message,
          anonymous
        }),
      });

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to create PayPal order');
      }

      return data.orderID;
    } catch (error) {
      console.error('Error creating PayPal order:', error);
      onError(error instanceof Error ? error.message : 'Failed to create order');
      throw error;
    }
  };

  const onApprove = async (data: OnApproveData) => {
    try {
      setLoading(true);
      
      const response = await fetch('/api/payments/paypal/capture-order', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          orderID: data.orderID,
          childId,
          donorEmail,
        }),
      });

      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.error || 'Failed to capture PayPal payment');
      }

      toast({
        title: "Payment Successful!",
        description: "Your donation has been processed successfully.",
      });

      onSuccess(result.transactionId);
    } catch (error) {
      console.error('Error capturing PayPal payment:', error);
      onError(error instanceof Error ? error.message : 'Payment failed');
    } finally {
      setLoading(false);
    }
  };

  const onPayPalError = (error: Record<string, unknown>) => {
    console.error('PayPal error:', error);
    onError('PayPal payment failed. Please try again.');
  };

  if (!process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-red-600">PayPal is not configured. Please contact support.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <span className="text-blue-600 font-bold mr-2">PayPal</span>
          Payment
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
            <h4 className="font-medium text-blue-900 mb-2">Payment Summary</h4>
            <div className="space-y-1 text-sm text-blue-800">
              <div className="flex justify-between">
                <span>Amount:</span>
                <span className="font-semibold">{currency} {amount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Payment Method:</span>
                <span>PayPal</span>
              </div>
            </div>
          </div>

          {loading && (
            <div className="flex items-center justify-center py-4">
              <Loader2 className="w-6 h-6 animate-spin mr-2" />
              <span>Processing payment...</span>
            </div>
          )}

          <PayPalScriptProvider options={paypalOptions}>
            <PayPalButtons
              style={{
                layout: "vertical",
                color: "blue",
                shape: "rect",
                label: "donate"
              }}
              createOrder={createOrder}
              onApprove={onApprove}
              onError={onPayPalError}
              disabled={loading}
            />
          </PayPalScriptProvider>

          <div className="text-xs text-gray-500 text-center">
            <p>Secure payment powered by PayPal</p>
            <p>Your payment information is encrypted and secure</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
