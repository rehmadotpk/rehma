import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Phone, Mail, MessageSquare, Copy } from "lucide-react";
import { Doctor } from "@/services/doctorService";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";

interface DoctorContactModalProps {
  doctor: Doctor;
  isOpen: boolean;
  onClose: () => void;
}

export default function DoctorContactModal({
  doctor,
  isOpen,
  onClose,
}: DoctorContactModalProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [messageData, setMessageData] = useState({
    name: user?.user_metadata?.full_name || "",
    email: user?.email || "",
    phone: "",
    subject: "",
    message: "",
  });

  const handlePhoneCall = () => {
    if (doctor.phone) {
      window.location.href = `tel:${doctor.phone}`;
    } else {
      toast({
        title: "Phone not available",
        description: "This doctor's phone number is not publicly available.",
        variant: "destructive",
      });
    }
  };

  const handleEmailContact = () => {
    if (doctor.email) {
      const subject = encodeURIComponent(`Consultation Request - ${doctor.name}`);
      const body = encodeURIComponent(`Dear Dr. ${doctor.name},\n\nI would like to schedule a consultation regarding pediatric care.\n\nBest regards,\n${messageData.name}`);
      window.location.href = `mailto:${doctor.email}?subject=${subject}&body=${body}`;
    } else {
      toast({
        title: "Email not available",
        description: "This doctor's email is not publicly available.",
        variant: "destructive",
      });
    }
  };

  const handleSendMessage = async () => {
    if (!messageData.name || !messageData.email || !messageData.message) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);

    try {
      const response = await fetch("/api/doctors/contact", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          doctorId: doctor.id,
          senderName: messageData.name,
          senderEmail: messageData.email,
          senderPhone: messageData.phone,
          subject: messageData.subject || `Consultation Request`,
          message: messageData.message,
        }),
      });

      if (response.ok) {
        toast({
          title: "Message Sent!",
          description: "Your message has been sent to the doctor. They will contact you soon.",
        });
        onClose();
      } else {
        throw new Error("Failed to send message");
      }
    } catch (err) {
      console.error("Failed to send message:", err);
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const copyContact = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: `${type} copied to clipboard`,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-blue-500" />
            Contact Dr. {doctor.name}
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="quick" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="quick">Quick Contact</TabsTrigger>
            <TabsTrigger value="message">Send Message</TabsTrigger>
            <TabsTrigger value="info">Contact Info</TabsTrigger>
          </TabsList>

          <TabsContent value="quick" className="space-y-4">
            <div className="grid gap-4">
              <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={handlePhoneCall}>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                      <Phone className="w-6 h-6 text-green-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold">Call Doctor</h4>
                      <p className="text-sm text-gray-600">Direct phone consultation</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={handleEmailContact}>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Mail className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold">Send Email</h4>
                      <p className="text-sm text-gray-600">Email consultation request</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => {
                const trigger = document.querySelector('button[data-radix-collection-item][value="message"]') as HTMLElement | null;
                trigger?.click();
              }}>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                      <MessageSquare className="w-6 h-6 text-purple-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold">Send Message</h4>
                      <p className="text-sm text-gray-600">Detailed message through platform</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="message" className="space-y-4">
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Your Name *</Label>
                  <Input
                    id="name"
                    value={messageData.name}
                    onChange={(e) => setMessageData({ ...messageData, name: e.target.value })}
                    placeholder="Enter your name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Your Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={messageData.email}
                    onChange={(e) => setMessageData({ ...messageData, email: e.target.value })}
                    placeholder="Enter your email"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="phone">Your Phone (Optional)</Label>
                  <Input
                    id="phone"
                    value={messageData.phone}
                    onChange={(e) => setMessageData({ ...messageData, phone: e.target.value })}
                    placeholder="03XX-XXXXXXX"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="subject">Subject (Optional)</Label>
                  <Input
                    id="subject"
                    value={messageData.subject}
                    onChange={(e) => setMessageData({ ...messageData, subject: e.target.value })}
                    placeholder="Consultation Request"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">Message *</Label>
                <Textarea
                  id="message"
                  value={messageData.message}
                  onChange={(e) => setMessageData({ ...messageData, message: e.target.value })}
                  placeholder="Describe your consultation needs, child's condition, or any specific questions..."
                  rows={4}
                />
              </div>

              <Button
                onClick={handleSendMessage}
                disabled={loading || !messageData.name || !messageData.email || !messageData.message}
                className="w-full"
              >
                {loading ? "Sending..." : "Send Message"}
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="info" className="space-y-4">
            <div className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-3">Dr. {doctor.name}</h4>
                <div className="space-y-2 text-sm">
                  <p><strong>Specialization:</strong> {doctor.specialization}</p>
                  <p><strong>Experience:</strong> {doctor.experience_years} years</p>
                  <p><strong>Location:</strong> {doctor.location}</p>
                  <p><strong>Qualification:</strong> {doctor.qualification}</p>
                </div>
              </div>

              {doctor.phone && (
                <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Phone className="w-4 h-4 text-green-600" />
                    <span className="font-medium">{doctor.phone}</span>
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => copyContact(doctor.phone as string, "Phone number")}
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
              )}

              {doctor.email && (
                <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-blue-600" />
                    <span className="font-medium">{doctor.email}</span>
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => copyContact(doctor.email as string, "Email address")}
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
              )}

              <div className="bg-yellow-50 p-3 rounded-lg">
                <p className="text-sm text-yellow-800">
                  <strong>Note:</strong> Response times may vary. For urgent medical situations, 
                  please contact emergency services or visit the nearest hospital.
                </p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
