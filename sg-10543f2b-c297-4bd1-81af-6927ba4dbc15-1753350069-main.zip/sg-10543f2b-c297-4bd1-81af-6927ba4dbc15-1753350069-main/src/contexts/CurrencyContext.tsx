import { createContext, useContext, useState, ReactNode, useMemo } from "react";

export type Currency = "PKR" | "USD" | "GBP";

interface CurrencyContextType {
  currency: Currency;
  setCurrency: (currency: Currency) => void;
  formatPrice: (amount: number) => string;
  convertAmount: (amount: number, from?: Currency, to?: Currency) => number;
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

interface CurrencyProviderProps {
  children: ReactNode;
}

export function CurrencyProvider({ children }: CurrencyProviderProps) {
  const [currency, setCurrency] = useState<Currency>("PKR");

  const conversionRates: Record<Currency, number> = {
    PKR: 1,
    USD: 278,
    GBP: 350,
  };

  const formatPrice = useMemo(() => {
    return (amount: number) => {
      return new Intl.NumberFormat("en-US", {
        style: "currency",
        currency: currency,
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
      }).format(amount);
    };
  }, [currency]);

  const convertAmount = (amount: number, from: Currency = "PKR", to: Currency = currency) => {
    const amountInPKR = amount * (conversionRates[from] || 1);
    return amountInPKR / (conversionRates[to] || 1);
  };

  const value = {
    currency,
    setCurrency,
    formatPrice,
    convertAmount,
  };

  return (
    <CurrencyContext.Provider value={value}>
      {children}
    </CurrencyContext.Provider>
  );
}

export const useCurrency = () => {
  const context = useContext(CurrencyContext);
  if (context === undefined) {
    throw new Error("useCurrency must be used within a CurrencyProvider");
  }
  return context;
};
