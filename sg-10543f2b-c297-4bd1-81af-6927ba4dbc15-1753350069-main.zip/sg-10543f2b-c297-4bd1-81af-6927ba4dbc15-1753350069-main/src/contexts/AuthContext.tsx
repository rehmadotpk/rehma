import {
  createContext,
  useContext,
  useEffect,
  useState,
  ReactNode,
  useCallback,
} from "react";
import { User, Session, AuthError } from "@supabase/supabase-js";
import {
  authService,
  UserProfile,
  SignUpData,
  SignInData,
} from "@/services/authService";
import { supabase } from "@/integrations/supabase/client";
import userService from "@/services/userService";

interface AuthResponse {
  data: {
    user: User | null;
    session: Session | null;
  };
  error: AuthError | null;
}

interface AuthContextType {
  user: User | null;
  userProfile: UserProfile | null;
  session: Session | null;
  loading: boolean;
  isAdmin: boolean;
  error: string | null;
  initialized: boolean;
  signUp: (data: SignUpData) => Promise<AuthResponse>;
  signIn: (data: SignInData) => Promise<AuthResponse>;
  signOut: () => Promise<void>;
  clearError: () => void;
  updateProfile: (
    updates: Partial<UserProfile>
  ) => Promise<UserProfile | null>;
  uploadAvatar: (file: File) => Promise<string | null>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  userProfile: null,
  session: null,
  loading: true,
  isAdmin: false,
  error: null,
  initialized: false,
  signUp: async () => ({ data: { user: null, session: null }, error: null }),
  signIn: async () => ({ data: { user: null, session: null }, error: null }),
  signOut: async () => {},
  clearError: () => {},
  updateProfile: async () => null,
  uploadAvatar: async () => null,
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [initialized, setInitialized] = useState(false);

  const clearError = () => setError(null);

  const fetchUserProfile = useCallback(async (user: User | null) => {
    if (!user) {
      setUserProfile(null);
      setIsAdmin(false);
      return;
    }
    try {
      const profile = await userService.getUserById(user.id);
      setUserProfile(profile);
      setIsAdmin(profile?.role === "admin");
    } catch (e) {
      console.error("Error fetching user profile:", e);
      setUserProfile(null);
      setIsAdmin(false);
    }
  }, []);

  useEffect(() => {
    const getInitialSession = async () => {
      try {
        const { data, error: sessionError } = await supabase.auth.getSession();
        
        if (sessionError) {
          console.error("Session error:", sessionError);
          // Clear any invalid session data
          await supabase.auth.signOut();
          setSession(null);
          setUser(null);
          setUserProfile(null);
          setIsAdmin(false);
        } else {
          setSession(data.session);
          setUser(data.session?.user ?? null);
          await fetchUserProfile(data.session?.user ?? null);
        }
      } catch (err) {
        console.error("Failed to get initial session:", err);
        // Clear session on error
        setSession(null);
        setUser(null);
        setUserProfile(null);
        setIsAdmin(false);
      } finally {
        setLoading(false);
        setInitialized(true);
      }
    };

    getInitialSession();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      console.log("Auth state changed:", event);
      
      // Handle token refresh errors
      if (event === 'TOKEN_REFRESHED') {
        console.log("Token refreshed successfully");
      } else if (event === 'SIGNED_OUT') {
        setSession(null);
        setUser(null);
        setUserProfile(null);
        setIsAdmin(false);
      }

      setSession(session);
      const currentUser = session?.user ?? null;
      setUser(currentUser);
      await fetchUserProfile(currentUser);
      
      if (!loading) setLoading(false);
      if (!initialized) setInitialized(true);
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [fetchUserProfile]);

  const signUp = async (data: SignUpData): Promise<AuthResponse> => {
    clearError();
    try {
      const response = await authService.signUp(data);
      const authResponse: AuthResponse = {
        data: {
          user: response.user,
          session: response.session
        },
        error: null
      };
      return authResponse;
    } catch (error) {
      const authError = error as AuthError;
      console.error("SignUp error:", authError);
      setError(authError.message || "An unexpected error occurred during sign up.");
      return { 
        data: { user: null, session: null }, 
        error: authError 
      };
    }
  };

  const signIn = async (data: SignInData): Promise<AuthResponse> => {
    clearError();
    try {
      const response = await authService.signIn(data);
      const authResponse: AuthResponse = {
        data: {
          user: response.user,
          session: response.session
        },
        error: null
      };
      return authResponse;
    } catch (error) {
      const authError = error as AuthError;
      console.error("SignIn error:", authError);
      setError(authError.message || "An unexpected error occurred during sign in.");
      return { 
        data: { user: null, session: null }, 
        error: authError 
      };
    }
  };

  const signOut = async () => {
    try {
      clearError();
      await authService.signOut();
      setUser(null);
      setSession(null);
      setUserProfile(null);
      setIsAdmin(false);
    } catch (err) {
      const authError = err as AuthError;
      console.error("SignOut error:", authError);
      setError(authError.message || "Sign out failed");
    }
  };

  const updateProfile = async (updates: Partial<UserProfile>) => {
    if (!user) return null;
    const updatedProfile = await userService.updateUser(user.id, updates);
    if (updatedProfile) {
      setUserProfile(updatedProfile);
    }
    return updatedProfile;
  };

  const uploadAvatar = async (file: File) => {
    // Dummy implementation
    console.log("uploadAvatar not implemented", file);
    return null;
  };

  const value = {
    user,
    userProfile,
    session,
    loading,
    isAdmin,
    error,
    initialized,
    signUp,
    signIn,
    signOut,
    clearError,
    updateProfile,
    uploadAvatar,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
