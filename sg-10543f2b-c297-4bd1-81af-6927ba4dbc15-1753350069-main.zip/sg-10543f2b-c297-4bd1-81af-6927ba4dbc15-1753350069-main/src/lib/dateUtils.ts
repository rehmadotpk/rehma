import { format } from "date-fns";

export function formatDate(date: string | Date, formatString = "yyyy-MM-dd"): string {
  try {
    const dateObj = typeof date === "string" ? new Date(date) : date;
    if (isNaN(dateObj.getTime())) {
      return "Invalid Date";
    }
    return format(dateObj, formatString);
  } catch (error) {
    console.error("Error formatting date:", error);
    return "Invalid Date";
  }
}

export const formatRelativeDate = (dateString: string): string => {
  if (typeof window === "undefined") {
    return "Recently added";
  }
  const date = new Date(dateString);
  const now = new Date();
  const diffInMs = now.getTime() - date.getTime();
  const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24));

  if (diffInDays === 0) return "Today";
  if (diffInDays === 1) return "1 day ago";
  if (diffInDays < 30) return `${diffInDays} days ago`;
  if (diffInDays < 365) {
    const months = Math.floor(diffInDays / 30);
    return months === 1 ? "1 month ago" : `${months} months ago`;
  }
  const years = Math.floor(diffInDays / 365);
  return years === 1 ? "1 year ago" : `${years} years ago`;
};

export const formatDateTime = (dateString: string, pattern = "MMM d, yyyy"): string => {
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return "Invalid Date";
  return format(date, pattern);
};

export const formatTime = (dateString: string, pattern = "HH:mm"): string => {
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return "Invalid Time";
  return format(date, pattern);
};

export const isValidDate = (dateString: string): boolean => {
  const date = new Date(dateString);
  return !isNaN(date.getTime());
};
