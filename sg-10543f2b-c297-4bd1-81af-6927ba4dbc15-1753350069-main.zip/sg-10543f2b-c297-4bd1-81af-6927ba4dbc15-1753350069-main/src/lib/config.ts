
// Production Configuration Management
export const config = {
  // Application
  app: {
    name: process.env.NEXT_PUBLIC_APP_NAME || 'Rehma Foundation',
    url: process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000',
    description: process.env.NEXT_PUBLIC_APP_DESCRIPTION || 'Infinite Blessings Here & After',
    environment: process.env.NEXT_PUBLIC_ENVIRONMENT || 'development',
  },

  // Database
  database: {
    url: process.env.NEXT_PUBLIC_SUPABASE_URL || '',
    anonKey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '',
    serviceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY || '',
  },

  // Payment Gateways
  payments: {
    paypro: {
      merchantId: process.env.PAYPRO_MERCHANT_ID || '',
      secretKey: process.env.PAYPRO_SECRET_KEY || '',
      apiUrl: process.env.PAYPRO_API_URL || 'https://api.paypro.com.pk',
      webhookSecret: process.env.PAYPRO_WEBHOOK_SECRET || '',
    },
    stripe: {
      publishableKey: process.env.STRIPE_PUBLISHABLE_KEY || "",
      secretKey: process.env.STRIPE_SECRET_KEY || "",
      webhookSecret: process.env.STRIPE_WEBHOOK_SECRET || "",
    },
    paypal: {
      clientId: process.env.PAYPAL_CLIENT_ID || "",
      clientSecret: process.env.PAYPAL_CLIENT_SECRET || "",
      webhookId: process.env.PAYPAL_WEBHOOK_ID || "",
    },
  },

  // Email Services
  email: {
    provider: process.env.EMAIL_PROVIDER || 'sendgrid', // sendgrid, mailgun, resend
    sendgrid: {
      apiKey: process.env.SENDGRID_API_KEY || '',
      fromEmail: process.env.SENDGRID_FROM_EMAIL || '',
      fromName: process.env.SENDGRID_FROM_NAME || '',
    },
    mailgun: {
      apiKey: process.env.MAILGUN_API_KEY || '',
      domain: process.env.MAILGUN_DOMAIN || '',
      fromEmail: process.env.MAILGUN_FROM_EMAIL || '',
    },
    resend: {
      apiKey: process.env.RESEND_API_KEY || '',
      fromEmail: process.env.RESEND_FROM_EMAIL || '',
    },
  },

  // Security
  security: {
    jwtSecret: process.env.JWT_SECRET || '',
    encryptionKey: process.env.ENCRYPTION_KEY || '',
    webhookSecret: process.env.WEBHOOK_SECRET || '',
  },

  // File Upload
  upload: {
    maxFileSize: parseInt(process.env.NEXT_PUBLIC_MAX_FILE_SIZE || '5242880'),
    allowedTypes: process.env.NEXT_PUBLIC_ALLOWED_FILE_TYPES?.split(',') || ['image/jpeg', 'image/png', 'image/webp'],
  },

  // Rate Limiting
  rateLimit: {
    maxRequests: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || '100'),
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '900000'),
  },

  // Features
  features: {
    maintenanceMode: process.env.ENABLE_MAINTENANCE_MODE === 'true',
    debugLogs: process.env.ENABLE_DEBUG_LOGS === 'true',
    gdprCompliance: process.env.GDPR_COMPLIANCE_ENABLED === 'true',
  },

  // External Services
  services: {
    googleAnalytics: process.env.GOOGLE_ANALYTICS_ID,
    sentry: process.env.SENTRY_DSN,
    firebase: process.env.FIREBASE_SERVER_KEY,
    twilio: {
      accountSid: process.env.TWILIO_ACCOUNT_SID,
      authToken: process.env.TWILIO_AUTH_TOKEN,
      phoneNumber: process.env.TWILIO_PHONE_NUMBER,
    },
  },
};

// Validation function to ensure required environment variables are set
export function validateConfig() {
  const requiredVars = [
    'NEXT_PUBLIC_SUPABASE_URL',
    'NEXT_PUBLIC_SUPABASE_ANON_KEY',
    'SUPABASE_SERVICE_ROLE_KEY',
  ];

  const missingVars = requiredVars.filter(varName => !process.env[varName]);

  if (missingVars.length > 0) {
    throw new Error(`Missing required environment variables: ${missingVars.join(', ')}`);
  }

  // Validate payment gateway configuration
  if (config.app.environment === "production") {
    const paymentVars = [
      "PAYPRO_MERCHANT_ID",
      "PAYPRO_SECRET_KEY",
      "STRIPE_PUBLISHABLE_KEY",
      "STRIPE_SECRET_KEY",
      "PAYPAL_CLIENT_ID",
      "PAYPAL_CLIENT_SECRET",
    ];

    const missingPaymentVars = paymentVars.filter(varName => !process.env[varName]);
    
    if (missingPaymentVars.length > 0) {
      console.warn(`Warning: Missing payment gateway variables: ${missingPaymentVars.join(', ')}`);
    }
  }

  // Validate email service configuration
  const emailProvider = process.env.EMAIL_PROVIDER || 'sendgrid';
  const emailVars = {
    sendgrid: ['SENDGRID_API_KEY', 'SENDGRID_FROM_EMAIL'],
    mailgun: ['MAILGUN_API_KEY', 'MAILGUN_DOMAIN'],
    resend: ['RESEND_API_KEY', 'RESEND_FROM_EMAIL'],
  };

  const requiredEmailVars = emailVars[emailProvider as keyof typeof emailVars] || [];
  const missingEmailVars = requiredEmailVars.filter(varName => !process.env[varName]);

  if (missingEmailVars.length > 0) {
    console.warn(`Warning: Missing email service variables for ${emailProvider}: ${missingEmailVars.join(', ')}`);
  }
}

export default config;
