
export interface EmailTemplate {
  subject: string;
  html: string;
  text: string;
}

export const emailTemplates = {
  donationConfirmation: (data: {
    donorName: string;
    childName: string;
    amount: number;
    currency: string;
    donationId: string;
  }): EmailTemplate => ({
    subject: `Thank you for your donation to ${data.childName}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <img src="https://your-domain.com/logo.png" alt="Rehma Foundation" style="height: 60px;">
          <h1 style="color: #101c2c; margin-top: 20px;">Thank You for Your Donation!</h1>
        </div>
        
        <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
          <h2 style="color: #101c2c; margin-top: 0;">Donation Details</h2>
          <p><strong>Donor:</strong> ${data.donorName}</p>
          <p><strong>Child:</strong> ${data.childName}</p>
          <p><strong>Amount:</strong> ${data.currency} ${data.amount.toLocaleString()}</p>
          <p><strong>Donation ID:</strong> ${data.donationId}</p>
        </div>
        
        <p>Dear ${data.donorName},</p>
        <p>Thank you for your generous donation to help ${data.childName}. Your contribution will make a real difference in their life and bring them one step closer to receiving the medical care they need.</p>
        
        <p>We will keep you updated on ${data.childName}'s progress and how your donation is being used.</p>
        
        <div style="background: #d4af37; color: white; padding: 15px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 0; text-align: center;"><strong>Your donation is making a difference!</strong></p>
        </div>
        
        <p>With gratitude,<br>The Rehma Foundation Team</p>
        
        <div style="border-top: 1px solid #eee; padding-top: 20px; margin-top: 30px; text-align: center; color: #666; font-size: 12px;">
          <p>Rehma Foundation - Infinite Blessings Here & After</p>
          <p>If you have any questions, please contact us at info@rehma.ai</p>
        </div>
      </div>
    `,
    text: `
      Thank You for Your Donation!
      
      Dear ${data.donorName},
      
      Thank you for your generous donation to help ${data.childName}. 
      
      Donation Details:
      - Child: ${data.childName}
      - Amount: ${data.currency} ${data.amount.toLocaleString()}
      - Donation ID: ${data.donationId}
      
      Your contribution will make a real difference in their life and bring them one step closer to receiving the medical care they need.
      
      We will keep you updated on ${data.childName}'s progress and how your donation is being used.
      
      With gratitude,
      The Rehma Foundation Team
      
      Rehma Foundation - Infinite Blessings Here & After
      If you have any questions, please contact us at info@rehma.ai
    `
  }),

  welcomeEmail: (data: {
    userName: string;
    userEmail: string;
  }): EmailTemplate => ({
    subject: 'Welcome to Rehma Foundation',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <img src="https://your-domain.com/logo.png" alt="Rehma Foundation" style="height: 60px;">
          <h1 style="color: #101c2c; margin-top: 20px;">Welcome to Rehma Foundation!</h1>
        </div>
        
        <p>Dear ${data.userName},</p>
        <p>Welcome to the Rehma Foundation community! We're thrilled to have you join us in our mission to provide life-saving medical care to children in need.</p>
        
        <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="color: #101c2c; margin-top: 0;">What you can do:</h3>
          <ul>
            <li>Browse children who need medical assistance</li>
            <li>Make secure donations to support their treatment</li>
            <li>Track the impact of your contributions</li>
            <li>Shop for artwork created by talented children</li>
            <li>Connect with verified doctors and NGOs</li>
          </ul>
        </div>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="https://your-domain.com/children" style="background: #d4af37; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold;">Start Making a Difference</a>
        </div>
        
        <p>Together, we can bring hope and healing to children across Pakistan.</p>
        
        <p>With gratitude,<br>The Rehma Foundation Team</p>
        
        <div style="border-top: 1px solid #eee; padding-top: 20px; margin-top: 30px; text-align: center; color: #666; font-size: 12px;">
          <p>Rehma Foundation - Infinite Blessings Here & After</p>
          <p>If you have any questions, please contact us at info@rehma.ai</p>
        </div>
      </div>
    `,
    text: `
      Welcome to Rehma Foundation!
      
      Dear ${data.userName},
      
      Welcome to the Rehma Foundation community! We're thrilled to have you join us in our mission to provide life-saving medical care to children in need.
      
      What you can do:
      - Browse children who need medical assistance
      - Make secure donations to support their treatment
      - Track the impact of your contributions
      - Shop for artwork created by talented children
      - Connect with verified doctors and NGOs
      
      Together, we can bring hope and healing to children across Pakistan.
      
      Visit https://your-domain.com/children to start making a difference.
      
      With gratitude,
      The Rehma Foundation Team
      
      Rehma Foundation - Infinite Blessings Here & After
      If you have any questions, please contact us at info@rehma.ai
    `
  }),

  childUpdateNotification: (data: {
    donorName: string;
    childName: string;
    updateMessage: string;
  }): EmailTemplate => ({
    subject: `Update on ${data.childName} - Your donation is making a difference`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="text-align: center; margin-bottom: 30px;">
          <img src="https://your-domain.com/logo.png" alt="Rehma Foundation" style="height: 60px;">
          <h1 style="color: #101c2c; margin-top: 20px;">Update on ${data.childName}</h1>
        </div>
        
        <p>Dear ${data.donorName},</p>
        <p>We have an important update about ${data.childName}, whom you generously supported with your donation.</p>
        
        <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="color: #101c2c; margin-top: 0;">Latest Update:</h3>
          <p>${data.updateMessage}</p>
        </div>
        
        <p>Your contribution has been instrumental in making this progress possible. Thank you for being part of ${data.childName}'s journey to recovery.</p>
        
        <div style="background: #d4af37; color: white; padding: 15px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 0; text-align: center;"><strong>Your support is changing lives!</strong></p>
        </div>
        
        <p>With gratitude,<br>The Rehma Foundation Team</p>
        
        <div style="border-top: 1px solid #eee; padding-top: 20px; margin-top: 30px; text-align: center; color: #666; font-size: 12px;">
          <p>Rehma Foundation - Infinite Blessings Here & After</p>
          <p>If you have any questions, please contact us at info@rehma.ai</p>
        </div>
      </div>
    `,
    text: `
      Update on ${data.childName}
      
      Dear ${data.donorName},
      
      We have an important update about ${data.childName}, whom you generously supported with your donation.
      
      Latest Update:
      ${data.updateMessage}
      
      Your contribution has been instrumental in making this progress possible. Thank you for being part of ${data.childName}'s journey to recovery.
      
      With gratitude,
      The Rehma Foundation Team
      
      Rehma Foundation - Infinite Blessings Here & After
      If you have any questions, please contact us at info@rehma.ai
    `
  })
};

export default emailTemplates;
