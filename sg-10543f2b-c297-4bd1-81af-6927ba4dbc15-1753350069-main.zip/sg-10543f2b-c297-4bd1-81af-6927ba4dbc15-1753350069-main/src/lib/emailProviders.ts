
import { config } from './config';

export interface EmailProvider {
  sendEmail(data: EmailData): Promise<EmailResult>;
  sendBulkEmails(emails: EmailData[]): Promise<EmailResult[]>;
}

export interface EmailData {
  to: string | string[];
  subject: string;
  html: string;
  text: string;
  from?: string;
  replyTo?: string;
  attachments?: EmailAttachment[];
}

export interface EmailAttachment {
  filename: string;
  content: string | Buffer;
  contentType?: string;
}

export interface EmailResult {
  success: boolean;
  messageId?: string;
  error?: string;
}

// SendGrid Provider
export class SendGridProvider implements EmailProvider {
  private apiKey: string;
  private fromEmail: string;
  private fromName: string;

  constructor() {
    this.apiKey = config.email.sendgrid.apiKey;
    this.fromEmail = config.email.sendgrid.fromEmail;
    this.fromName = config.email.sendgrid.fromName;
  }

  async sendEmail(data: EmailData): Promise<EmailResult> {
    try {
      const sgMail = await import('@sendgrid/mail');
      sgMail.default.setApiKey(this.apiKey);

      const msg = {
        to: Array.isArray(data.to) ? data.to : [data.to],
        from: {
          email: data.from || this.fromEmail,
          name: this.fromName,
        },
        subject: data.subject,
        text: data.text,
        html: data.html,
        replyTo: data.replyTo,
        attachments: data.attachments?.map(att => ({
          filename: att.filename,
          content: att.content.toString('base64'),
          type: att.contentType,
          disposition: 'attachment',
        })),
      };

      const response = await sgMail.default.send(msg);
      
      return {
        success: true,
        messageId: response[0].headers['x-message-id'] as string,
      };
    } catch (error) {
      console.error('SendGrid error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'SendGrid error',
      };
    }
  }

  async sendBulkEmails(emails: EmailData[]): Promise<EmailResult[]> {
    const results: EmailResult[] = [];
    
    for (const email of emails) {
      const result = await this.sendEmail(email);
      results.push(result);
    }
    
    return results;
  }
}

// Mailgun Provider
export class MailgunProvider implements EmailProvider {
  private apiKey: string;
  private domain: string;
  private fromEmail: string;

  constructor() {
    this.apiKey = config.email.mailgun.apiKey;
    this.domain = config.email.mailgun.domain;
    this.fromEmail = config.email.mailgun.fromEmail;
  }

  async sendEmail(data: EmailData): Promise<EmailResult> {
    try {
      const formData = new FormData();
      formData.append('from', data.from || this.fromEmail);
      formData.append('to', Array.isArray(data.to) ? data.to.join(',') : data.to);
      formData.append('subject', data.subject);
      formData.append('text', data.text);
      formData.append('html', data.html);
      
      if (data.replyTo) {
        formData.append('h:Reply-To', data.replyTo);
      }

      // Add attachments if any
      data.attachments?.forEach((attachment, index) => {
        formData.append(`attachment[${index}]`, new Blob([attachment.content], { 
          type: attachment.contentType 
        }), attachment.filename);
      });

      const response = await fetch(`https://api.mailgun.net/v3/${this.domain}/messages`, {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${Buffer.from(`api:${this.apiKey}`).toString('base64')}`,
        },
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`Mailgun API error: ${response.statusText}`);
      }

      const result = await response.json();
      
      return {
        success: true,
        messageId: result.id,
      };
    } catch (error) {
      console.error('Mailgun error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Mailgun error',
      };
    }
  }

  async sendBulkEmails(emails: EmailData[]): Promise<EmailResult[]> {
    const results: EmailResult[] = [];
    
    for (const email of emails) {
      const result = await this.sendEmail(email);
      results.push(result);
    }
    
    return results;
  }
}

// Resend Provider
export class ResendProvider implements EmailProvider {
  private apiKey: string;
  private fromEmail: string;

  constructor() {
    this.apiKey = config.email.resend.apiKey;
    this.fromEmail = config.email.resend.fromEmail;
  }

  async sendEmail(data: EmailData): Promise<EmailResult> {
    try {
      const payload = {
        from: data.from || this.fromEmail,
        to: Array.isArray(data.to) ? data.to : [data.to],
        subject: data.subject,
        text: data.text,
        html: data.html,
        reply_to: data.replyTo,
        attachments: data.attachments?.map(att => ({
          filename: att.filename,
          content: att.content,
          content_type: att.contentType,
        })),
      };

      const response = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(`Resend API error: ${response.statusText}`);
      }

      const result = await response.json();
      
      return {
        success: true,
        messageId: result.id,
      };
    } catch (error) {
      console.error('Resend error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Resend error',
      };
    }
  }

  async sendBulkEmails(emails: EmailData[]): Promise<EmailResult[]> {
    const results: EmailResult[] = [];
    
    for (const email of emails) {
      const result = await this.sendEmail(email);
      results.push(result);
    }
    
    return results;
  }
}

// Factory function to get the appropriate email provider
export function getEmailProvider(): EmailProvider {
  const provider = config.email.provider;
  
  switch (provider) {
    case 'sendgrid':
      return new SendGridProvider();
    case 'mailgun':
      return new MailgunProvider();
    case 'resend':
      return new ResendProvider();
    default:
      throw new Error(`Unsupported email provider: ${provider}`);
  }
}
