import Stripe, { Stripe as StripeTypes } from "stripe";
import { PayPro } from "./paypro";
import config from "./config";
import * as paypal from "@paypal/checkout-server-sdk";
import { payproService } from "@/services/payproService";

// --- TYPE DEFINITIONS ---

interface PayPalError extends Error {
  statusCode: number;
  result: unknown;
}

export interface PaymentGateway {
  createPayment(data: PaymentData): Promise<PaymentResult>;
  verifyPayment(data: VerificationData): Promise<VerificationResult>;
  refundPayment(data: RefundData): Promise<RefundResult>;
}

export interface PaymentData {
  amount: number;
  currency: string;
  orderId: string;
  description: string;
  customerName: string;
  customerEmail: string;
  customerPhone?: string;
  returnUrl: string;
  cancelUrl: string;
  metadata?: Record<string, unknown>;
}

export interface PaymentResult {
  success: boolean;
  paymentUrl?: string;
  transactionId?: string;
  error?: string;
}

export interface VerificationData {
  transactionId: string;
  orderId: string;
  signature?: string;
  rawData?: Record<string, unknown>;
}

export interface VerificationResult {
  success: boolean;
  status: "pending" | "completed" | "failed" | "cancelled";
  amount?: number;
  currency?: string;
  error?: string;
}

export interface RefundData {
  transactionId: string;
  amount: number;
  reason?: string;
}

export interface RefundResult {
  success: boolean;
  refundId?: string;
  error?: string;
}

type PaymentPayload = {
  amount: number;
  currency: string;
  customerId?: string;
  paymentMethodId?: string;
  metadata?: Record<string, string>;
};

type SubscriptionPayload = {
  customerId: string;
  priceId: string;
  paymentMethodId: string;
  metadata?: Record<string, string>;
};

interface PayProPaymentDetails {
  amount: number;
  currency: string;
  email: string;
  metadata: Record<string, string | undefined>;
}

// --- CLIENT INITIALIZATION ---

const stripeClient = new Stripe(config.payments.stripe.secretKey, {
  apiVersion: "2025-02-24.acacia", // Use the latest supported API version
  typescript: true,
  appInfo: { name: "Rehma Foundation", version: "1.0.0" },
});

const paypro = new PayPro({
  merchantId: config.payments.paypro.merchantId,
  secretKey: config.payments.paypro.secretKey,
});

const paypalEnvironment =
  config.app.environment === "production"
    ? new paypal.core.LiveEnvironment(config.payments.paypal.clientId, config.payments.paypal.clientSecret)
    : new paypal.core.SandboxEnvironment(config.payments.paypal.clientId, config.payments.paypal.clientSecret);
const paypalClient = new paypal.core.PayPalHttpClient(paypalEnvironment);

// --- PAYMENT FUNCTIONS ---

async function createStripePaymentIntent(payload: PaymentPayload): Promise<string | null> {
  const { amount, currency, customerId, paymentMethodId, metadata } = payload;
  try {
    const params: StripeTypes.PaymentIntentCreateParams = {
      amount: Math.round(amount * 100),
      currency,
      customer: customerId,
      payment_method: paymentMethodId,
      metadata: { ...metadata, platform: "Rehma Foundation" },
      confirmation_method: "manual",
      confirm: true,
      return_url: `${config.app.url}/payment/success`,
    };
    const paymentIntent = await stripeClient.paymentIntents.create(params);
    return paymentIntent.client_secret;
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "An unknown error occurred";
    console.error("Stripe Payment Intent Error:", message);
    throw new Error("Failed to create Stripe payment intent.");
  }
}

async function createStripeSubscription(payload: SubscriptionPayload): Promise<StripeTypes.Subscription> {
  const { customerId, priceId, paymentMethodId, metadata } = payload;
  try {
    await stripeClient.paymentMethods.attach(paymentMethodId, { customer: customerId });
    await stripeClient.customers.update(customerId, {
      invoice_settings: { default_payment_method: paymentMethodId },
    });
    const subscription = await stripeClient.subscriptions.create({
      customer: customerId,
      items: [{ price: priceId }],
      expand: ["latest_invoice.payment_intent"],
      metadata,
    });
    return subscription;
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "An unknown error occurred";
    console.error("Stripe Subscription Error:", message);
    throw new Error("Failed to create Stripe subscription.");
  }
}

export async function handleStripeWebhook(body: Buffer, signature: string): Promise<{ received: boolean; data?: StripeTypes.Event }> {
  try {
    const event = stripeClient.webhooks.constructEvent(body, signature, config.payments.stripe.webhookSecret);
    // Handle specific event types
    switch (event.type) {
      case "payment_intent.succeeded": break;
      case "customer.subscription.created": break;
    }
    return { received: true, data: event };
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "An unknown error occurred";
    console.error("Stripe Webhook Error:", message);
    throw new Error(`Webhook Error: ${message}`);
  }
}

async function createPayProPayment(payload: PaymentPayload): Promise<string | null> {
  try {
    const response = await paypro.createTransaction({
      amount: payload.amount,
      currency: payload.currency,
      customer: payload.metadata?.email,
      metadata: payload.metadata,
    });
    return response.paymentUrl;
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "An unknown error occurred";
    console.error("PayPro Payment Error:", message);
    throw new Error("Failed to create PayPro payment.");
  }
}

async function createPayPalOrder(payload: PaymentPayload): Promise<{ id: string; approveUrl?: string }> {
  const request = new paypal.orders.OrdersCreateRequest();
  request.prefer("return=representation");
  request.requestBody({
    intent: "CAPTURE",
    purchase_units: [
      {
        amount: {
          currency_code: payload.currency.toUpperCase(),
          value: payload.amount.toFixed(2),
        },
        description: (payload.metadata?.description as string) || "Rehma Foundation Donation",
        custom_id: payload.metadata?.orderId as string,
      },
    ],
    application_context: {
      return_url: `${config.app.url}/payment/success?gateway=paypal`,
      cancel_url: `${config.app.url}/payment/cancel`,
      brand_name: "Rehma Foundation",
      user_action: "PAY_NOW",
    },
  });

  try {
    const order = await paypalClient.execute(request);
    const approveLink = order.result.links.find((link: { rel: string }) => link.rel === "approve");
    return {
      id: order.result.id,
      approveUrl: approveLink?.href,
    };
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "An unknown error occurred";
    console.error("PayPal Order Creation Error:", message);
    const paypalError = error as PayPalError;
    if (paypalError.statusCode) {
      const errorDetails = JSON.stringify(paypalError.result, null, 2);
      console.error("PayPal Error Details:", errorDetails);
    }
    throw new Error("Failed to create PayPal order.");
  }
}

// --- PAYMENT GATEWAY ADAPTER ---

export const paymentGateway = {
  stripe: {
    createIntent: createStripePaymentIntent,
    createSubscription: createStripeSubscription,
    handleWebhook: handleStripeWebhook,
    client: stripeClient,
  },
  paypro: {
    createPayment: createPayProPayment,
  },
  paypal: {
    createOrder: createPayPalOrder,
    client: paypalClient,
  },
};

export const processStripePayment = async (
  paymentMethodId: string,
  amount: number,
  currency: string,
  customerId: string,
  metadata: Record<string, string>,
) => {
  const payload: PaymentPayload = {
    amount,
    currency,
    customerId,
    paymentMethodId,
    metadata,
  };
  const client_secret = await createStripePaymentIntent(payload);
  return { success: true, client_secret };
};

export const processPayProPayment = async (paymentDetails: PayProPaymentDetails) => {
  try {
    const orderId = payproService.generateOrderId();
    const session = await payproService.createPayment({
        amount: paymentDetails.amount,
        currency: paymentDetails.currency,
        orderId: orderId,
        description: (paymentDetails.metadata?.description as string) || "Rehma Donation",
        customerName: (paymentDetails.metadata?.customerName as string) || "Anonymous",
        customerEmail: paymentDetails.email,
        returnUrl: `${config.app.url}/payment/success`,
        cancelUrl: `${config.app.url}/payment/cancel`,
    });
    return { success: true, session };
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "An unknown error occurred";
    console.error("PayPro Payment Error:", message);
    throw new Error("Failed to create PayPro payment.");
  }
};
