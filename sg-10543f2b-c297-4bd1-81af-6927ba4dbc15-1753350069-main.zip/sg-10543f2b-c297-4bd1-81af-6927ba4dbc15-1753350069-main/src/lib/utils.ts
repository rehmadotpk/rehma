import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { supabase } from "@/integrations/supabase/client";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export async function updateChildRaisedAmount(childId: string): Promise<{ error: Error | null }> {
  try {
    const { data: donations, error: donationsError } = await supabase
      .from("donations")
      .select("amount")
      .eq("child_id", childId)
      .eq("payment_status", "completed");

    if (donationsError) {
      console.error("Error fetching child donations for amount update:", donationsError);
      return { error: donationsError as any };
    }

    const totalRaised = donations?.reduce((sum, donation) => sum + Number(donation.amount), 0) || 0;

    const { error: updateError } = await supabase
      .from("children")
      .update({ raised_amount: totalRaised, updated_at: new Date().toISOString() })
      .eq("id", childId);

    if (updateError) {
      console.error("Error updating child's raised amount:", updateError);
      return { error: updateError as any };
    }

    return { error: null };
  } catch (error) {
    console.error("Unexpected error in updateChildRaisedAmount:", error);
    return { error: error instanceof Error ? error : new Error("An unexpected error occurred") };
  }
}