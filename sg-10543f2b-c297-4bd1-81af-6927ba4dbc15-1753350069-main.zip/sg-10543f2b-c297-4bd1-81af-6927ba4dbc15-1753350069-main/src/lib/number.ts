
    export function formatNumber(value: number | null | undefined): string {
      if (typeof value !== "number" || isNaN(value)) return "0";
      return new Intl.NumberFormat("en-US").format(value);
    }
    
    export function formatCurrency(value: number | null | undefined, currency: "PKR" | "USD" | string = "USD"): string {
      const amount = typeof value === "number" && !isNaN(value) ? value : 0;
      if (currency.toUpperCase() === "PKR") {
        return `PKR ${formatNumber(amount)}`;
      }
      if (currency.toUpperCase() === "USD") {
        return `USD ${new Intl.NumberFormat("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(amount)}`;
      }
      return `${currency.toUpperCase()} ${formatNumber(amount)}`;
    }
  