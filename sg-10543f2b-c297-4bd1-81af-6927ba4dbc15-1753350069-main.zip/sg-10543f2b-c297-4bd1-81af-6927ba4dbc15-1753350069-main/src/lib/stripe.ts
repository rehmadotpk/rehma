import Stripe from "stripe";

const stripeSecretKey = process.env.STRIPE_SECRET_KEY;

// Server-side Stripe instance - only create if secret key exists and we're on server
export const stripe = (stripeSecretKey && typeof window === "undefined") ? new Stripe(stripeSecretKey, {
  apiVersion: "2025-02-24.acacia",
}) : null;

// Client-side Stripe instance with build-safe error handling
export const getStripe = () => {
  if (typeof window === "undefined") return null;
  
  const stripePublishableKey = process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY;
  
  // Return null instead of throwing error to prevent build failures
  if (!stripePublishableKey) {
    console.warn("NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY is not set in environment variables. Payment functionality will be disabled.");
    return null;
  }
  
  const stripePromise = import("@stripe/stripe-js").then(({ loadStripe }) =>
    loadStripe(stripePublishableKey)
  );
  
  return stripePromise;
};

// Helper function to check if Stripe is properly configured
export const isStripeConfigured = () => {
  const hasSecretKey = !!(process.env.STRIPE_SECRET_KEY);
  const hasPublishableKey = !!(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY);
  
  return {
    server: hasSecretKey,
    client: hasPublishableKey,
    fully: hasSecretKey && hasPublishableKey
  };
};

// Safe stripe operations
export const safeStripeOperation = async <T>(
  operation: () => Promise<T>,
  fallback?: T
): Promise<T | null> => {
  try {
    if (!stripe) {
      console.warn("Stripe is not configured. Operation skipped.");
      return fallback || null;
    }
    return await operation();
  } catch (error) {
    console.error("Stripe operation failed:", error);
    return fallback || null;
  }
};
