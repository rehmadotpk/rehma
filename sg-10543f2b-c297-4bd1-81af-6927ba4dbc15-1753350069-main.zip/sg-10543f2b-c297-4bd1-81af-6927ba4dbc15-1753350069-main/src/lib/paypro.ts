import config from "./config";

interface PayProOptions {
  merchantId: string;
  secretKey: string;
}

interface PayProTransactionPayload {
  amount: number;
  currency: string;
  customer?: string;
  metadata?: Record<string, unknown>;
}

interface PayProTransactionResponse {
  success: boolean;
  paymentUrl: string;
  transactionId: string;
}

export class PayPro {
  private merchantId: string;
  private secretKey: string;

  constructor(options: PayProOptions) {
    if (!options.merchantId || !options.secretKey) {
      throw new Error("PayPro Merchant ID and Secret Key are required.");
    }
    this.merchantId = options.merchantId;
    this.secretKey = options.secretKey;
  }

  async createTransaction(payload: PayProTransactionPayload): Promise<PayProTransactionResponse> {
    // This is a mock implementation.
    // In a real implementation, you would make an API call to PayPro here.
    console.log("Creating PayPro transaction with payload:", payload);
    
    const transactionId = `pp_mock_${Date.now()}`;
    const paymentUrl = `${config.app.url}/payment/success?gateway=paypro&transaction_id=${transactionId}`;
    
    return Promise.resolve({
      success: true,
      paymentUrl,
      transactionId,
    });
  }
}
