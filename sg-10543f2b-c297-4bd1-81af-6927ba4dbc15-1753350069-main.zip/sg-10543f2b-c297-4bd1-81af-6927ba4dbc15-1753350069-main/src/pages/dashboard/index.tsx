import Layout from "@/components/Layout";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, Shield, BarChart, Users, Settings } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function DashboardPage() {
  const { user, userProfile, loading, isAdmin, initialized } = useAuth();

  // Show loading while auth is initializing
  if (loading || !initialized) {
    return (
      <Layout>
        <div className="flex h-screen w-full items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }

  // Check if user is not logged in
  if (!user) {
    return (
      <Layout>
        <div className="flex h-screen w-full items-center justify-center p-4">
          <Card className="w-full max-w-md text-center">
            <CardHeader>
              <CardTitle>Access Denied</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">You must be logged in to access this page.</p>
              <Link href="/auth/login" passHref>
                <Button>
                  <Shield className="mr-2 h-4 w-4" /> Login
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </Layout>
    );
  }

  // Check if user is not admin - redirect regular users to homepage
  if (!isAdmin) {
    return (
      <Layout>
        <div className="flex h-screen w-full items-center justify-center p-4">
          <Card className="w-full max-w-md text-center">
            <CardHeader>
              <CardTitle>Welcome to Rehma!</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                Welcome, {userProfile?.full_name || 'User'}! You're successfully logged in as a {userProfile?.role || 'user'}.
              </p>
              <p className="mb-6 text-sm text-gray-600">
                The dashboard is for administrators only. You can explore children who need help and make donations from the main site.
              </p>
              <div className="space-y-3">
                <Link href="/" passHref>
                  <Button className="w-full">
                    Go to Homepage
                  </Button>
                </Link>
                <Link href="/children" passHref>
                  <Button variant="outline" className="w-full">
                    View Children
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Welcome, {userProfile.full_name || "Admin"}!</h1>
          <p className="text-muted-foreground">Here's your dashboard overview.</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                User Management
              </CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                View and manage all system users.
              </p>
              <Link href="/admin" passHref>
                <Button variant="outline">Go to Admin Panel</Button>
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Analytics
              </CardTitle>
              <BarChart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
               <p className="text-sm text-muted-foreground mb-4">
                View system analytics and reports.
              </p>
              <Button variant="outline" disabled>Coming Soon</Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                System Settings
              </CardTitle>
              <Settings className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
               <p className="text-sm text-muted-foreground mb-4">
                Configure application settings.
              </p>
              <Link href="/settings" passHref>
                <Button variant="outline">Go to Settings</Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        <div className="mt-8">
            <Alert>
                <Shield className="h-4 w-4" />
                <AlertDescription>
                    This is the main dashboard for administrators. More widgets and features will be added soon.
                </AlertDescription>
            </Alert>
        </div>
      </div>
    </Layout>
  );
}
