import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Input } from "@/components/ui/input";
import { Search, Heart, CreditCard, Users, Shield, Phone, Mail, MessageCircle, Book, Video, FileText } from "lucide-react";
import Layout from "@/components/Layout";

const faqData = [
  {
    id: "1",
    question: "How do I make a donation?",
    answer: "Making a donation is simple! Browse our children's profiles, select a child you'd like to support, click the 'Donate Now' button, choose your donation amount, and complete the secure payment process. You'll receive a confirmation email with your donation receipt."
  },
  {
    id: "2",
    question: "Is my donation secure?",
    answer: "Yes, absolutely! We use industry-standard SSL encryption and work with trusted payment processors like PayPro to ensure your financial information is completely secure. We never store your complete payment details on our servers."
  },
  {
    id: "3",
    question: "Can I track how my donation is used?",
    answer: "Yes! We provide regular updates on how donations are being used. You'll receive progress reports, photos, and updates about the child's treatment and recovery. We believe in complete transparency with our donors."
  },
  {
    id: "4",
    question: "Are donations tax-deductible?",
    answer: "Yes, Rehma Foundation is a registered charitable organization. All donations are tax-deductible, and we provide official tax receipts for your records. Please consult with your tax advisor for specific guidance."
  },
  {
    id: "5",
    question: "Can I donate anonymously?",
    answer: "Absolutely! During the donation process, you can choose to remain anonymous. Your personal information will be kept private, and only your donation amount will be recorded for the child's fundraising progress."
  },
  {
    id: "6",
    question: "What payment methods do you accept?",
    answer: "We accept major credit cards, debit cards, and bank transfers through our secure PayPro payment gateway. We're working to add more payment options to make donating as convenient as possible."
  },
  {
    id: "7",
    question: "How do you verify the children's cases?",
    answer: "Every case goes through a rigorous verification process. We work with medical professionals, social workers, and partner NGOs to verify medical records, family circumstances, and treatment needs before listing any child on our platform."
  },
  {
    id: "8",
    question: "Can I donate to multiple children?",
    answer: "Yes! You can support as many children as you'd like. Each donation is processed separately, and you'll receive individual receipts and updates for each child you support."
  },
  {
    id: "9",
    question: "What happens if a fundraising goal is exceeded?",
    answer: "If a child's fundraising goal is exceeded, the additional funds are used to support their ongoing care, rehabilitation, or are allocated to other children in similar need with the donor's consent."
  },
  {
    id: "10",
    question: "How can I get involved beyond donating?",
    answer: "There are many ways to help! You can volunteer, spread awareness on social media, organize fundraising events, purchase artwork from our shop, or connect us with healthcare providers and NGOs in your area."
  }
];

const supportCategories = [
  {
    icon: Heart,
    title: "Donations & Payments",
    description: "Questions about making donations, payment methods, and receipts",
    articles: 12
  },
  {
    icon: Users,
    title: "Account & Profile",
    description: "Managing your account, profile settings, and preferences",
    articles: 8
  },
  {
    icon: Shield,
    title: "Privacy & Security",
    description: "Information about data protection, privacy, and security measures",
    articles: 6
  },
  {
    icon: CreditCard,
    title: "Billing & Receipts",
    description: "Tax receipts, billing questions, and financial documentation",
    articles: 5
  }
];

export default function HelpPage() {
  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-gray-50">
        {/* Hero Section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-[#101c2c] to-[#1a2b3d]">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-6 bg-[#d4af37]/20 text-[#d4af37] hover:bg-[#d4af37]/30 border-[#d4af37]/30">
              💡 We're Here to Help
            </Badge>
            
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Help & Support Center
            </h1>
            
            <p className="text-xl text-gray-300 mb-8">
              Find answers to your questions and get the support you need to make a difference in children's lives.
            </p>

            {/* Search Bar */}
            <div className="max-w-2xl mx-auto">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  placeholder="Search for help articles, FAQs, or topics..."
                  className="pl-12 pr-4 py-3 text-lg bg-white border-0 focus:ring-2 focus:ring-[#d4af37]"
                />
                <Button className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-[#d4af37] hover:bg-[#b8941f] text-white">
                  Search
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Quick Help Categories */}
        <section className="py-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold text-[#101c2c] text-center mb-12">
              Browse Help Topics
            </h2>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {supportCategories.map((category, index) => (
                <Card key={index} className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg cursor-pointer">
                  <CardHeader className="text-center pb-4">
                    <div className="w-16 h-16 bg-[#d4af37]/20 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#d4af37]/30 transition-colors">
                      <category.icon className="w-8 h-8 text-[#d4af37]" />
                    </div>
                    <CardTitle className="text-lg text-[#101c2c] group-hover:text-[#d4af37] transition-colors">
                      {category.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-center pt-0">
                    <p className="text-gray-600 mb-4">
                      {category.description}
                    </p>
                    <Badge variant="outline" className="border-[#d4af37]/30 text-[#d4af37]">
                      {category.articles} articles
                    </Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-[#101c2c] mb-4">
                Frequently Asked Questions
              </h2>
              <p className="text-lg text-gray-600">
                Quick answers to the most common questions about Rehma Foundation
              </p>
            </div>

            <Accordion type="single" collapsible className="space-y-4">
              {faqData.map((faq) => (
                <AccordionItem key={faq.id} value={faq.id} className="border border-gray-200 rounded-lg px-6">
                  <AccordionTrigger className="text-left hover:text-[#d4af37] transition-colors">
                    <span className="font-semibold text-[#101c2c]">{faq.question}</span>
                  </AccordionTrigger>
                  <AccordionContent className="text-gray-600 leading-relaxed pt-2 pb-4">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </section>

        {/* Contact Support Section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-[#101c2c]/5 to-[#d4af37]/5">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-[#101c2c] mb-4">
                Still Need Help?
              </h2>
              <p className="text-lg text-gray-600">
                Our support team is here to assist you with any questions or concerns
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <Card className="text-center border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader>
                  <div className="w-16 h-16 bg-[#d4af37]/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <MessageCircle className="w-8 h-8 text-[#d4af37]" />
                  </div>
                  <CardTitle className="text-xl text-[#101c2c]">Live Chat</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-6">
                    Get instant help from our support team through live chat
                  </p>
                  <Button 
                    className="bg-[#d4af37] hover:bg-[#b8941f] text-white"
                    onClick={() => window.open('mailto:support@rehma.ai?subject=Live Chat Request&body=Hello, I would like to start a live chat session. Please contact me at your earliest convenience.', '_blank')}
                  >
                    Start Chat
                  </Button>
                </CardContent>
              </Card>

              <Card className="text-center border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader>
                  <div className="w-16 h-16 bg-[#d4af37]/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Mail className="w-8 h-8 text-[#d4af37]" />
                  </div>
                  <CardTitle className="text-xl text-[#101c2c]">Email Support</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-6">
                    Send us an email and we'll respond within 24 hours
                  </p>
                  <Button 
                    variant="outline" 
                    className="border-[#d4af37] text-[#d4af37] hover:bg-[#d4af37] hover:text-white"
                    onClick={() => window.open('mailto:support@rehma.ai?subject=Support Request&body=Hello, I need assistance with...', '_blank')}
                  >
                    Send Email
                  </Button>
                </CardContent>
              </Card>

              <Card className="text-center border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader>
                  <div className="w-16 h-16 bg-[#d4af37]/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Phone className="w-8 h-8 text-[#d4af37]" />
                  </div>
                  <CardTitle className="text-xl text-[#101c2c]">Phone Support</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-6">
                    Call us directly for urgent matters and immediate assistance
                  </p>
                  <Button 
                    variant="outline" 
                    className="border-[#d4af37] text-[#d4af37] hover:bg-[#d4af37] hover:text-white"
                    onClick={() => window.open('tel:+923001234567', '_self')}
                  >
                    Call Now
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Resources Section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-[#101c2c] mb-4">
                Additional Resources
              </h2>
              <p className="text-lg text-gray-600">
                Explore more ways to learn about our mission and get involved
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader>
                  <Book className="w-8 h-8 text-[#d4af37] mb-3" />
                  <CardTitle className="text-lg text-[#101c2c]">User Guide</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">
                    Comprehensive guide on how to use our platform effectively
                  </p>
                  <Button variant="outline" size="sm" className="border-[#d4af37] text-[#d4af37] hover:bg-[#d4af37] hover:text-white">
                    Read Guide
                  </Button>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader>
                  <Video className="w-8 h-8 text-[#d4af37] mb-3" />
                  <CardTitle className="text-lg text-[#101c2c]">Video Tutorials</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">
                    Step-by-step video tutorials for common tasks and features
                  </p>
                  <Button variant="outline" size="sm" className="border-[#d4af37] text-[#d4af37] hover:bg-[#d4af37] hover:text-white">
                    Watch Videos
                  </Button>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader>
                  <FileText className="w-8 h-8 text-[#d4af37] mb-3" />
                  <CardTitle className="text-lg text-[#101c2c]">Documentation</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">
                    Detailed documentation about our policies and procedures
                  </p>
                  <Button variant="outline" size="sm" className="border-[#d4af37] text-[#d4af37] hover:bg-[#d4af37] hover:text-white">
                    View Docs
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </div>
    </Layout>
  );
}
