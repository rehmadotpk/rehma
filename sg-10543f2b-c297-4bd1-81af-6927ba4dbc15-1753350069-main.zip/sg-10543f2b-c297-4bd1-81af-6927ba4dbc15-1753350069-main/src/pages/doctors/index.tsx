import { useState, useEffect } from "react";
import Image from "next/image";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Phone, MapPin, Briefcase, Award, UserCheck, Search } from "lucide-react";
import { doctorService, Doctor } from "@/services/doctorService";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import DoctorContactModal from "@/components/DoctorContactModal";

export default function DoctorsPage() {
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [specialization, setSpecialization] = useState("all");
  const [location, setLocation] = useState("all");
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [contactModalOpen, setContactModalOpen] = useState(false);

  useEffect(() => {
    const fetchDoctors = async () => {
      setLoading(true);
      try {
        const filters = {
          search: searchTerm || undefined,
          specialization: specialization !== "all" ? specialization : undefined,
          location: location !== "all" ? location : undefined,
        };
        const fetchedDoctors = await doctorService.getVerifiedDoctors(filters);
        setDoctors(fetchedDoctors);
      } catch (error) {
        console.error("Failed to fetch doctors:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchDoctors();
  }, [searchTerm, specialization, location]);

  const handleContactDoctor = (doctor: Doctor) => {
    setSelectedDoctor(doctor);
    setContactModalOpen(true);
  };

  const specializations = ["all", "Pediatric Neurology", "Pediatric Cardiology", "Child Psychology", "Pediatric Ophthalmology", "Developmental Pediatrics", "Speech and Language Therapy"];
  const locations = ["all", "Karachi", "Rawalpindi", "Lahore", "Multan", "Islamabad", "Faisalabad"];

  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-[#101c2c]/5 via-white to-yellow-50">
        {/* Hero Section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-[#101c2c] to-green-600">
          <div className="max-w-7xl mx-auto text-center">
            <Badge className="mb-6 bg-white/20 text-white hover:bg-white/30 border-white/30">
              🩺 Verified Medical Professionals
            </Badge>
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Connect with Trusted Doctors
            </h1>
            <p className="text-xl text-green-100 mb-8 max-w-3xl mx-auto">
              Find experienced and verified doctors specializing in pediatric care. Our network is dedicated to providing the best medical support for children with special needs.
            </p>
          </div>
        </section>

        {/* Search and Filter Section */}
        <section className="py-12 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <Card className="border-0 shadow-lg">
              <CardContent className="p-6 flex flex-col md:flex-row gap-4 items-center">
                <div className="relative flex-grow w-full">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <Input
                    placeholder="Search by name, specialization..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={specialization} onValueChange={setSpecialization}>
                  <SelectTrigger className="w-full md:w-56">
                    <SelectValue placeholder="Filter by Specialization" />
                  </SelectTrigger>
                  <SelectContent>
                    {specializations.map(spec => <SelectItem key={spec} value={spec}>{spec === 'all' ? 'All Specializations' : spec}</SelectItem>)}
                  </SelectContent>
                </Select>
                <Select value={location} onValueChange={setLocation}>
                  <SelectTrigger className="w-full md:w-56">
                    <SelectValue placeholder="Filter by Location" />
                  </SelectTrigger>
                  <SelectContent>
                    {locations.map(loc => <SelectItem key={loc} value={loc}>{loc === 'all' ? 'All Locations' : loc}</SelectItem>)}
                  </SelectContent>
                </Select>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Doctors Grid */}
        <section className="pb-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-2xl font-bold text-gray-900 mb-8">
              {doctors.length} Doctors Found
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {loading ? (
                [...Array(6)].map((_, i) => (
                  <Card key={i} className="p-6 shadow-lg animate-pulse">
                    <div className="h-24 w-24 rounded-full bg-gray-200 mx-auto mb-4"></div>
                    <div className="h-6 bg-gray-200 rounded mb-2 w-3/4 mx-auto"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/2 mx-auto"></div>
                  </Card>
                ))
              ) : (
                doctors.map((doctor) => (
                  <Card key={doctor.id} className="hover:shadow-xl transition-all duration-300 border-0 shadow-lg overflow-hidden flex flex-col">
                    <CardHeader className="items-center text-center bg-gray-50 p-6">
                      <Image
                        src={doctor.avatar_url || `https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=150&h=150&fit=crop&crop=face`}
                        alt={doctor.name}
                        width={100}
                        height={100}
                        className="rounded-full border-4 border-white shadow-md"
                      />
                      <CardTitle className="text-xl mt-4 mb-1">{doctor.name}</CardTitle>
                      <p className="text-green-600 font-medium">{doctor.specialization}</p>
                    </CardHeader>
                    <CardContent className="p-6 space-y-4 flex-grow">
                      <div className="flex items-start space-x-3 text-sm">
                        <Award className="w-5 h-5 text-gray-400 mt-0.5 shrink-0" />
                        <span>{doctor.qualification}</span>
                      </div>
                      <div className="flex items-start space-x-3 text-sm">
                        <Briefcase className="w-5 h-5 text-gray-400 mt-0.5 shrink-0" />
                        <span>{doctor.experience_years} years of experience</span>
                      </div>
                      <div className="flex items-start space-x-3 text-sm">
                        <MapPin className="w-5 h-5 text-gray-400 mt-0.5 shrink-0" />
                        <span>{doctor.location}</span>
                      </div>
                      <div className="flex items-center justify-between pt-4">
                        <Badge variant={doctor.is_available ? "default" : "secondary"} className={doctor.is_available ? "bg-green-100 text-green-800" : ""}>
                          {doctor.is_available ? "Available" : "Unavailable"}
                        </Badge>
                        {doctor.verified && (
                          <Badge className="bg-blue-100 text-blue-800">
                            <UserCheck className="w-3 h-3 mr-1" />
                            Verified
                          </Badge>
                        )}
                      </div>
                    </CardContent>
                    <div className="p-6 border-t">
                      <Button 
                        className="w-full bg-gradient-to-r from-[#101c2c] to-green-600 hover:from-[#1e293b] hover:to-green-700"
                        onClick={() => handleContactDoctor(doctor)}
                      >
                        <Phone className="w-4 h-4 mr-2" />
                        Contact Doctor
                      </Button>
                    </div>
                  </Card>
                ))
              )}
            </div>
          </div>
        </section>

        {selectedDoctor && (
          <DoctorContactModal
            doctor={selectedDoctor}
            isOpen={contactModalOpen}
            onClose={() => {
              setContactModalOpen(false);
              setSelectedDoctor(null);
            }}
          />
        )}
      </div>
    </Layout>
  );
}
