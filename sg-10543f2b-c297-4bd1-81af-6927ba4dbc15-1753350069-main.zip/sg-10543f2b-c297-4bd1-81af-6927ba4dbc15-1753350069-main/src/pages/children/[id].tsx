import { useState, useEffect, useCallback } from "react";
import { useRouter } from "next/router";
import { GetServerSideProps, NextPage } from "next";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MapPin, Heart, Share2, Bell, Award, TrendingUp, MessageSquare, Info } from "lucide-react";
import { useCurrency } from "@/contexts/CurrencyContext";
import { useToast } from "@/hooks/use-toast";
import { donationService, Donation } from "@/services/donationService";
import { childrenService, Child } from "@/services/childrenService";
import Layout from "@/components/Layout";
import dynamic from "next/dynamic";
const DonationModal = dynamic(() => import("@/components/DonationModal"), { ssr: false });
import { formatDistanceToNow } from "date-fns";
import { formatDate } from "@/lib/dateUtils";
import ClientOnlyDate from "@/components/ClientOnlyDate";

interface ChildProfilePageProps {
  child: Child | null;
}

interface DonationStats {
  totalDonations: number;
  totalAmount: number;
  formattedTargetAmount: string;
  formattedRaisedAmount: string;
  formattedRemainingAmount: string;
  recentDonations: Donation[];
}

const ChildProfilePage = ({ child: initialChild }: ChildProfilePageProps) => {
  const router = useRouter();
  const { formatPrice } = useCurrency();
  const [child, setChild] = useState<Child | null>(initialChild);
  const [isFollowing, setIsFollowing] = useState(false);
  const [activeTab, setActiveTab] = useState("story");
  const [stats, setStats] = useState<Partial<DonationStats>>({});
  const [donationModalOpen, setDonationModalOpen] = useState(false);
  const { toast } = useToast();
  const [updatedAtRelative, setUpdatedAtRelative] = useState("A while ago");

  useEffect(() => {
    if (child?.updated_at) {
      setUpdatedAtRelative(
        formatDistanceToNow(new Date(child.updated_at), { addSuffix: true })
      );
    }
  }, [child?.updated_at]);

  const fetchDonationStats = useCallback(async () => {
    if (!child) return;
    try {
      const donationData = await donationService.getChildDonations(child.id);
      const totalDonations = donationData.total || 0;
      const totalAmount = donationData.donations.reduce((sum, d) => sum + d.amount, 0);
      const recentDonations = donationData.donations.slice(0, 5);

      const formattedTargetAmount = formatPrice(child.target_amount);
      const formattedRaisedAmount = formatPrice(child.raised_amount || 0);
      const formattedRemainingAmount = formatPrice(Math.max(0, child.target_amount - (child.raised_amount || 0)));

      setStats({
        totalDonations,
        totalAmount,
        formattedTargetAmount,
        formattedRaisedAmount,
        formattedRemainingAmount,
        recentDonations
      });
    } catch (error) {
      console.error("Failed to fetch donation stats:", error);
      toast({
        title: "Error",
        description: "Could not load donation statistics.",
        variant: "destructive",
      });
    }
  }, [child, formatPrice, toast]);

  useEffect(() => {
    if (child) {
      fetchDonationStats();
    }
  }, [child, fetchDonationStats]);

  const handleSuccessfulDonation = async () => {
    toast({ title: "Donation successful!", description: "Thank you for your generosity." });
    if (child) {
      try {
        const updatedChild = await childrenService.getChildById(child.id);
        setChild(updatedChild);
      } catch (error) {
        console.error("Failed to refetch child data after donation:", error);
        router.replace(router.asPath);
      }
    }
  };

  if (!child) {
    return <Layout><div>Child not found</div></Layout>;
  }

  const progressPercentage = child.target_amount > 0 ? (child.raised_amount / child.target_amount) * 100 : 0;
  
  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-[#d4af37]/10">
        <section className="py-12 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <div className="grid lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-8">
                <Card className="border-0 shadow-lg overflow-hidden">
                  <div className="relative h-64 bg-gradient-to-br from-[#101c2c]/10 to-[#d4af37]/20">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-32 h-32 bg-white rounded-full flex items-center justify-center shadow-xl border-4 border-[#d4af37]/30">
                        <span className="text-4xl font-bold text-[#101c2c]">{child.name.charAt(0)}</span>
                      </div>
                    </div>
                    <Badge className="absolute top-4 right-4 bg-[#d4af37] hover:bg-[#b8941f] text-white">
                      ✓ Verified
                    </Badge>
                    <div className="absolute bottom-4 left-4 right-4">
                      <div className="bg-white/90 backdrop-blur-sm rounded-lg p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h1 className="text-2xl font-bold text-gray-900">{child.name}</h1>
                            <p className="text-gray-600">Age {child.age} • {child.condition}</p>
                            <div className="flex items-center text-sm text-gray-500 mt-1">
                              <MapPin className="w-4 h-4 mr-1" />
                              {child.location}
                            </div>
                          </div>
                          <div className="flex space-x-2">
                            <Button
                              size="sm"
                              variant={isFollowing ? "default" : "outline"}
                              onClick={() => setIsFollowing(!isFollowing)}
                              className={isFollowing ? "bg-[#d4af37] hover:bg-[#b8941f] text-white" : "bg-transparent hover:bg-[#d4af37]/10 border-[#d4af37] text-[#101c2c]"}
                            >
                              <Heart className={`w-4 h-4 mr-1 ${isFollowing ? "fill-current text-white" : "text-[#d4af37]"}`} />
                              {isFollowing ? "Following" : "Follow"}
                            </Button>
                            <Button size="sm" variant="outline" className="bg-transparent hover:bg-[#101c2c]/10 border-[#101c2c] text-[#101c2c]">
                              <Share2 className="w-4 h-4 mr-1" />
                              Share
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>

                <div className="grid md:grid-cols-2 gap-6">
                  <Card className="border-0 shadow-md">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg flex items-center">
                        <TrendingUp className="w-5 h-5 mr-2 text-[#d4af37]" />
                        Funding Progress
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>{stats.formattedRaisedAmount}</span>
                          <span>{stats.formattedTargetAmount}</span>
                        </div>
                        <Progress value={progressPercentage} className="h-3" />
                        <p className="text-xs text-gray-500">{Math.round(progressPercentage)}% funded</p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-0 shadow-md">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg flex items-center">
                        <Award className="w-5 h-5 mr-2 text-[#101c2c]" />
                        Donations
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-[#101c2c]">{stats.totalDonations || 0}</div>
                        <div className="text-sm text-gray-600">donations received</div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <Card className="border-0 shadow-lg">
                  <Tabs value={activeTab} onValueChange={setActiveTab}>
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="story">Story</TabsTrigger>
                      <TabsTrigger value="updates">Updates</TabsTrigger>
                      <TabsTrigger value="donors">Donors</TabsTrigger>
                    </TabsList>

                    <TabsContent value="story" className="p-6">
                      <div className="space-y-6">
                        <div>
                          <h3 className="text-xl font-semibold mb-4">{`${child.name}'s`} Story</h3>
                          <p className="text-gray-700 leading-relaxed mb-4">{child.story}</p>
                        </div>
                        
                        <div className="bg-[#d4af37]/10 rounded-lg p-4 border border-[#d4af37]/20">
                          <h4 className="font-medium text-[#101c2c] mb-2">How Your Donation Helps</h4>
                          <ul className="space-y-2 text-sm text-[#101c2c]/80">
                            <li>• {formatPrice(500)} - One art therapy session</li>
                            <li>• {formatPrice(1000)} - Professional art supplies for one month</li>
                            <li>• {formatPrice(2500)} - Transportation support for therapy visits</li>
                            <li>• {formatPrice(5000)} - Specialized assessment and treatment plan</li>
                          </ul>
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="updates" className="p-6">
                      <div className="space-y-6">
                        <h3 className="text-xl font-semibold">Recent Updates</h3>
                        <p className="text-gray-600">No updates yet. Check back soon!</p>
                      </div>
                    </TabsContent>

                    <TabsContent value="donors" className="p-6">
                      <div className="space-y-4">
                        <h3 className="text-xl font-semibold">Recent Donors</h3>
                        {stats.recentDonations && stats.recentDonations.length > 0 ? (
                          stats.recentDonations.map((donation) => (
                            <div key={donation.id} className="flex items-center justify-between">
                              <p>{donation.anonymous ? "Anonymous Donor" : donation.donor_name}</p>
                              <p className="font-semibold">{formatPrice(donation.amount)}</p>
                            </div>
                          ))
                        ) : (
                          <p className="text-gray-600">Be the first to donate!</p>
                        )}
                      </div>
                    </TabsContent>
                  </Tabs>
                </Card>

                <Card className="border-0 shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <MessageSquare className="w-5 h-5 mr-2" />
                      Recent Updates
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-start space-x-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                          <Info className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <p className="font-medium text-sm">Treatment Started</p>
                          <p className="text-xs text-gray-500">
                            <ClientOnlyDate date={child.updated_at} format={(d) => formatDistanceToNow(d, { addSuffix: true })} />
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-6">
                <Card className="border-0 shadow-md">
                  <CardHeader>
                    <CardTitle>Make a Donation</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Button className="w-full bg-gradient-to-r from-[#101c2c] to-[#d4af37] hover:from-[#1e293b] hover:to-[#b8941f] text-white" onClick={() => setDonationModalOpen(true)}>
                      <Heart className="w-4 h-4 mr-2" />
                      Donate Now
                    </Button>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-md">
                  <CardHeader>
                    <CardTitle className="text-lg">Quick Stats</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Last Update</span>
                      <span className="font-medium"><ClientOnlyDate date={child.updated_at} format={(d) => formatDate(d)} /></span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Verification</span>
                      <Badge className="bg-[#d4af37] hover:bg-[#b8941f] text-white">Verified</Badge>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-md">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center">
                      <Bell className="w-5 h-5 mr-2" />
                      Stay Updated
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">
                      Get notified about {`${child.name}'s`} progress and milestones.
                    </p>
                    <Button className="w-full bg-[#101c2c] hover:bg-[#1e293b] text-white" variant="outline">
                      Enable Notifications
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>
        {donationModalOpen && (
          <DonationModal
            child={child}
            isOpen={donationModalOpen}
            onClose={() => setDonationModalOpen(false)}
            onSuccess={handleSuccessfulDonation}
          />
        )}
      </div>
    </Layout>
  );
};

export const getServerSideProps: GetServerSideProps = async (context) => {
  const { id } = context.params as { id: string };
  try {
    const child = await childrenService.getChildById(id);
    return { props: { child } };
  } catch (error) {
    console.error("Failed to fetch child", error);
    return { props: { child: null } };
  }
};

export default ChildProfilePage;
