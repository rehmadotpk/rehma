import { useState, useEffect, useCallback } from "react";
import { useRouter } from "next/router";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Layout from "@/components/Layout";
import SearchAndFilter from "@/components/SearchAndFilter";
import EnhancedChildCard from "@/components/EnhancedChildCard";
import { childrenService, Child } from "@/services/childrenService";
import { useToast } from "@/hooks/use-toast";

export default function ChildrenListPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [children, setChildren] = useState<Child[]>([]);
  const [loading, setLoading] = useState(true);
  const [totalChildren, setTotalChildren] = useState(0);
  const [page, setPage] = useState(1);
  const limit = 12;

  const [filters, setFilters] = useState({
    status: "active",
    urgency: "all",
    searchTerm: "",
    sortBy: "created_at_desc",
  });

  const fetchChildren = useCallback(async () => {
    setLoading(true);
    try {
      const { search } = router.query;
      const currentFilters = { ...filters };
      
      // Handle search parameter from URL (from homepage search)
      if (search && typeof search === 'string') {
        currentFilters.searchTerm = search;
        // Update the local filters state to reflect the URL search parameter
        if (!filters.searchTerm) {
          setFilters(prev => ({ ...prev, searchTerm: search }));
        }
      }
      
      const data = await childrenService.getAllChildren(page, limit, currentFilters);
      setChildren(data.children);
      setTotalChildren(data.total);
    } catch (error) {
      console.error("Failed to fetch children:", error);
      toast({
        title: "Error",
        description: "Could not load children data.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [page, filters, router.query, toast]);

  useEffect(() => {
    fetchChildren();
  }, [fetchChildren]);

  // Handle URL search parameter on component mount
  useEffect(() => {
    const { search } = router.query;
    if (search && typeof search === 'string' && search !== filters.searchTerm) {
      setFilters(prev => ({ ...prev, searchTerm: search }));
    }
  }, [router.query, filters.searchTerm]);

  const handleFilterChange = (newFilters: Record<string, unknown>) => {
    setPage(1);
    setFilters(newFilters as typeof filters);
    
    // Update URL to reflect search term
    if (newFilters.searchTerm && typeof newFilters.searchTerm === 'string') {
      router.push({
        pathname: '/children',
        query: { search: newFilters.searchTerm }
      }, undefined, { shallow: true });
    } else if (!newFilters.searchTerm && router.query.search) {
      // Remove search parameter if search term is cleared
      const newQuery = { ...router.query };
      delete newQuery.search;
      router.push({
        pathname: '/children',
        query: newQuery
      }, undefined, { shallow: true });
    }
  };

  const totalPages = Math.ceil(totalChildren / limit);

  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-[#d4af37]/10">
        {/* Hero Section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-[#101c2c] to-[#d4af37]">
          <div className="max-w-7xl mx-auto text-center">
            <Badge className="mb-6 bg-white/20 text-white hover:bg-white/30 border-white/30">
              💖 Find a Child to Support
            </Badge>
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Explore and Connect
            </h1>
            <p className="text-xl text-white/90 mb-8 max-w-3xl mx-auto">
              Browse through profiles of children who need your help. Use the filters to find a child you can connect with and make a difference in their life.
            </p>
          </div>
        </section>

        {/* Main Content */}
        <section className="py-12 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <Card className="mb-8 border-0 shadow-lg">
              <CardContent className="p-6">
                <SearchAndFilter 
                  onFiltersChange={handleFilterChange} 
                  showAdvanced={true} 
                />
              </CardContent>
            </Card>
            
            <div className="mb-4 text-sm text-gray-600">
              Showing {children.length} of {totalChildren} children
            </div>

            {/* Results Grid */}
            {loading ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {[...Array(limit)].map((_, i) => (
                  <div key={i} className="bg-white rounded-2xl p-6 shadow-lg animate-pulse">
                    <div className="h-48 bg-gray-200 rounded-lg mb-4"></div>
                    <div className="h-4 bg-gray-200 rounded mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  </div>
                ))}
              </div>
            ) : (
              <>
                {children.length > 0 ? (
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {children.map((child) => (
                      <EnhancedChildCard key={child.id} child={child} onDonationSuccess={fetchChildren} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-16">
                    <h3 className="text-xl font-semibold">No Children Found</h3>
                    <p className="text-gray-500 mt-2">Try adjusting your filters or check back later.</p>
                  </div>
                )}

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex justify-center items-center mt-12 space-x-4">
                    <Button 
                      onClick={() => setPage(p => Math.max(1, p - 1))} 
                      disabled={page === 1}
                      variant="outline"
                    >
                      Previous
                    </Button>
                    <span className="text-sm text-gray-600">
                      Page {page} of {totalPages}
                    </span>
                    <Button 
                      onClick={() => setPage(p => Math.min(totalPages, p + 1))} 
                      disabled={page === totalPages}
                      variant="outline"
                    >
                      Next
                    </Button>
                  </div>
                )}
              </>
            )}
          </div>
        </section>
      </div>
    </Layout>
  );
}
