import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Heart, Search, Users, TrendingUp, Shield, Globe, ArrowRight, Play } from "lucide-react";
import { useCurrency } from "@/contexts/CurrencyContext";
import { childrenService, Child } from "@/services/childrenService";
import { donationService } from "@/services/donationService";
import Layout from "@/components/Layout";
import dynamic from "next/dynamic";
import { useRouter } from "next/router";
import Image from "next/image";
import { formatNumber } from "@/lib/number";

const PaymentStatusBanner = dynamic(() => import("@/components/PaymentStatusBanner"), { ssr: false });

export default function HomePage() {
  const router = useRouter();
  const { formatPrice } = useCurrency();
  const [searchTerm, setSearchTerm] = useState("");
  const [featuredChildren, setFeaturedChildren] = useState<Child[]>([]);
  const [stats, setStats] = useState({
    totalDonated: 0,
    totalDonations: 0,
    childrenHelped: 0
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);
        
        // Fetch featured children with error handling
        try {
          const childrenData = await childrenService.getAllChildren(1, 6, { 
            status: 'active',
            sortBy: 'urgent'
          });
          setFeaturedChildren(childrenData.children);
        } catch (childrenError) {
          console.error("Failed to fetch children:", childrenError);
          setFeaturedChildren([]);
        }

        // Fetch platform stats with error handling
        try {
          const donationStats = await donationService.getDonationStats();
          setStats({
            totalDonated: donationStats.totalAmount,
            totalDonations: donationStats.totalDonations,
            childrenHelped: Math.floor(donationStats.totalAmount / 5000)
          });
        } catch (statsError) {
          console.error("Failed to fetch stats:", statsError);
          // Keep default stats
        }
      } catch (error) {
        console.error("Failed to fetch homepage data:", error);
        setError("We're having trouble loading data. Please try refreshing the page.");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      router.push(`/children?search=${encodeURIComponent(searchTerm.trim())}`);
    }
  };

  return (
    <Layout>
      <div className="min-h-screen">
        <PaymentStatusBanner />
        
        {/* Show error banner if data fetch failed */}
        {error && (
          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-sm text-yellow-700">{error}</p>
              </div>
            </div>
          </div>
        )}

        {/* Hero Section */}
        <section className="relative py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-[#101c2c] via-[#1e293b] to-[#334155] overflow-hidden">
          <div className="absolute inset-0 bg-black/20"></div>
          <div className="relative max-w-7xl mx-auto text-center">
            <Badge className="mb-6 bg-[#d4af37]/20 text-[#d4af37] hover:bg-[#d4af37]/30 border-[#d4af37]/30 text-sm px-4 py-2">
              ✨ Connecting Hearts, Changing Lives
            </Badge>
            
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight">
              Every Child Deserves
              <span className="block bg-gradient-to-r from-[#d4af37] to-[#b8941f] bg-clip-text text-transparent">
                Hope & Healing
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-4xl mx-auto leading-relaxed">
              Join our mission to provide life-saving medical care to children in need. 
              Your donation can be the difference between despair and hope.
            </p>

            {/* Search Bar */}
            <form onSubmit={handleSearch} className="max-w-2xl mx-auto mb-8">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  type="text"
                  placeholder="Search for a child by name, condition, or location..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-12 pr-32 py-4 text-lg bg-white/95 backdrop-blur-sm border-0 rounded-full shadow-xl focus:ring-4 focus:ring-yellow-400/30"
                />
                <Button 
                  type="submit"
                  className="absolute right-2 top-1/2 transform -translate-y-1/2 rounded-full px-6 py-2 bg-gradient-to-r from-[#d4af37] to-[#b8941f] hover:from-[#b8941f] hover:to-[#9a7a1a] transition-all duration-300"
                >
                  Search
                </Button>
              </div>
            </form>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button 
                size="lg" 
                onClick={() => router.push('/children')}
                className="bg-[#d4af37] text-white hover:bg-[#b8941f] px-8 py-4 text-lg font-semibold rounded-full shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300"
              >
                <Heart className="w-5 h-5 mr-2" />
                Start Donating
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                onClick={() => router.push('/help')}
                className="border-white text-white hover:bg-white hover:text-[#101c2c] px-8 py-4 text-lg font-semibold rounded-full backdrop-blur-sm bg-white/10 transition-all duration-300"
              >
                <Play className="w-5 h-5 mr-2" />
                Learn More
              </Button>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center group">
                <div className="w-16 h-16 bg-gradient-to-br from-[#101c2c] to-[#d4af37] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Heart className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
                  {loading ? "..." : formatPrice(stats.totalDonated)}
                </h3>
                <p className="text-gray-600 text-lg">Total Donations Raised</p>
              </div>
              <div className="text-center group">
                <div className="w-16 h-16 bg-gradient-to-br from-[#d4af37] to-[#101c2c] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Users className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
                  {loading ? "..." : formatNumber(stats.childrenHelped)}
                </h3>
                <p className="text-gray-600 text-lg">Children Helped</p>
              </div>
              <div className="text-center group">
                <div className="w-16 h-16 bg-gradient-to-br from-[#101c2c] to-[#d4af37] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                  <TrendingUp className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
                  {loading ? "..." : formatNumber(stats.totalDonations)}
                </h3>
                <p className="text-gray-600 text-lg">Lives Touched</p>
              </div>
            </div>
          </div>
        </section>

        {/* Featured Children */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-50 to-[#d4af37]/10">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <Badge className="mb-4 bg-[#d4af37]/20 text-[#d4af37] hover:bg-[#d4af37]/30">
                💝 Featured Stories
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Children Who Need Your Help
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Meet some of the brave children waiting for your support. Each story represents hope, courage, and the possibility of a brighter future.
              </p>
            </div>

            {loading ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="bg-white rounded-2xl p-6 shadow-lg animate-pulse">
                    <div className="h-48 bg-gray-200 rounded-lg mb-4"></div>
                    <div className="h-4 bg-gray-200 rounded mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
                    <div className="h-10 bg-gray-200 rounded"></div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {featuredChildren.map((child) => (
                  <Card key={child.id} className="group hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border-0 shadow-lg overflow-hidden">
                    <div className="relative">
                      <Image
                        src={child.image || "/api/placeholder/400/300"}
                        alt={child.name}
                        width={400}
                        height={300}
                        className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute top-4 right-4">
                        <Badge className={`${
                          child.urgency === 'high' ? 'bg-red-500' :
                          child.urgency === 'medium' ? 'bg-yellow-500' : 'bg-green-500'
                        } text-white`}>
                          {child.urgency} priority
                        </Badge>
                      </div>
                    </div>
                    <CardContent className="p-6">
                      <h3 className="text-xl font-bold text-gray-900 mb-2">{child.name}</h3>
                      <p className="text-gray-600 mb-3 line-clamp-2">{child.condition}</p>
                      <div className="mb-4">
                        <div className="flex justify-between text-sm text-gray-600 mb-1">
                          <span>Progress</span>
                          <span>{Math.round((child.raised_amount / child.target_amount) * 100)}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-gradient-to-r from-[#101c2c] to-[#d4af37] h-2 rounded-full transition-all duration-500"
                            style={{ width: `${Math.min(100, (child.raised_amount / child.target_amount) * 100)}%` }}
                          ></div>
                        </div>
                        <div className="flex justify-between text-sm text-gray-600 mt-1">
                          <span>{formatPrice(child.raised_amount)} raised</span>
                          <span>{formatPrice(child.target_amount)} goal</span>
                        </div>
                      </div>
                      <Button 
                        className="w-full bg-gradient-to-r from-[#101c2c] to-[#d4af37] hover:from-[#1e293b] hover:to-[#b8941f] transition-all duration-300"
                        onClick={() => router.push(`/children/${child.id}`)}
                      >
                        <Heart className="w-4 h-4 mr-2" />
                        Help {child.name}
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            <div className="text-center mt-12">
              <Button 
                size="lg"
                variant="outline"
                onClick={() => router.push('/children')}
                className="px-8 py-4 text-lg font-semibold border-2 border-[#101c2c] text-[#101c2c] hover:bg-[#101c2c] hover:text-white transition-all duration-300"
              >
                View All Children
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </div>
          </div>
        </section>

        {/* How It Works */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <Badge className="mb-4 bg-[#d4af37]/20 text-[#d4af37] hover:bg-[#d4af37]/30">
                🚀 Simple Process
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                How Your Donation Makes a Difference
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Our transparent process ensures your donation reaches the children who need it most, with real-time updates on their progress.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center group">
                <div className="w-20 h-20 bg-gradient-to-br from-[#d4af37]/20 to-[#d4af37]/30 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                  <Search className="w-10 h-10 text-[#101c2c]" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">1. Choose a Child</h3>
                <p className="text-gray-600">
                  Browse through verified profiles of children who need medical assistance. Each profile includes their story, medical condition, and funding goal.
                </p>
              </div>
              <div className="text-center group">
                <div className="w-20 h-20 bg-gradient-to-br from-[#101c2c]/20 to-[#101c2c]/30 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                  <Heart className="w-10 h-10 text-[#d4af37]" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">2. Make a Donation</h3>
                <p className="text-gray-600">
                  Donate any amount through our secure payment system. Choose to donate anonymously or leave a message of support for the child and family.
                </p>
              </div>
              <div className="text-center group">
                <div className="w-20 h-20 bg-gradient-to-br from-[#d4af37]/20 to-[#101c2c]/20 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                  <TrendingUp className="w-10 h-10 text-[#101c2c]" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">3. Track Impact</h3>
                <p className="text-gray-600">
                  Receive updates on the child's treatment progress. See how your donation is being used and the difference you're making in their life.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Trust & Security */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-50 to-[#d4af37]/10">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <Badge className="mb-4 bg-[#101c2c]/20 text-[#101c2c] hover:bg-[#101c2c]/30">
                🛡️ Trusted Platform
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Your Trust is Our Priority
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                We maintain the highest standards of transparency, security, and accountability to ensure your donations make the maximum impact.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <Card className="text-center p-8 border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <Shield className="w-12 h-12 text-[#101c2c] mx-auto mb-4" />
                <h3 className="text-xl font-bold text-gray-900 mb-3">Secure Payments</h3>
                <p className="text-gray-600">
                  All transactions are encrypted and processed through secure payment gateways. Your financial information is always protected.
                </p>
              </Card>
              <Card className="text-center p-8 border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <Globe className="w-12 h-12 text-[#d4af37] mx-auto mb-4" />
                <h3 className="text-xl font-bold text-gray-900 mb-3">100% Transparency</h3>
                <p className="text-gray-600">
                  Track exactly how your donation is used. We provide detailed reports and updates on every child's treatment progress.
                </p>
              </Card>
              <Card className="text-center p-8 border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <Users className="w-12 h-12 text-[#101c2c] mx-auto mb-4" />
                <h3 className="text-xl font-bold text-gray-900 mb-3">Verified Cases</h3>
                <p className="text-gray-600">
                  Every child profile is thoroughly verified by our medical team and partner organizations to ensure authenticity.
                </p>
              </Card>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-[#101c2c] to-[#d4af37]">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
              Ready to Change a Life Today?
            </h2>
            <p className="text-xl text-gray-200 mb-8 max-w-2xl mx-auto">
              Join thousands of donors who are making a real difference. Your contribution, no matter the size, can help save a child's life.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg"
                onClick={() => router.push('/children')}
                className="bg-white text-[#101c2c] hover:bg-gray-100 px-8 py-4 text-lg font-semibold rounded-full shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300"
              >
                <Heart className="w-5 h-5 mr-2" />
                Start Your Journey
              </Button>
              <Button 
                variant="outline"
                size="lg"
                onClick={() => router.push('/contact')}
                className="border-white text-white hover:bg-white hover:text-[#101c2c] px-8 py-4 text-lg font-semibold rounded-full backdrop-blur-sm bg-white/10 transition-all duration-300"
              >
                Get in Touch
              </Button>
            </div>
          </div>
        </section>
      </div>
    </Layout>
  );
}
