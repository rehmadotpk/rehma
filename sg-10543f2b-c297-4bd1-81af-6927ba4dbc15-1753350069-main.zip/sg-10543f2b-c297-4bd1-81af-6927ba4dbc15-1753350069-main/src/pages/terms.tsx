
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { FileText, Scale, Shield, CreditCard, Users, AlertTriangle, Mail, Phone, MapPin } from "lucide-react";
import Layout from "@/components/Layout";

export default function TermsOfServicePage() {
  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-gray-50">
        {/* Hero Section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-[#101c2c] to-[#1a2b3d]">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-6 bg-[#d4af37]/20 text-[#d4af37] hover:bg-[#d4af37]/30 border-[#d4af37]/30">
              📋 Terms & Conditions
            </Badge>
            
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Terms of Service
            </h1>
            
            <p className="text-xl text-gray-300 mb-8">
              Please read these terms carefully before using our platform. By using Rehma, you agree to these terms and conditions.
            </p>
            
            <p className="text-sm text-gray-400">
              Last updated: January 25, 2025
            </p>
          </div>
        </section>

        {/* Main Content */}
        <section className="py-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="space-y-8">
              {/* Introduction */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c] flex items-center">
                    <FileText className="w-6 h-6 mr-3 text-[#d4af37]" />
                    Agreement to Terms
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-gray max-w-none">
                  <p className="text-gray-600 leading-relaxed">
                    These Terms of Service ("Terms") govern your use of the Rehma platform operated by Rehma Foundation ("we," "our," or "us"). By accessing or using our website (rehma.ai) and services, you agree to be bound by these Terms.
                  </p>
                  <p className="text-gray-600 leading-relaxed">
                    If you disagree with any part of these terms, then you may not access or use our services. These Terms apply to all visitors, users, donors, and others who access or use the service.
                  </p>
                </CardContent>
              </Card>

              {/* Platform Description */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c] flex items-center">
                    <Users className="w-6 h-6 mr-3 text-[#d4af37]" />
                    Platform Description
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600 leading-relaxed">
                    Rehma is a charitable platform that connects donors with children who need medical assistance and special needs support. Our services include:
                  </p>
                  <ul className="list-disc list-inside space-y-2 text-gray-600">
                    <li>Facilitating donations to verified children and families in need</li>
                    <li>Connecting users with specialized healthcare providers</li>
                    <li>Providing a marketplace for artwork and products created by special needs children</li>
                    <li>Offering resources and support for families of special needs children</li>
                    <li>Partnering with NGOs and healthcare organizations</li>
                  </ul>
                </CardContent>
              </Card>

              {/* User Accounts */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c]">User Accounts and Registration</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    To access certain features of our platform, you must create an account. You agree to:
                  </p>
                  <ul className="list-disc list-inside space-y-2 text-gray-600">
                    <li>Provide accurate, current, and complete information during registration</li>
                    <li>Maintain and update your account information</li>
                    <li>Keep your login credentials secure and confidential</li>
                    <li>Accept responsibility for all activities under your account</li>
                    <li>Notify us immediately of any unauthorized use of your account</li>
                  </ul>
                  <p className="text-gray-600">
                    We reserve the right to suspend or terminate accounts that violate these Terms or engage in fraudulent activity.
                  </p>
                </CardContent>
              </Card>

              {/* Donations and Payments */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c] flex items-center">
                    <CreditCard className="w-6 h-6 mr-3 text-[#d4af37]" />
                    Donations and Payments
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-3">Donation Terms</h3>
                    <ul className="list-disc list-inside space-y-2 text-gray-600">
                      <li>All donations are voluntary and made at your own discretion</li>
                      <li>Donations are generally non-refundable unless required by law</li>
                      <li>We will use donations for their intended purpose as described on the platform</li>
                      <li>You may receive updates on how your donation is being used</li>
                      <li>Tax receipts will be provided where applicable and legally required</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-3">Payment Processing</h3>
                    <ul className="list-disc list-inside space-y-2 text-gray-600">
                      <li>Payments are processed through secure third-party payment providers</li>
                      <li>We do not store your complete payment information on our servers</li>
                      <li>Payment processing fees may apply as disclosed during checkout</li>
                      <li>Failed payments may result in donation cancellation</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-3">Refund Policy</h3>
                    <p className="text-gray-600">
                      Refunds may be considered in exceptional circumstances such as technical errors, duplicate charges, or fraudulent activity. Refund requests must be submitted within 30 days of the original donation.
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* User Conduct */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c] flex items-center">
                    <Scale className="w-6 h-6 mr-3 text-[#d4af37]" />
                    User Conduct and Prohibited Activities
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">You agree not to use our platform to:</p>
                  <ul className="list-disc list-inside space-y-2 text-gray-600">
                    <li>Violate any applicable laws or regulations</li>
                    <li>Impersonate any person or entity or misrepresent your affiliation</li>
                    <li>Submit false, misleading, or fraudulent information</li>
                    <li>Interfere with or disrupt the platform's operation or security</li>
                    <li>Attempt to gain unauthorized access to our systems</li>
                    <li>Use automated systems to access or interact with our platform</li>
                    <li>Harass, abuse, or harm other users</li>
                    <li>Upload malicious software or harmful content</li>
                    <li>Engage in money laundering or other financial crimes</li>
                  </ul>
                </CardContent>
              </Card>

              {/* Content and Intellectual Property */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c]">Content and Intellectual Property</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-3">Our Content</h3>
                    <p className="text-gray-600">
                      All content on our platform, including text, graphics, logos, images, and software, is owned by Rehma Foundation or our licensors and is protected by intellectual property laws.
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-3">User-Generated Content</h3>
                    <p className="text-gray-600">
                      By submitting content to our platform, you grant us a non-exclusive, worldwide, royalty-free license to use, display, and distribute your content for platform operations and promotional purposes.
                    </p>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-3">Children's Artwork</h3>
                    <p className="text-gray-600">
                      Artwork created by children and sold through our platform remains the intellectual property of the child artist. We facilitate sales with appropriate consent from parents or guardians.
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Privacy and Data Protection */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c] flex items-center">
                    <Shield className="w-6 h-6 mr-3 text-[#d4af37]" />
                    Privacy and Data Protection
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 leading-relaxed">
                    Your privacy is important to us. Our collection, use, and protection of your personal information is governed by our Privacy Policy, which is incorporated into these Terms by reference. By using our platform, you consent to our data practices as described in the Privacy Policy.
                  </p>
                </CardContent>
              </Card>

              {/* Medical Information Disclaimer */}
              <Card className="border-0 shadow-lg bg-yellow-50 border-yellow-200">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c] flex items-center">
                    <AlertTriangle className="w-6 h-6 mr-3 text-yellow-600" />
                    Medical Information Disclaimer
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 leading-relaxed">
                    The information provided on our platform is for informational purposes only and should not be considered medical advice. We do not provide medical services or diagnoses. Always consult with qualified healthcare professionals for medical decisions. We are not responsible for medical outcomes or treatment decisions made based on information from our platform.
                  </p>
                </CardContent>
              </Card>

              {/* Disclaimers and Limitations */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c]">Disclaimers and Limitations of Liability</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-3">Service Availability</h3>
                    <p className="text-gray-600">
                      Our platform is provided "as is" without warranties of any kind. We do not guarantee uninterrupted or error-free service and may suspend or modify services at any time.
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-3">Third-Party Services</h3>
                    <p className="text-gray-600">
                      We work with third-party service providers (payment processors, healthcare providers, NGOs). We are not responsible for their actions, services, or content.
                    </p>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-3">Limitation of Liability</h3>
                    <p className="text-gray-600">
                      To the maximum extent permitted by law, Rehma Foundation shall not be liable for any indirect, incidental, special, or consequential damages arising from your use of our platform.
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Termination */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c]">Termination</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 leading-relaxed">
                    We may terminate or suspend your account and access to our services immediately, without prior notice, for conduct that we believe violates these Terms or is harmful to other users, us, or third parties, or for any other reason at our sole discretion.
                  </p>
                  <p className="text-gray-600 leading-relaxed mt-4">
                    You may terminate your account at any time by contacting us. Upon termination, your right to use our services will cease immediately.
                  </p>
                </CardContent>
              </Card>

              {/* Governing Law */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c]">Governing Law and Dispute Resolution</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    These Terms are governed by the laws of Pakistan. Any disputes arising from these Terms or your use of our platform will be resolved through:
                  </p>
                  <ol className="list-decimal list-inside space-y-2 text-gray-600">
                    <li>Good faith negotiations between the parties</li>
                    <li>Mediation through a mutually agreed mediator</li>
                    <li>Binding arbitration if mediation fails</li>
                    <li>Courts of competent jurisdiction in Lahore, Pakistan as a last resort</li>
                  </ol>
                </CardContent>
              </Card>

              {/* Changes to Terms */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c]">Changes to Terms</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 leading-relaxed">
                    We reserve the right to modify these Terms at any time. We will notify users of material changes by posting the updated Terms on our website and updating the "Last updated" date. Your continued use of our platform after changes constitutes acceptance of the new Terms.
                  </p>
                </CardContent>
              </Card>

              {/* Contact Information */}
              <Card className="border-0 shadow-lg bg-gradient-to-r from-[#101c2c]/5 to-[#d4af37]/5">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c]">Contact Information</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-6">
                    If you have questions about these Terms of Service, please contact us:
                  </p>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-3">
                      <div className="flex items-center space-x-3">
                        <Mail className="w-5 h-5 text-[#d4af37]" />
                        <span className="text-gray-700">legal@rehma.ai</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Phone className="w-5 h-5 text-[#d4af37]" />
                        <span className="text-gray-700">+92-42-1234-5678</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <MapPin className="w-5 h-5 text-[#d4af37]" />
                        <span className="text-gray-700">Lahore, Pakistan</span>
                      </div>
                    </div>
                    <div>
                      <Button className="bg-[#d4af37] hover:bg-[#b8941f] text-white">
                        Contact Legal Team
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </div>
    </Layout>
  );
}
