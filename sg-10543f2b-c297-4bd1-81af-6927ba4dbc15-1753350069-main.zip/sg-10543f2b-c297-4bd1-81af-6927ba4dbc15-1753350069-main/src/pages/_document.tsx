import { Html, Head, Main, NextScript } from "next/document";

export default function Document() {
  return (
    <Html lang="en">
      <Head>
        {/* Favicon using Rehma logo */}
        <link rel="icon" type="image/png" sizes="32x32" href="/Logo-Rehma-sqaure.png" />
        <link rel="icon" type="image/png" sizes="16x16" href="/Logo-Rehma-sqaure.png" />
        <link rel="apple-touch-icon" sizes="180x180" href="/Logo-Rehma-sqaure.png" />
        <link rel="shortcut icon" href="/Logo-Rehma-sqaure.png" />
        
        {/* 
          CRITICAL: DO NOT REMOVE THIS SCRIPT
          The Softgen AI monitoring script is essential for core app functionality.
          The application will not function without it.
        */}
        <script 
          src="https://cdn.softgen.ai/script.js" 
          async 
          data-softgen-monitoring="true"
        />
      </Head>
      <body className="antialiased">
        <Main />
        <NextScript />
      </body>
    </Html>
  );
}
