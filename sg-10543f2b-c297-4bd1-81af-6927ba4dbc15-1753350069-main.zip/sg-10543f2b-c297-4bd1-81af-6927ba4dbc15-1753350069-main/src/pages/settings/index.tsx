import { useState, useEffect, useCallback } from "react";
import { useRouter } from "next/router";
import Layout from "@/components/Layout";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { 
  Loader2, 
  Lock, 
  Bell, 
  Shield, 
  Trash2, 
  AlertTriangle, 
  Settings, 
  Globe, 
  DollarSign, 
  CreditCard,
  RefreshCw
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { authService } from "@/services/authService";
import { systemSettingsService, SystemSettings } from "@/services/systemSettingsService";
import { formatDate } from "@/lib/dateUtils";

export default function SettingsPage() {
  const { user, userProfile, signOut, loading } = useAuth();
  const [isAdmin, setIsAdmin] = useState(false);
  const [checkingAdmin, setCheckingAdmin] = useState(true);
  const [systemSettings, setSystemSettings] = useState<SystemSettings[]>([]);
  const [loadingSettings, setLoadingSettings] = useState(false);
  const [settingsExist, setSettingsExist] = useState(false);
  const [initializingSettings, setInitializingSettings] = useState(false);
  
  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: ""
  });
  const [changingPassword, setChangingPassword] = useState(false);
  const [notifications, setNotifications] = useState({
    email: true,
    push: false,
    donations: true,
    updates: true
  });
  const { toast } = useToast();
  const router = useRouter();

  const loadSystemSettings = useCallback(async () => {
    try {
      setLoadingSettings(true);
      
      // Check if settings exist
      const exist = await systemSettingsService.checkSettingsExist();
      setSettingsExist(exist);
      
      if (exist) {
        const settings = await systemSettingsService.getAllSettings();
        setSystemSettings(settings);
      }
    } catch (error) {
      console.error("Error loading system settings:", error);
      toast({
        title: "Error",
        description: "Failed to load system settings.",
        variant: "destructive",
      });
    } finally {
      setLoadingSettings(false);
    }
  }, [toast]);

  // Check if user is admin
  useEffect(() => {
    const checkAdminStatus = async () => {
      if (user && userProfile) {
        const adminStatus = userProfile.role === 'admin';
        setIsAdmin(adminStatus);
        setCheckingAdmin(false);
        
        if (adminStatus) {
          await loadSystemSettings();
        }
      } else if (!loading) {
        setCheckingAdmin(false);
      }
    };

    checkAdminStatus();
  }, [user, userProfile, loading, loadSystemSettings]);

  const initializeSystemSettings = async () => {
    if (!user) return;
    
    try {
      setInitializingSettings(true);
      await systemSettingsService.initializeDefaultSettings(user.id);
      await loadSystemSettings();
      toast({
        title: "Settings Initialized",
        description: "System settings have been initialized with default values.",
      });
    } catch (error) {
      console.error('Error initializing settings:', error);
      toast({
        title: "Error",
        description: "Failed to initialize system settings.",
        variant: "destructive",
      });
    } finally {
      setInitializingSettings(false);
    }
  };

  const updateSystemSetting = async (key: string, value: string) => {
    if (!user) return;
    
    try {
      await systemSettingsService.updateSetting(key, value, user.id);
      
      // Update local state
      setSystemSettings(prev => 
        prev.map(setting => 
          setting.setting_key === key 
            ? { ...setting, setting_value: value, updated_at: new Date().toISOString() }
            : setting
        )
      );
      
      toast({
        title: "Setting Updated",
        description: "System setting has been updated successfully.",
      });
    } catch (error) {
      console.error('Error updating setting:', error);
      toast({
        title: "Error",
        description: "Failed to update system setting.",
        variant: "destructive",
      });
    }
  };

  const getSettingValue = (key: string): string => {
    const setting = systemSettings.find(s => s.setting_key === key);
    return setting?.setting_value || '';
  };

  if (loading || checkingAdmin) {
    return (
      <Layout>
        <div className="min-h-screen flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin" />
        </div>
      </Layout>
    );
  }

  if (!user) {
    router.push('/auth/login');
    return null;
  }

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast({
        title: "Error",
        description: "New passwords do not match.",
        variant: "destructive",
      });
      return;
    }

    if (passwordData.newPassword.length < 6) {
      toast({
        title: "Error",
        description: "Password must be at least 6 characters long.",
        variant: "destructive",
      });
      return;
    }

    setChangingPassword(true);
    try {
      await authService.updatePassword(passwordData.newPassword);
      setPasswordData({
        currentPassword: "",
        newPassword: "",
        confirmPassword: ""
      });
      toast({
        title: "Password updated",
        description: "Your password has been successfully changed.",
      });
    } catch (error) {
      console.error("Failed to update password:", error);
      toast({
        title: "Error",
        description: "Failed to update password. Please try again.",
        variant: "destructive",
      });
    } finally {
      setChangingPassword(false);
    }
  };

  const handleNotificationChange = (key: string, value: boolean) => {
    setNotifications(prev => ({ ...prev, [key]: value }));
    toast({
      title: "Settings updated",
      description: "Your notification preferences have been saved.",
    });
  };

  const handleDeleteAccount = async () => {
    if (window.confirm("Are you sure you want to delete your account? This action cannot be undone.")) {
      try {
        await signOut();
        router.push('/');
        toast({
          title: "Account deleted",
          description: "Your account has been successfully deleted.",
        });
      } catch (error) {
        console.error("Failed to delete account:", error);
        toast({
          title: "Error",
          description: "Failed to delete account. Please contact support.",
          variant: "destructive",
        });
      }
    }
  };

  const tabsList = isAdmin 
    ? ["security", "notifications", "system", "account"]
    : ["security", "notifications", "account"];

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
            <p className="text-gray-600 mt-2">
              Manage your account settings and preferences
              {isAdmin && " • System administration"}
            </p>
          </div>

          <Tabs defaultValue="security" className="space-y-6">
            <TabsList className={`grid w-full ${isAdmin ? 'grid-cols-4' : 'grid-cols-3'}`}>
              <TabsTrigger value="security">Security</TabsTrigger>
              <TabsTrigger value="notifications">Notifications</TabsTrigger>
              {isAdmin && <TabsTrigger value="system">System Settings</TabsTrigger>}
              <TabsTrigger value="account">Account</TabsTrigger>
            </TabsList>

            <TabsContent value="security">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lock className="w-5 h-5" />
                    Security Settings
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handlePasswordChange} className="space-y-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Change Password</h3>
                      
                      <div className="space-y-2">
                        <Label htmlFor="currentPassword">Current Password</Label>
                        <Input
                          id="currentPassword"
                          type="password"
                          value={passwordData.currentPassword}
                          onChange={(e) => setPasswordData(prev => ({ ...prev, currentPassword: e.target.value }))}
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="newPassword">New Password</Label>
                        <Input
                          id="newPassword"
                          type="password"
                          value={passwordData.newPassword}
                          onChange={(e) => setPasswordData(prev => ({ ...prev, newPassword: e.target.value }))}
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="confirmPassword">Confirm New Password</Label>
                        <Input
                          id="confirmPassword"
                          type="password"
                          value={passwordData.confirmPassword}
                          onChange={(e) => setPasswordData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                          required
                        />
                      </div>
                    </div>

                    <Button type="submit" disabled={changingPassword}>
                      {changingPassword ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Updating Password...
                        </>
                      ) : (
                        'Update Password'
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="notifications">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Bell className="w-5 h-5" />
                    Notification Preferences
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Email Notifications</h4>
                        <p className="text-sm text-gray-600">Receive notifications via email</p>
                      </div>
                      <Switch
                        checked={notifications.email}
                        onCheckedChange={(checked) => handleNotificationChange('email', checked)}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Push Notifications</h4>
                        <p className="text-sm text-gray-600">Receive push notifications in your browser</p>
                      </div>
                      <Switch
                        checked={notifications.push}
                        onCheckedChange={(checked) => handleNotificationChange('push', checked)}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Donation Updates</h4>
                        <p className="text-sm text-gray-600">Get notified about donation confirmations and updates</p>
                      </div>
                      <Switch
                        checked={notifications.donations}
                        onCheckedChange={(checked) => handleNotificationChange('donations', checked)}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Platform Updates</h4>
                        <p className="text-sm text-gray-600">Receive updates about new features and improvements</p>
                      </div>
                      <Switch
                        checked={notifications.updates}
                        onCheckedChange={(checked) => handleNotificationChange('updates', checked)}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {isAdmin && (
              <TabsContent value="system">
                <div className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Settings className="w-5 h-5" />
                        System Settings
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={loadSystemSettings}
                          disabled={loadingSettings}
                          className="ml-auto"
                        >
                          {loadingSettings ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <RefreshCw className="w-4 h-4" />
                          )}
                        </Button>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {!settingsExist ? (
                        <div className="text-center py-8">
                          <Settings className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                          <h3 className="text-lg font-medium text-gray-900 mb-2">
                            System Settings Not Initialized
                          </h3>
                          <p className="text-gray-600 mb-4">
                            System settings need to be initialized with default values.
                          </p>
                          <Button
                            onClick={initializeSystemSettings}
                            disabled={initializingSettings}
                          >
                            {initializingSettings ? (
                              <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Initializing...
                              </>
                            ) : (
                              'Initialize System Settings'
                            )}
                          </Button>
                        </div>
                      ) : (
                        <Tabs defaultValue="platform" className="space-y-6">
                          <TabsList className="grid w-full grid-cols-4">
                            <TabsTrigger value="platform">
                              <Globe className="w-4 h-4 mr-2" />
                              Platform
                            </TabsTrigger>
                            <TabsTrigger value="donations">
                              <DollarSign className="w-4 h-4 mr-2" />
                              Donations
                            </TabsTrigger>
                            <TabsTrigger value="security">
                              <Shield className="w-4 h-4 mr-2" />
                              Security
                            </TabsTrigger>
                            <TabsTrigger value="payments">
                              <CreditCard className="w-4 h-4 mr-2" />
                              Payments
                            </TabsTrigger>
                          </TabsList>

                          <TabsContent value="platform">
                            <div className="space-y-6">
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="space-y-2">
                                  <Label htmlFor="platformName">Platform Name</Label>
                                  <Input
                                    id="platformName"
                                    value={getSettingValue('platformName')}
                                    onChange={(e) => updateSystemSetting('platformName', e.target.value)}
                                    placeholder="Platform name"
                                  />
                                </div>
                                
                                <div className="space-y-2">
                                  <Label htmlFor="supportEmail">Support Email</Label>
                                  <Input
                                    id="supportEmail"
                                    type="email"
                                    value={getSettingValue('supportEmail')}
                                    onChange={(e) => updateSystemSetting('supportEmail', e.target.value)}
                                    placeholder="support@example.com"
                                  />
                                </div>
                              </div>

                              <div className="space-y-2">
                                <Label htmlFor="platformDescription">Platform Description</Label>
                                <Textarea
                                  id="platformDescription"
                                  value={getSettingValue('platformDescription')}
                                  onChange={(e) => updateSystemSetting('platformDescription', e.target.value)}
                                  placeholder="Describe your platform"
                                  rows={3}
                                />
                              </div>

                              <div className="flex items-center justify-between">
                                <div>
                                  <h4 className="font-medium">Maintenance Mode</h4>
                                  <p className="text-sm text-gray-600">Enable maintenance mode to restrict access</p>
                                </div>
                                <Switch
                                  checked={getSettingValue('maintenanceMode') === 'true'}
                                  onCheckedChange={(checked) => updateSystemSetting('maintenanceMode', checked.toString())}
                                />
                              </div>
                            </div>
                          </TabsContent>

                          <TabsContent value="donations">
                            <div className="space-y-6">
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <div className="space-y-2">
                                  <Label htmlFor="minDonationAmount">Minimum Donation ($)</Label>
                                  <Input
                                    id="minDonationAmount"
                                    type="number"
                                    value={getSettingValue('minDonationAmount')}
                                    onChange={(e) => updateSystemSetting('minDonationAmount', e.target.value)}
                                    min="1"
                                  />
                                </div>
                                
                                <div className="space-y-2">
                                  <Label htmlFor="maxDonationAmount">Maximum Donation ($)</Label>
                                  <Input
                                    id="maxDonationAmount"
                                    type="number"
                                    value={getSettingValue('maxDonationAmount')}
                                    onChange={(e) => updateSystemSetting('maxDonationAmount', e.target.value)}
                                    min="1"
                                  />
                                </div>

                                <div className="space-y-2">
                                  <Label htmlFor="defaultCurrency">Default Currency</Label>
                                  <Select
                                    value={getSettingValue('defaultCurrency')}
                                    onValueChange={(value) => updateSystemSetting('defaultCurrency', value)}
                                  >
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select currency" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="USD">USD - US Dollar</SelectItem>
                                      <SelectItem value="EUR">EUR - Euro</SelectItem>
                                      <SelectItem value="GBP">GBP - British Pound</SelectItem>
                                      <SelectItem value="PKR">PKR - Pakistani Rupee</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </div>
                              </div>

                              <div className="flex items-center justify-between">
                                <div>
                                  <h4 className="font-medium">Enable Recurring Donations</h4>
                                  <p className="text-sm text-gray-600">Allow users to set up recurring donations</p>
                                </div>
                                <Switch
                                  checked={getSettingValue('enableRecurringDonations') === 'true'}
                                  onCheckedChange={(checked) => updateSystemSetting('enableRecurringDonations', checked.toString())}
                                />
                              </div>
                            </div>
                          </TabsContent>

                          <TabsContent value="security">
                            <div className="space-y-6">
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="space-y-2">
                                  <Label htmlFor="passwordMinLength">Minimum Password Length</Label>
                                  <Input
                                    id="passwordMinLength"
                                    type="number"
                                    value={getSettingValue('passwordMinLength')}
                                    onChange={(e) => updateSystemSetting('passwordMinLength', e.target.value)}
                                    min="6"
                                    max="20"
                                  />
                                </div>
                                
                                <div className="space-y-2">
                                  <Label htmlFor="sessionTimeout">Session Timeout (hours)</Label>
                                  <Input
                                    id="sessionTimeout"
                                    type="number"
                                    value={getSettingValue('sessionTimeout')}
                                    onChange={(e) => updateSystemSetting('sessionTimeout', e.target.value)}
                                    min="1"
                                    max="168"
                                  />
                                </div>
                              </div>

                              <div className="space-y-4">
                                <div className="flex items-center justify-between">
                                  <div>
                                    <h4 className="font-medium">Require Email Verification</h4>
                                    <p className="text-sm text-gray-600">New users must verify their email address</p>
                                  </div>
                                  <Switch
                                    checked={getSettingValue('requireEmailVerification') === 'true'}
                                    onCheckedChange={(checked) => updateSystemSetting('requireEmailVerification', checked.toString())}
                                  />
                                </div>
                              </div>
                            </div>
                          </TabsContent>

                          <TabsContent value="payments">
                            <div className="space-y-6">
                              <div className="space-y-4">
                                <div className="flex items-center justify-between">
                                  <div>
                                    <h4 className="font-medium">Enable Stripe Payments</h4>
                                    <p className="text-sm text-gray-600">Accept payments through Stripe</p>
                                  </div>
                                  <Switch
                                    checked={getSettingValue('enableStripe') === 'true'}
                                    onCheckedChange={(checked) => updateSystemSetting('enableStripe', checked.toString())}
                                  />
                                </div>

                                <div className="flex items-center justify-between">
                                  <div>
                                    <h4 className="font-medium">Enable PayPal Payments</h4>
                                    <p className="text-sm text-gray-600">Accept payments through PayPal</p>
                                  </div>
                                  <Switch
                                    checked={getSettingValue('enablePayPal') === 'true'}
                                    onCheckedChange={(checked) => updateSystemSetting('enablePayPal', checked.toString())}
                                  />
                                </div>
                              </div>

                              <div className="space-y-2">
                                <Label htmlFor="processingFeePercentage">Processing Fee Percentage</Label>
                                <Input
                                  id="processingFeePercentage"
                                  type="number"
                                  step="0.1"
                                  value={getSettingValue('processingFeePercentage')}
                                  onChange={(e) => updateSystemSetting('processingFeePercentage', e.target.value)}
                                  min="0"
                                  max="10"
                                />
                                <p className="text-sm text-gray-600">
                                  Percentage fee charged for payment processing
                                </p>
                              </div>
                            </div>
                          </TabsContent>
                        </Tabs>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            )}

            <TabsContent value="account">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Shield className="w-5 h-5" />
                      Account Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <Label>Email Address</Label>
                        <p className="text-gray-900">{user.email}</p>
                      </div>
                      {userProfile && (
                        <>
                          <div>
                            <Label>Full Name</Label>
                            <p className="text-gray-900">{userProfile.full_name}</p>
                          </div>
                          <div>
                            <Label>Role</Label>
                            <p className="text-gray-900 capitalize">{userProfile.role}</p>
                          </div>
                          <div>
                            <Label>Verification Status</Label>
                            <p className={`font-medium ${userProfile.verified ? 'text-green-600' : 'text-yellow-600'}`}>
                              {userProfile.verified ? 'Verified' : 'Pending Verification'}
                            </p>
                          </div>
                        </>
                      )}
                      <div>
                        <Label>Account Created</Label>
                        <p className="text-gray-900">
                          {formatDate(user.created_at, "yyyy-MM-dd")}
                        </p>
                      </div>
                      <div>
                        <Label>Last Sign In</Label>
                        <p className="text-gray-900">
                          {user.last_sign_in_at ? formatDate(user.last_sign_in_at, "yyyy-MM-dd") : "Never"}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-red-200">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-red-600">
                      <AlertTriangle className="w-5 h-5" />
                      Danger Zone
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Alert className="border-red-200 bg-red-50 mb-4">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription className="text-red-800">
                        Once you delete your account, there is no going back. Please be certain.
                      </AlertDescription>
                    </Alert>
                    
                    <Button
                      variant="destructive"
                      onClick={handleDeleteAccount}
                      className="flex items-center gap-2"
                    >
                      <Trash2 className="w-4 h-4" />
                      Delete Account
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </Layout>
  );
}
