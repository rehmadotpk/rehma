import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MapPin, Phone, Mail, Clock, Send, MessageCircle, Users, Building, Heart } from "lucide-react";
import Image from "next/image";
import Layout from "@/components/Layout";
import { useRouter } from "next/router";

interface ContactForm {
  name: string;
  email: string;
  phone: string;
  subject: string;
  category: string;
  message: string;
}

const contactInfo = [
  {
    icon: MapPin,
    title: "Visit Our Office",
    details: [
      "Rehma Foundation",
      "123 Main Street, Gulberg III",
      "Lahore, Punjab 54000",
      "Pakistan"
    ],
    color: "bg-[#101c2c]"
  },
  {
    icon: Phone,
    title: "Call Us",
    details: [
      "Main: +92-42-1234-5678",
      "Support: +92-300-1234567",
      "Emergency: +92-321-9876543",
      "WhatsApp: +92-300-1234567"
    ],
    color: "bg-[#d4af37]"
  },
  {
    icon: Mail,
    title: "Email Us",
    details: [
      "General: info@rehma.ai",
      "Support: support@rehma.ai",
      "Partnerships: partners@rehma.ai",
      "Media: media@rehma.ai"
    ],
    color: "bg-[#101c2c]"
  },
  {
    icon: Clock,
    title: "Office Hours",
    details: [
      "Monday - Friday: 9:00 AM - 6:00 PM",
      "Saturday: 10:00 AM - 4:00 PM",
      "Sunday: Closed",
      "Emergency Support: 24/7"
    ],
    color: "bg-[#d4af37]"
  }
];

const categories = [
  "General Inquiry",
  "Donation Support",
  "Medical Assistance",
  "NGO Partnership",
  "Doctor Registration",
  "Technical Support",
  "Media & Press",
  "Volunteer Opportunities"
];

const teamMembers = [
  {
    name: "Dr. Sarah Ahmed",
    role: "Founder & CEO",
    image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=300&h=300&fit=crop&crop=face",
    email: "sarah@rehma.ai"
  },
  {
    name: "Ahmad Hassan",
    role: "Head of Operations",
    image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=300&h=300&fit=crop&crop=face",
    email: "ahmad@rehma.ai"
  },
  {
    name: "Fatima Khan",
    role: "Medical Director",
    image: "https://images.unsplash.com/photo-1594824388853-d0c2d4e5b1b7?w=300&h=300&fit=crop&crop=face",
    email: "fatima@rehma.ai"
  },
  {
    name: "Ali Raza",
    role: "Technology Lead",
    image: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=300&h=300&fit=crop&crop=face",
    email: "ali@rehma.ai"
  }
];

export default function ContactPage() {
  const router = useRouter();
  const [formData, setFormData] = useState<ContactForm>({
    name: "",
    email: "",
    phone: "",
    subject: "",
    category: "",
    message: ""
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (field: keyof ContactForm, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    setTimeout(() => {
      alert("Thank you for your message! We'll get back to you within 24 hours.");
      setFormData({
        name: "",
        email: "",
        phone: "",
        subject: "",
        category: "",
        message: ""
      });
      setIsSubmitting(false);
    }, 2000);
  };

  return (
    <Layout>
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-gray-50">
      {/* Hero Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-[#101c2c] to-[#1a2b3d]">
        <div className="max-w-7xl mx-auto text-center">
          <Badge className="mb-6 bg-[#d4af37]/20 text-[#d4af37] hover:bg-[#d4af37]/30 border-[#d4af37]/30">
            📞 Get in Touch
          </Badge>
          
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Contact Us
          </h1>
          
          <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
            Have questions, need support, or want to partner with us? We're here to help you make a difference in the lives of special needs children.
          </p>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-[#101c2c] mb-4">Get in Touch</h2>
            <p className="text-xl text-gray-600">Multiple ways to reach us</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {contactInfo.map((info, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6 text-center">
                  <div className={`w-16 h-16 ${info.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                    <info.icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="font-semibold text-lg mb-4">{info.title}</h3>
                  <div className="space-y-1">
                    {info.details.map((detail, detailIndex) => (
                      <p key={detailIndex} className="text-sm text-gray-600">
                        {detail}
                      </p>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form & Map */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div>
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c]">Send us a Message</CardTitle>
                  <p className="text-gray-600">We'll respond within 24 hours</p>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-2">Full Name *</label>
                        <Input
                          required
                          value={formData.name}
                          onChange={(e) => handleInputChange("name", e.target.value)}
                          placeholder="Your full name"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">Email *</label>
                        <Input
                          type="email"
                          required
                          value={formData.email}
                          onChange={(e) => handleInputChange("email", e.target.value)}
                          placeholder="your.email@example.com"
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-2">Phone Number</label>
                        <Input
                          value={formData.phone}
                          onChange={(e) => handleInputChange("phone", e.target.value)}
                          placeholder="+92-300-1234567"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">Category *</label>
                        <Select value={formData.category} onValueChange={(value) => handleInputChange("category", value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                          <SelectContent>
                            {categories.map((category) => (
                              <SelectItem key={category} value={category}>
                                {category}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Subject *</label>
                      <Input
                        required
                        value={formData.subject}
                        onChange={(e) => handleInputChange("subject", e.target.value)}
                        placeholder="Brief subject of your message"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Message *</label>
                      <Textarea
                        required
                        value={formData.message}
                        onChange={(e) => handleInputChange("message", e.target.value)}
                        placeholder="Please provide details about your inquiry..."
                        className="min-h-[120px]"
                      />
                    </div>

                    <Button 
                      type="submit" 
                      disabled={isSubmitting}
                      className="w-full bg-[#d4af37] hover:bg-[#b8941f] text-white"
                    >
                      {isSubmitting ? (
                        "Sending..."
                      ) : (
                        <>
                          <Send className="w-4 h-4 mr-2" />
                          Send Message
                        </>
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Map & Additional Info */}
            <div className="space-y-8">
              {/* Map Placeholder */}
              <Card className="border-0 shadow-lg">
                <CardContent className="p-0">
                  <div className="h-64 bg-gradient-to-br from-[#101c2c]/10 to-[#d4af37]/10 rounded-lg flex items-center justify-center">
                    <div className="text-center">
                      <MapPin className="w-12 h-12 text-[#101c2c] mx-auto mb-4" />
                      <h3 className="font-semibold text-lg mb-2">Find Us Here</h3>
                      <p className="text-gray-600">Interactive map coming soon</p>
                      <Button variant="outline" className="mt-4 border-[#101c2c] text-[#101c2c] hover:bg-[#101c2c] hover:text-white">
                        Get Directions
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Contact Options */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-[#101c2c]">Quick Contact</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button 
                    variant="outline" 
                    className="w-full justify-start border-[#d4af37] text-[#d4af37] hover:bg-[#d4af37] hover:text-white"
                    onClick={() => window.open('mailto:support@rehma.ai?subject=Live Chat Request&body=Hello, I would like to start a live chat session. Please contact me at your earliest convenience.', '_blank')}
                  >
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Start Live Chat
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start border-[#d4af37] text-[#d4af37] hover:bg-[#d4af37] hover:text-white"
                    onClick={() => window.open('mailto:support@rehma.ai?subject=Schedule a Call Request&body=Hello, I would like to schedule a call. Please let me know your available times.', '_blank')}
                  >
                    <Phone className="w-4 h-4 mr-2" />
                    Schedule a Call
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start border-[#d4af37] text-[#d4af37] hover:bg-[#d4af37] hover:text-white"
                    onClick={() => window.open('mailto:support@rehma.ai?subject=Support Request&body=Hello, I need assistance with...', '_blank')}
                  >
                    <Mail className="w-4 h-4 mr-2" />
                    Email Support
                  </Button>
                </CardContent>
              </Card>

              {/* Emergency Contact */}
              <Card className="border-0 shadow-lg bg-red-50">
                <CardHeader>
                  <CardTitle className="text-red-800">Emergency Support</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-red-700 text-sm mb-4">
                    For urgent medical situations or crisis support
                  </p>
                  <Button className="w-full bg-red-600 hover:bg-red-700">
                    Emergency Hotline: +92-321-9876543
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-[#101c2c] mb-4">Meet Our Team</h2>
            <p className="text-xl text-gray-600">Dedicated professionals working to make a difference</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {teamMembers.map((member, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6 text-center">
                  <Image
                    src={member.image}
                    alt={member.name}
                    width={96}
                    height={96}
                    className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
                  />
                  <h3 className="font-semibold text-lg mb-1">{member.name}</h3>
                  <p className="text-[#101c2c] text-sm mb-3">{member.role}</p>
                  <Button variant="outline" size="sm" className="border-[#d4af37] text-[#d4af37] hover:bg-[#d4af37] hover:text-white">
                    <Mail className="w-3 h-3 mr-1" />
                    Contact
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Partnership CTA */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-[#101c2c] to-[#1a2b3d]">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Partner with Us
          </h2>
          <p className="text-xl text-gray-300 mb-8">
            Join our mission to create a more inclusive world for special needs children
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              onClick={() => router.push('/partnerships/ngo')}
              className="bg-[#d4af37] hover:bg-[#b8941f] text-white font-semibold px-8 py-3"
            >
              <Building className="w-5 h-5 mr-2" />
              NGO Partnership
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              onClick={() => router.push('/partnerships/volunteer')}
              className="border-white text-white hover:bg-white hover:text-[#101c2c] font-semibold px-8 py-3"
            >
              <Users className="w-5 h-5 mr-2" />
              Volunteer with Us
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              onClick={() => router.push('/partnerships/corporate')}
              className="border-white text-white hover:bg-white hover:text-[#101c2c] font-semibold px-8 py-3"
            >
              <Heart className="w-5 h-5 mr-2" />
              Corporate Sponsorship
            </Button>
          </div>
        </div>
      </section>
    </div>
    </Layout>
  );
}
