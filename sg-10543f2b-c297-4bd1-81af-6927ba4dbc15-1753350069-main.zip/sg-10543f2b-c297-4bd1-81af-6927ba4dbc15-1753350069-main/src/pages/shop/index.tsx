import { useState, useEffect } from "react";
import Layout from "@/components/Layout";
import BannerSystem from "@/components/BannerSystem";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, ShoppingBag, Star, Filter } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import Image from "next/image";

interface ShopItem {
  id: string;
  title: string;
  artist: string;
  artist_age: number;
  price: number;
  category: string;
  image: string;
  description: string;
  rating: number;
  sales: number;
  verified: boolean;
  story: string;
  created_at: string;
}

export default function ShopPage() {
  const { isAdmin } = useAuth();
  const [items, setItems] = useState<ShopItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    fetchShopItems();
  }, []);

  const fetchShopItems = async () => {
    try {
      const { data, error } = await supabase
        .from('shop_items')
        .select('*')
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setItems(data || []);
    } catch (error) {
      console.error('Error fetching shop items:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredItems = items.filter(item =>
    item.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.artist?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50">
        {/* Hero Banner */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
          <BannerSystem position="hero" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Art Shop</h1>
                <p className="text-gray-600 mt-2">Support young artists by purchasing their beautiful artwork</p>
              </div>
              {isAdmin && (
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Artwork
                </Button>
              )}
            </div>
          </div>

          {/* Between Sections Banner */}
          <BannerSystem position="between-sections" />

          <div className="mb-6 flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search artwork..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button variant="outline">
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Sidebar with Banner */}
            <div className="lg:col-span-1 order-2 lg:order-1">
              <BannerSystem position="sidebar" />
              
              {/* Additional sidebar content can go here */}
              <Card className="p-4 mb-6">
                <h3 className="font-semibold mb-3">Categories</h3>
                <div className="space-y-2">
                  <Button variant="ghost" className="w-full justify-start text-sm">
                    Paintings
                  </Button>
                  <Button variant="ghost" className="w-full justify-start text-sm">
                    Drawings
                  </Button>
                  <Button variant="ghost" className="w-full justify-start text-sm">
                    Crafts
                  </Button>
                  <Button variant="ghost" className="w-full justify-start text-sm">
                    Digital Art
                  </Button>
                </div>
              </Card>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-3 order-1 lg:order-2">
              {loading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
                </div>
              ) : filteredItems.length === 0 ? (
                <Card className="text-center py-12">
                  <CardContent>
                    <ShoppingBag className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">No Artwork Available</h3>
                    <p className="text-gray-600 mb-6">
                      {searchTerm 
                        ? "No artwork matches your search criteria. Try adjusting your search terms."
                        : "No artwork has been added to the shop yet. Check back later for beautiful pieces from young artists."
                      }
                    </p>
                    {isAdmin && (
                      <Button>
                        <Plus className="w-4 h-4 mr-2" />
                        Add First Artwork
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                  {filteredItems.map((item) => (
                    <Card key={item.id} className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border-0 shadow-lg overflow-hidden">
                      <div className="relative">
                        <Image
                          src={item.image || "/api/placeholder/400/300"}
                          alt={item.title}
                          width={400}
                          height={300}
                          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute top-4 right-4">
                          <Badge className="bg-[#d4af37] text-white">
                            ⭐ {item.rating}
                          </Badge>
                        </div>
                      </div>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg line-clamp-1">{item.title}</CardTitle>
                        <div className="flex items-center justify-between">
                          <p className="text-sm text-gray-600">by {item.artist}, {item.artist_age}</p>
                          <div className="flex items-center">
                            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                            <span className="text-sm ml-1">{item.rating}</span>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="text-sm text-gray-600 line-clamp-2 mb-3">{item.description}</p>
                        <div className="flex items-center justify-between">
                          <span className="text-2xl font-bold text-primary">${item.price}</span>
                          <Button size="sm">
                            Add to Cart
                          </Button>
                        </div>
                        <p className="text-xs text-gray-500 mt-2">{item.sales} sold</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Footer Banner */}
          <div className="mt-12">
            <BannerSystem position="footer" />
          </div>
        </div>
      </div>
    </Layout>
  );
}
