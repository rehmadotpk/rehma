import { useState, useEffect } from "react";
import Layout from "@/components/Layout";
import BannerSystem from "@/components/BannerSystem";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, Building2, Users, MapPin, Globe, Phone, Mail } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";

interface NGO {
  id: string;
  organization_name: string;
  description: string;
  focus_areas: string[];
  contact_person: string;
  contact_email: string;
  contact_phone: string;
  website: string;
  address: string;
  verified: boolean;
  status: string;
  created_at: string;
}

export default function NGOsPage() {
  const { isAdmin } = useAuth();
  const [ngos, setNgos] = useState<NGO[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    fetchNGOs();
  }, []);

  const fetchNGOs = async () => {
    try {
      const { data, error } = await supabase
        .from('ngos')
        .select('*')
        .eq('status', 'approved')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setNgos(data || []);
    } catch (error) {
      console.error('Error fetching NGOs:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredNGOs = ngos.filter(ngo =>
    ngo.organization_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ngo.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ngo.focus_areas?.some(area => area.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50">
        {/* Hero Banner */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
          <BannerSystem position="hero" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Partner NGOs</h1>
                <p className="text-gray-600 mt-2">Connect with verified non-governmental organizations</p>
              </div>
              {isAdmin && (
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Add NGO
                </Button>
              )}
            </div>
          </div>

          {/* Between Sections Banner */}
          <BannerSystem position="between-sections" />

          <div className="mb-6">
            <div className="relative max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search NGOs..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Sidebar with Banner */}
            <div className="lg:col-span-1 order-2 lg:order-1">
              <BannerSystem position="sidebar" />
              
              {/* Additional sidebar content */}
              <Card className="p-4 mb-6">
                <h3 className="font-semibold mb-3">Filter by Focus</h3>
                <div className="space-y-2">
                  <Button variant="ghost" className="w-full justify-start text-sm">
                    Education
                  </Button>
                  <Button variant="ghost" className="w-full justify-start text-sm">
                    Healthcare
                  </Button>
                  <Button variant="ghost" className="w-full justify-start text-sm">
                    Special Needs
                  </Button>
                  <Button variant="ghost" className="w-full justify-start text-sm">
                    Community Support
                  </Button>
                </div>
              </Card>

              <Card className="p-4">
                <h3 className="font-semibold mb-3">Quick Stats</h3>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Total NGOs</span>
                    <span className="font-medium">{ngos.length}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Verified</span>
                    <span className="font-medium">{ngos.filter(n => n.verified).length}</span>
                  </div>
                </div>
              </Card>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-3 order-1 lg:order-2">
              {loading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
                </div>
              ) : filteredNGOs.length === 0 ? (
                <Card className="text-center py-12">
                  <CardContent>
                    <Building2 className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">No NGOs Found</h3>
                    <p className="text-gray-600 mb-6">
                      {searchTerm 
                        ? "No NGOs match your search criteria. Try adjusting your search terms."
                        : "No NGO partners have been added yet. Check back later for updates."
                      }
                    </p>
                    {isAdmin && (
                      <Button>
                        <Plus className="w-4 h-4 mr-2" />
                        Add First NGO
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {filteredNGOs.map((ngo) => (
                    <Card key={ngo.id} className="hover:shadow-lg transition-shadow">
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <CardTitle className="text-lg">{ngo.organization_name}</CardTitle>
                          {ngo.verified && (
                            <Badge variant="default" className="ml-2">
                              Verified
                            </Badge>
                          )}
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <p className="text-gray-600 text-sm line-clamp-3">{ngo.description}</p>
                        
                        {ngo.focus_areas && ngo.focus_areas.length > 0 && (
                          <div className="flex flex-wrap gap-1">
                            {ngo.focus_areas.slice(0, 3).map((area, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {area}
                              </Badge>
                            ))}
                            {ngo.focus_areas.length > 3 && (
                              <Badge variant="secondary" className="text-xs">
                                +{ngo.focus_areas.length - 3} more
                              </Badge>
                            )}
                          </div>
                        )}

                        <div className="space-y-2 text-sm text-gray-600">
                          {ngo.contact_person && (
                            <div className="flex items-center">
                              <Users className="w-4 h-4 mr-2" />
                              {ngo.contact_person}
                            </div>
                          )}
                          {ngo.address && (
                            <div className="flex items-center">
                              <MapPin className="w-4 h-4 mr-2" />
                              {ngo.address}
                            </div>
                          )}
                          {ngo.website && (
                            <div className="flex items-center">
                              <Globe className="w-4 h-4 mr-2" />
                              <a href={ngo.website} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                                Visit Website
                              </a>
                            </div>
                          )}
                        </div>

                        <div className="flex space-x-2 pt-4">
                          {ngo.contact_email && (
                            <Button variant="outline" size="sm" asChild>
                              <a href={`mailto:${ngo.contact_email}`}>
                                <Mail className="w-4 h-4 mr-1" />
                                Email
                              </a>
                            </Button>
                          )}
                          {ngo.contact_phone && (
                            <Button variant="outline" size="sm" asChild>
                              <a href={`tel:${ngo.contact_phone}`}>
                                <Phone className="w-4 h-4 mr-1" />
                                Call
                              </a>
                            </Button>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Footer Banner */}
          <div className="mt-12">
            <BannerSystem position="footer" />
          </div>
        </div>
      </div>
    </Layout>
  );
}
