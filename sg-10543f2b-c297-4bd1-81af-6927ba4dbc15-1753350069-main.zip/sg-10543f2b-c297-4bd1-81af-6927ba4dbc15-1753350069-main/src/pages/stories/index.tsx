import { useState, useEffect } from "react";
import { useRouter } from "next/router";
import Image from "next/image";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Heart, 
  Search,
  Filter,
  BookOpen,
  Star,
  MessageCircle,
  Eye,
  ArrowRight
} from "lucide-react";
import Layout from "@/components/Layout";
import { formatDate } from "@/lib/dateUtils";

interface Story {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  authorRole: string;
  authorImage?: string;
  featuredImage: string;
  category: 'success' | 'update' | 'news' | 'impact';
  tags: string[];
  publishedAt: string;
  readTime: number;
  likes: number;
  comments: number;
  views: number;
  featured: boolean;
}

export default function StoriesPage() {
  const router = useRouter();
  const [stories, setStories] = useState<Story[]>([]);
  const [filteredStories, setFilteredStories] = useState<Story[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [loading, setLoading] = useState(true);

  // Mock data for stories
  useEffect(() => {
    const mockStories: Story[] = [
      {
        id: "1",
        title: "Ahmad's Journey to Recovery: A Success Story",
        excerpt: "After 8 months of treatment and community support, Ahmad has made remarkable progress in his recovery journey.",
        content: "Full story content here...",
        author: "Dr. Sarah Ahmed",
        authorRole: "Medical Director",
        authorImage: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=100&h=100&fit=crop&crop=face",
        featuredImage: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?w=800&h=400&fit=crop",
        category: "success",
        tags: ["Recovery", "Medical Care", "Community Support"],
        publishedAt: "2024-01-15",
        readTime: 5,
        likes: 124,
        comments: 18,
        views: 1250,
        featured: true
      },
      {
        id: "2",
        title: "New Partnership with Shaukat Khanum Hospital",
        excerpt: "We're excited to announce our new partnership that will provide specialized care for children with complex medical needs.",
        content: "Full story content here...",
        author: "Rehma Team",
        authorRole: "Communications",
        featuredImage: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=800&h=400&fit=crop",
        category: "news",
        tags: ["Partnership", "Healthcare", "Expansion"],
        publishedAt: "2024-01-12",
        readTime: 3,
        likes: 89,
        comments: 12,
        views: 890,
        featured: false
      },
      {
        id: "3",
        title: "Monthly Impact Report: December 2023",
        excerpt: "See how your donations made a difference last month - 47 children received care, 12 surgeries completed.",
        content: "Full story content here...",
        author: "Impact Team",
        authorRole: "Analytics",
        featuredImage: "https://images.unsplash.com/photo-1551601651-2a8555f1a136?w=800&h=400&fit=crop",
        category: "impact",
        tags: ["Impact", "Statistics", "Transparency"],
        publishedAt: "2024-01-08",
        readTime: 4,
        likes: 156,
        comments: 24,
        views: 2100,
        featured: true
      },
      {
        id: "4",
        title: "Fatima's First Steps: A Milestone Celebration",
        excerpt: "After months of physiotherapy, 4-year-old Fatima took her first independent steps, bringing joy to everyone involved.",
        content: "Full story content here...",
        author: "Physiotherapy Team",
        authorRole: "Healthcare Provider",
        featuredImage: "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?w=800&h=400&fit=crop",
        category: "update",
        tags: ["Milestone", "Physiotherapy", "Progress"],
        publishedAt: "2024-01-05",
        readTime: 6,
        likes: 203,
        comments: 31,
        views: 1800,
        featured: false
      }
    ];

    setStories(mockStories);
    setFilteredStories(mockStories);
    setLoading(false);
  }, []);

  useEffect(() => {
    let filtered = stories;

    if (searchTerm) {
      filtered = filtered.filter(story => 
        story.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        story.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
        story.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    if (selectedCategory !== "all") {
      filtered = filtered.filter(story => story.category === selectedCategory);
    }

    setFilteredStories(filtered);
  }, [searchTerm, selectedCategory, stories]);

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'success': return 'bg-green-100 text-green-800';
      case 'update': return 'bg-blue-100 text-blue-800';
      case 'news': return 'bg-purple-100 text-purple-800';
      case 'impact': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case 'success': return 'Success Story';
      case 'update': return 'Progress Update';
      case 'news': return 'News';
      case 'impact': return 'Impact Report';
      default: return category;
    }
  };

  const featuredStories = filteredStories.filter(story => story.featured);
  const regularStories = filteredStories.filter(story => !story.featured);

  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-[#101c2c]/5 via-white to-yellow-50">
        {/* Hero Section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-[#101c2c] to-yellow-600">
          <div className="max-w-7xl mx-auto text-center">
            <Badge className="mb-6 bg-white/20 text-white hover:bg-white/30 border-white/30">
              📖 Stories of Hope & Impact
            </Badge>
            
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Stories That Inspire
            </h1>
            
            <p className="text-xl text-yellow-100 mb-8 max-w-3xl mx-auto">
              Read about the incredible journeys, milestones, and transformations happening in our community. Every story represents a life changed through your generosity.
            </p>

            {/* Search and Filter */}
            <div className="bg-white rounded-2xl p-6 max-w-4xl mx-auto shadow-xl">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <Input
                    placeholder="Search stories, tags, or topics..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-full md:w-48">
                    <Filter className="w-4 h-4 mr-2" />
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Stories</SelectItem>
                    <SelectItem value="success">Success Stories</SelectItem>
                    <SelectItem value="update">Progress Updates</SelectItem>
                    <SelectItem value="news">News</SelectItem>
                    <SelectItem value="impact">Impact Reports</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </section>

        {/* Featured Stories */}
        {featuredStories.length > 0 && (
          <section className="py-16 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto">
              <div className="flex items-center mb-8">
                <Star className="w-6 h-6 text-yellow-500 mr-2" />
                <h2 className="text-2xl font-bold text-gray-900">Featured Stories</h2>
              </div>
              
              <div className="grid md:grid-cols-2 gap-8">
                {featuredStories.map((story) => (
                  <Card key={story.id} className="hover:shadow-xl transition-all duration-300 border-0 shadow-lg overflow-hidden group cursor-pointer" onClick={() => router.push(`/stories/${story.id}`)}>
                    <div className="relative">
                      <Image 
                        src={story.featuredImage} 
                        alt={story.title}
                        width={800}
                        height={400}
                        className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <Badge className={`absolute top-4 left-4 ${getCategoryColor(story.category)}`}>
                        {getCategoryLabel(story.category)}
                      </Badge>
                      <div className="absolute bottom-4 right-4 bg-black/70 text-white px-3 py-1 rounded-full text-sm">
                        {story.readTime} min read
                      </div>
                    </div>

                    <CardHeader className="pb-3">
                      <CardTitle className="text-xl mb-2 group-hover:text-[#101c2c] transition-colors">
                        {story.title}
                      </CardTitle>
                      <p className="text-gray-600 text-sm line-clamp-2">{story.excerpt}</p>
                    </CardHeader>

                    <CardContent className="space-y-4">
                      <div className="flex items-center space-x-3">
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={story.authorImage} />
                          <AvatarFallback className="bg-gradient-to-br from-blue-100 to-purple-100">
                            {story.author.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium text-sm">{story.author}</p>
                          <p className="text-xs text-gray-500">{story.authorRole}</p>
                        </div>
                        <div className="flex-1" />
                        <p className="text-xs text-gray-500">
                          {formatDate(story.publishedAt, "yyyy-MM-dd")}
                        </p>
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t">
                        <div className="flex items-center space-x-4 text-sm text-gray-500">
                          <span className="flex items-center">
                            <Eye className="w-4 h-4 mr-1" />
                            {story.views}
                          </span>
                          <span className="flex items-center">
                            <Heart className="w-4 h-4 mr-1" />
                            {story.likes}
                          </span>
                          <span className="flex items-center">
                            <MessageCircle className="w-4 h-4 mr-1" />
                            {story.comments}
                          </span>
                        </div>
                        <Button variant="ghost" size="sm" className="text-[#101c2c] hover:bg-[#101c2c] hover:text-white">
                          Read More
                          <ArrowRight className="w-3 h-3 ml-1" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Regular Stories */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-7xl mx-auto">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-2xl font-bold text-gray-900">
                {selectedCategory === "all" ? "All Stories" : `${getCategoryLabel(selectedCategory)}s`}
                <span className="text-gray-500 ml-2">({filteredStories.length})</span>
              </h2>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {regularStories.map((story) => (
                <Card key={story.id} className="hover:shadow-xl transition-all duration-300 border-0 shadow-lg overflow-hidden group cursor-pointer" onClick={() => router.push(`/stories/${story.id}`)}>
                  <div className="relative">
                    <Image 
                      src={story.featuredImage} 
                      alt={story.title}
                      width={400}
                      height={200}
                      className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <Badge className={`absolute top-3 left-3 text-xs ${getCategoryColor(story.category)}`}>
                      {getCategoryLabel(story.category)}
                    </Badge>
                  </div>

                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg mb-2 group-hover:text-[#101c2c] transition-colors line-clamp-2">
                      {story.title}
                    </CardTitle>
                    <p className="text-gray-600 text-sm line-clamp-2">{story.excerpt}</p>
                  </CardHeader>

                  <CardContent className="space-y-3">
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span>{story.author}</span>
                      <span>{story.readTime} min read</span>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t">
                      <div className="flex items-center space-x-3 text-xs text-gray-500">
                        <span className="flex items-center">
                          <Heart className="w-3 h-3 mr-1" />
                          {story.likes}
                        </span>
                        <span className="flex items-center">
                          <MessageCircle className="w-3 h-3 mr-1" />
                          {story.comments}
                        </span>
                      </div>
                      <p className="text-xs text-gray-500">
                        {formatDate(story.publishedAt, "yyyy-MM-dd")}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {filteredStories.length === 0 && !loading && (
              <div className="text-center py-12">
                <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-medium text-gray-900 mb-2">No stories found</h3>
                <p className="text-gray-500">Try adjusting your search or filter criteria.</p>
              </div>
            )}
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-[#101c2c] to-yellow-600">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              Be Part of the Next Story
            </h2>
            <p className="text-xl text-yellow-100 mb-8">
              Every donation creates a new chapter in a child's life. Your support today could be tomorrow's success story.
            </p>
            <Button 
              size="lg" 
              onClick={() => router.push('/children')}
              className="bg-white text-[#101c2c] hover:bg-gray-100 font-semibold px-8 py-3 transition-all duration-200 hover:scale-105 transform"
            >
              <Heart className="w-5 h-5 mr-2" />
              Start Your Impact Story
            </Button>
          </div>
        </section>
      </div>
    </Layout>
  );
}
