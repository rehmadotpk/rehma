
import { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, Mail, ArrowLeft, AlertCircle, CheckCircle } from "lucide-react";
import authService from "@/services/authService";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [fieldError, setFieldError] = useState("");

  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleInputChange = (value: string) => {
    setEmail(value);
    if (fieldError) setFieldError("");
    if (error) setError("");
    if (success) setSuccess("");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate email
    if (!email.trim()) {
      setFieldError("Email is required");
      return;
    }
    
    if (!validateEmail(email.trim())) {
      setFieldError("Please enter a valid email address");
      return;
    }

    setLoading(true);
    setError("");
    setSuccess("");
    setFieldError("");

    try {
      await authService.resetPassword(email.trim().toLowerCase());
      setSuccess("Password reset email sent! Please check your inbox and follow the instructions to reset your password.");
    } catch (err) {
      if (err instanceof Error) {
        if (err.message.includes('User not found')) {
          setError('No account found with this email address. Please check your email or create a new account.');
        } else if (err.message.includes('Email not confirmed')) {
          setError('Please verify your email address first before resetting your password.');
        } else {
          setError(err.message);
        }
      } else {
        setError('An error occurred while sending the reset email. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#101c2c]/5 via-white to-yellow-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-[#101c2c] mb-2">Reset Password</h1>
          <p className="text-gray-600">Enter your email to receive a reset link</p>
        </div>

        <Card className="border-0 shadow-xl">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl text-center text-[#101c2c]">Forgot Password</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4" noValidate>
              {error && (
                <Alert className="border-red-200 bg-red-50">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription className="text-red-800">
                    {error}
                  </AlertDescription>
                </Alert>
              )}

              {success && (
                <Alert className="border-green-200 bg-green-50">
                  <CheckCircle className="h-4 w-4" />
                  <AlertDescription className="text-green-800">
                    {success}
                  </AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="your.email@example.com"
                    value={email}
                    onChange={(e) => handleInputChange(e.target.value)}
                    className={`pl-10 ${fieldError ? 'border-red-500 focus:border-red-500' : ''}`}
                    required
                    autoComplete="email"
                    autoFocus
                    disabled={loading}
                  />
                </div>
                {fieldError && (
                  <p className="text-sm text-red-600 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    {fieldError}
                  </p>
                )}
              </div>

              <Button 
                type="submit" 
                className="w-full bg-gradient-to-r from-[#101c2c] to-yellow-600 hover:from-[#1e293b] hover:to-yellow-700 transition-all duration-300 focus:ring-2 focus:ring-[#101c2c] focus:ring-offset-2"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Sending reset email...
                  </>
                ) : (
                  'Send Reset Email'
                )}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <Link 
                href="/auth/login" 
                className="inline-flex items-center text-sm text-[#101c2c] hover:text-yellow-600 font-medium transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-[#101c2c] rounded px-1"
              >
                <ArrowLeft className="w-4 h-4 mr-1" />
                Back to Sign In
              </Link>
            </div>

            <div className="mt-4 text-center">
              <p className="text-sm text-gray-600">
                Don't have an account?{' '}
                <Link 
                  href="/auth/register" 
                  className="text-[#101c2c] hover:text-yellow-600 font-medium transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-[#101c2c] rounded px-1"
                >
                  Sign up
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
