import { useState, useEffect } from "react";
import { useCurrency } from "@/contexts/CurrencyContext";
import { useAuth } from "@/contexts/AuthContext";
import Layout from "@/components/Layout";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { donationService, Donation } from "@/services/donationService";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { formatDate } from "@/lib/dateUtils";

const TrackPage = () => {
  const { user, loading: authLoading } = useAuth();
  const { formatPrice } = useCurrency();
  const [donations, setDonations] = useState<Donation[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      const fetchDonations = async () => {
        setLoading(true);
        setError(null);
        try {
          const { donations: userDonations } = await donationService.getUserDonations(user.email as string);
          setDonations(userDonations);
        } catch (err) {
          setError((err as Error).message || "An error occurred.");
        } finally {
          setLoading(false);
        }
      };
      fetchDonations();
    } else if (!authLoading) {
      setLoading(false);
    }
  }, [user, authLoading]);

  return (
    <Layout>
      <div className="flex flex-col gap-6 p-4 md:p-8">
        <header>
          <h1 className="text-3xl font-bold">My Donations</h1>
          <p className="text-gray-600">Track the status and impact of your contributions.</p>
        </header>
        <main className="flex flex-col gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Donation History</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex justify-center items-center p-10">
                  <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
                </div>
              ) : error ? (
                <div className="text-center text-red-500 p-4 bg-red-50 rounded-md">
                  <p>{error}</p>
                </div>
              ) : !user ? (
                <div className="text-center text-gray-500 p-10 border-2 border-dashed rounded-md">
                  <p>Please sign in to view your donation history.</p>
                </div>
              ) : donations.length === 0 ? (
                <div className="text-center text-gray-500 p-10 border-2 border-dashed rounded-md">
                  <p>You haven't made any donations yet.</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Recipient</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {donations.map((donation) => (
                      <TableRow key={donation.id}>
                        <TableCell>{formatDate(donation.created_at, "yyyy-MM-dd")}</TableCell>
                        <TableCell className="font-medium">
                          {formatPrice(donation.amount)}
                        </TableCell>
                        <TableCell>{donation.child?.name || "N/A"}</TableCell>
                        <TableCell>
                          <Badge 
                            variant={donation.payment_status === 'completed' ? 'default' : 'secondary'}
                            className="capitalize"
                          >
                            {donation.payment_status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button variant="outline" size="sm">View Details</Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </main>
      </div>
    </Layout>
  );
};

export default TrackPage;
