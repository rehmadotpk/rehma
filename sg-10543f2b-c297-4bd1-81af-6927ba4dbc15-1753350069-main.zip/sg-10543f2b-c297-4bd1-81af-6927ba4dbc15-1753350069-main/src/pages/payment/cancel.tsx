import { useRouter } from "next/router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { XCircle, Home, RotateCcw } from "lucide-react";

export default function PaymentCancelPage() {
  const router = useRouter();

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md mx-auto">
        <CardHeader className="text-center">
          <div className="mx-auto w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
            <XCircle className="h-8 w-8 text-red-600" />
          </div>
          <CardTitle className="text-2xl text-red-700">Payment Cancelled</CardTitle>
          <p className="text-muted-foreground">
            Your payment was cancelled. No charges have been made to your account.
          </p>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="pt-4 space-y-2">
            <Button
              onClick={() => router.push("/")}
              className="w-full"
              variant="default"
            >
              <Home className="h-4 w-4 mr-2" />
              Return to Home
            </Button>
            
            <Button
              onClick={() => router.back()}
              className="w-full"
              variant="outline"
            >
              <RotateCcw className="h-4 w-4 mr-2" />
              Try Again
            </Button>
          </div>

          <div className="text-center pt-4">
            <p className="text-xs text-muted-foreground">
              If you experienced any issues, please contact our support team.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
