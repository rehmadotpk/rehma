import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, Home, Receipt } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { donationService, Donation } from "@/services/donationService";
import LoadingSpinner from "@/components/LoadingSpinner";
import { formatNumber } from "@/lib/number";

export default function PaymentSuccessPage() {
  const router = useRouter();
  const { donation_id } = router.query;
  const [donation, setDonation] = useState<Donation | null>(null);
  const [loading, setLoading] = useState(true);

  const loadDonationDetails = useCallback(async () => {
    if (!donation_id) {
      setLoading(false);
      return;
    }
    try {
      const donationData = await donationService.getDonationById(donation_id as string);
      // Also update status to completed on success page visit as a fallback to webhook
      if (donationData.payment_status !== 'completed') {
        const updatedDonation = await donationService.updateDonation(donationData.id, { payment_status: 'completed' });
        setDonation(updatedDonation);
      } else {
        setDonation(donationData);
      }
    } catch (error) {
      console.error("Error loading donation:", error);
    } finally {
      setLoading(false);
    }
  }, [donation_id]);

  useEffect(() => {
    loadDonationDetails();
  }, [loadDonationDetails]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md mx-auto">
        <CardHeader className="text-center">
          <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
          <CardTitle className="text-2xl text-green-700">Payment Successful!</CardTitle>
          <p className="text-muted-foreground">
            Thank you for your generous donation. Your contribution will make a real difference.
          </p>
        </CardHeader>

        <CardContent className="space-y-4">
          {donation && (
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Amount:</span>
                <Badge variant="secondary" className="text-lg font-bold">
                  PKR {donation.amount ? formatNumber(donation.amount) : "0"}
                </Badge>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Donation ID:</span>
                <span className="text-sm font-mono">{donation.id}</span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Status:</span>
                <Badge variant="default" className="bg-green-600">
                  {donation.payment_status}
                </Badge>
              </div>
            </div>
          )}

          <div className="pt-4 space-y-2">
            <Button
              onClick={() => router.push("/")}
              className="w-full"
              variant="default"
            >
              <Home className="h-4 w-4 mr-2" />
              Return to Home
            </Button>
            
            {donation && (
              <Button
                onClick={() => router.push(`/api/payments/receipt/${donation.id}`)}
                className="w-full"
                variant="outline"
              >
                <Receipt className="h-4 w-4 mr-2" />
                Download Receipt
              </Button>
            )}
          </div>

          <div className="text-center pt-4">
            <p className="text-xs text-muted-foreground">
              A confirmation email has been sent to your registered email address.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
