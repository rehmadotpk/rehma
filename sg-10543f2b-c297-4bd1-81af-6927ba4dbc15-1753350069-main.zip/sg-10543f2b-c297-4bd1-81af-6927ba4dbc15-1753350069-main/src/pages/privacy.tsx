
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield, Eye, Lock, Database, Users, Mail, Phone, MapPin } from "lucide-react";
import Layout from "@/components/Layout";

export default function PrivacyPolicyPage() {
  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-gray-50">
        {/* Hero Section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-[#101c2c] to-[#1a2b3d]">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-6 bg-[#d4af37]/20 text-[#d4af37] hover:bg-[#d4af37]/30 border-[#d4af37]/30">
              🛡️ Your Privacy Matters
            </Badge>
            
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Privacy Policy
            </h1>
            
            <p className="text-xl text-gray-300 mb-8">
              We are committed to protecting your privacy and ensuring the security of your personal information.
            </p>
            
            <p className="text-sm text-gray-400">
              Last updated: January 25, 2025
            </p>
          </div>
        </section>

        {/* Main Content */}
        <section className="py-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="space-y-8">
              {/* Introduction */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c] flex items-center">
                    <Shield className="w-6 h-6 mr-3 text-[#d4af37]" />
                    Introduction
                  </CardTitle>
                </CardHeader>
                <CardContent className="prose prose-gray max-w-none">
                  <p className="text-gray-600 leading-relaxed">
                    Rehma Foundation ("we," "our," or "us") operates the Rehma platform (rehma.ai) to connect donors with children in need of medical assistance. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website or use our services.
                  </p>
                  <p className="text-gray-600 leading-relaxed">
                    By using our platform, you consent to the data practices described in this policy. If you do not agree with the practices described in this policy, please do not access or use our services.
                  </p>
                </CardContent>
              </Card>

              {/* Information We Collect */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c] flex items-center">
                    <Database className="w-6 h-6 mr-3 text-[#d4af37]" />
                    Information We Collect
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-3">Personal Information</h3>
                    <ul className="list-disc list-inside space-y-2 text-gray-600">
                      <li>Name, email address, and phone number</li>
                      <li>Payment information (processed securely through our payment partners)</li>
                      <li>Donation history and preferences</li>
                      <li>Profile information and account settings</li>
                      <li>Communication preferences and messages</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-3">Usage Information</h3>
                    <ul className="list-disc list-inside space-y-2 text-gray-600">
                      <li>Device information (IP address, browser type, operating system)</li>
                      <li>Usage patterns and interaction with our platform</li>
                      <li>Cookies and similar tracking technologies</li>
                      <li>Location data (with your consent)</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-3">Medical Information</h3>
                    <ul className="list-disc list-inside space-y-2 text-gray-600">
                      <li>Medical records and documentation (for children seeking assistance)</li>
                      <li>Treatment progress reports and updates</li>
                      <li>Healthcare provider information</li>
                      <li>Insurance and financial assistance information</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              {/* How We Use Information */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c] flex items-center">
                    <Eye className="w-6 h-6 mr-3 text-[#d4af37]" />
                    How We Use Your Information
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="list-disc list-inside space-y-3 text-gray-600">
                    <li>Process donations and maintain transaction records</li>
                    <li>Provide updates on children's treatment progress</li>
                    <li>Communicate with you about our services and impact</li>
                    <li>Improve our platform and user experience</li>
                    <li>Ensure platform security and prevent fraud</li>
                    <li>Comply with legal obligations and regulatory requirements</li>
                    <li>Generate anonymized reports and statistics</li>
                    <li>Facilitate connections between donors, children, and healthcare providers</li>
                  </ul>
                </CardContent>
              </Card>

              {/* Information Sharing */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c] flex items-center">
                    <Users className="w-6 h-6 mr-3 text-[#d4af37]" />
                    Information Sharing and Disclosure
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    We do not sell, trade, or rent your personal information to third parties. We may share your information in the following circumstances:
                  </p>
                  <ul className="list-disc list-inside space-y-2 text-gray-600">
                    <li><strong>Service Providers:</strong> With trusted partners who assist in platform operations (payment processing, email services, analytics)</li>
                    <li><strong>Healthcare Partners:</strong> With medical professionals and NGOs involved in children's care (with appropriate consent)</li>
                    <li><strong>Legal Requirements:</strong> When required by law, court order, or government regulation</li>
                    <li><strong>Safety and Security:</strong> To protect the rights, property, or safety of our users and platform</li>
                    <li><strong>Business Transfers:</strong> In connection with mergers, acquisitions, or asset sales (with user notification)</li>
                  </ul>
                </CardContent>
              </Card>

              {/* Data Security */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c] flex items-center">
                    <Lock className="w-6 h-6 mr-3 text-[#d4af37]" />
                    Data Security
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    We implement industry-standard security measures to protect your personal information:
                  </p>
                  <ul className="list-disc list-inside space-y-2 text-gray-600">
                    <li>SSL encryption for all data transmission</li>
                    <li>Secure database storage with access controls</li>
                    <li>Regular security audits and vulnerability assessments</li>
                    <li>Employee training on data protection practices</li>
                    <li>Multi-factor authentication for administrative access</li>
                    <li>Regular data backups and disaster recovery procedures</li>
                  </ul>
                  <p className="text-gray-600">
                    While we strive to protect your information, no method of transmission over the internet is 100% secure. We cannot guarantee absolute security but are committed to protecting your data using reasonable measures.
                  </p>
                </CardContent>
              </Card>

              {/* Your Rights */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c]">Your Rights and Choices</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">You have the following rights regarding your personal information:</p>
                  <ul className="list-disc list-inside space-y-2 text-gray-600">
                    <li><strong>Access:</strong> Request a copy of the personal information we hold about you</li>
                    <li><strong>Correction:</strong> Request correction of inaccurate or incomplete information</li>
                    <li><strong>Deletion:</strong> Request deletion of your personal information (subject to legal requirements)</li>
                    <li><strong>Portability:</strong> Request transfer of your data to another service provider</li>
                    <li><strong>Opt-out:</strong> Unsubscribe from marketing communications at any time</li>
                    <li><strong>Restrict Processing:</strong> Request limitation of how we process your information</li>
                  </ul>
                  <p className="text-gray-600">
                    To exercise these rights, please contact us using the information provided below. We will respond to your request within 30 days.
                  </p>
                </CardContent>
              </Card>

              {/* Cookies and Tracking */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c]">Cookies and Tracking Technologies</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600">
                    We use cookies and similar technologies to enhance your experience on our platform:
                  </p>
                  <ul className="list-disc list-inside space-y-2 text-gray-600">
                    <li><strong>Essential Cookies:</strong> Required for platform functionality and security</li>
                    <li><strong>Analytics Cookies:</strong> Help us understand how users interact with our platform</li>
                    <li><strong>Preference Cookies:</strong> Remember your settings and preferences</li>
                    <li><strong>Marketing Cookies:</strong> Used to deliver relevant advertisements (with consent)</li>
                  </ul>
                  <p className="text-gray-600">
                    You can control cookie settings through your browser preferences. Disabling certain cookies may affect platform functionality.
                  </p>
                </CardContent>
              </Card>

              {/* Children's Privacy */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c]">Children's Privacy</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 leading-relaxed">
                    Our platform is designed to help children, but we do not knowingly collect personal information from children under 13 without parental consent. If you are a parent or guardian and believe your child has provided us with personal information, please contact us immediately. We will take steps to remove such information from our systems.
                  </p>
                  <p className="text-gray-600 leading-relaxed mt-4">
                    For children seeking medical assistance through our platform, we work with parents, guardians, and healthcare providers to ensure appropriate consent and privacy protection.
                  </p>
                </CardContent>
              </Card>

              {/* International Transfers */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c]">International Data Transfers</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 leading-relaxed">
                    Your information may be transferred to and processed in countries other than your country of residence. We ensure that such transfers comply with applicable data protection laws and implement appropriate safeguards to protect your information.
                  </p>
                </CardContent>
              </Card>

              {/* Changes to Policy */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c]">Changes to This Privacy Policy</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 leading-relaxed">
                    We may update this Privacy Policy from time to time to reflect changes in our practices or legal requirements. We will notify you of any material changes by posting the updated policy on our website and updating the "Last updated" date. Your continued use of our platform after such changes constitutes acceptance of the updated policy.
                  </p>
                </CardContent>
              </Card>

              {/* Contact Information */}
              <Card className="border-0 shadow-lg bg-gradient-to-r from-[#101c2c]/5 to-[#d4af37]/5">
                <CardHeader>
                  <CardTitle className="text-2xl text-[#101c2c]">Contact Us</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-6">
                    If you have questions about this Privacy Policy or our data practices, please contact us:
                  </p>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-3">
                      <div className="flex items-center space-x-3">
                        <Mail className="w-5 h-5 text-[#d4af37]" />
                        <span className="text-gray-700">privacy@rehma.ai</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Phone className="w-5 h-5 text-[#d4af37]" />
                        <span className="text-gray-700">+92-42-1234-5678</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <MapPin className="w-5 h-5 text-[#d4af37]" />
                        <span className="text-gray-700">Lahore, Pakistan</span>
                      </div>
                    </div>
                    <div>
                      <Button className="bg-[#d4af37] hover:bg-[#b8941f] text-white">
                        Contact Privacy Team
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </div>
    </Layout>
  );
}
