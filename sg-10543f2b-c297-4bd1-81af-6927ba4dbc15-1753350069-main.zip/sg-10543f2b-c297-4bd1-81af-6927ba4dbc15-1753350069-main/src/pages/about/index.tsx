import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Heart, 
  Shield, 
  Users, 
  Globe, 
  TrendingUp, 
  Award,
  CheckCircle2,
  Download,
  Star,
  Target,
  Eye,
  Zap,
  Lock,
  BarChart3,
  FileText,
  Phone,
  Mail,
  MapPin
} from "lucide-react";
import Layout from "@/components/Layout";
import { useCurrency } from "@/contexts/CurrencyContext";
import { donationService } from "@/services/donationService";
import { childrenService } from "@/services/childrenService";
import { formatNumber } from "@/lib/number";
import Image from "next/image";
import { jsPDF } from "jspdf";

interface TransparencyMetric {
  label: string;
  value: string;
  percentage: number;
  icon: typeof Heart;
  color: string;
}

interface Review {
  id: string;
  name: string;
  role: string;
  avatar: string;
  rating: number;
  comment: string;
  date: string;
}

const mockReviews: Review[] = [
  {
    id: "1",
    name: "Sarah Ahmed",
    role: "Regular Donor",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
    rating: 5,
    comment: "Rehma has completely changed how I approach charitable giving. The transparency and real-time updates give me confidence that my donations are making a real difference. I've been able to track the progress of the children I've supported, and it's incredibly rewarding.",
    date: "2025-01-15"
  },
  {
    id: "2",
    name: "Dr. Muhammad Hassan",
    role: "Medical Partner",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
    rating: 5,
    comment: "As a medical professional working with Rehma, I'm impressed by their thorough verification process and commitment to quality care. They ensure every child receives proper medical attention and follow-up. The platform's efficiency allows us to focus on what matters most - healing children.",
    date: "2025-01-10"
  },
  {
    id: "3",
    name: "Fatima Khan",
    role: "NGO Partner",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
    rating: 5,
    comment: "Rehma's partnership approach is exceptional. They don't just connect donors with children - they build an entire ecosystem of support. The technology platform makes coordination seamless, and their team is always responsive and professional.",
    date: "2025-01-05"
  }
];

export default function AboutPage() {
  const { formatPrice } = useCurrency();
  const [stats, setStats] = useState({
    totalDonated: 0,
    childrenHelped: 0,
    activeDonors: 0,
    successRate: 0
  });
  const [transparencyMetrics, setTransparencyMetrics] = useState<TransparencyMetric[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [donationStats, childrenData] = await Promise.all([
          donationService.getDonationStats(),
          childrenService.getAllChildren(1, 100)
        ]);

        const totalDonated = donationStats.totalAmount;
        const childrenHelped = Math.floor(totalDonated / 5000);
        const activeDonors = donationStats.totalDonations;
        const successRate = 96.5;

        setStats({
          totalDonated,
          childrenHelped,
          activeDonors,
          successRate
        });

        setTransparencyMetrics([
          {
            label: "Funds to Children",
            value: "92%",
            percentage: 92,
            icon: Heart,
            color: "bg-red-500"
          },
          {
            label: "Administrative Costs",
            value: "5%",
            percentage: 5,
            icon: FileText,
            color: "bg-blue-500"
          },
          {
            label: "Platform Operations",
            value: "3%",
            percentage: 3,
            icon: Zap,
            color: "bg-yellow-500"
          }
        ]);
      } catch (error) {
        console.error("Failed to fetch about page data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleDownloadPDF = async () => {
    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();
      let yPosition = 20;

      // Helper function to add new page if needed
      const checkPageBreak = (requiredSpace: number) => {
        if (yPosition + requiredSpace > pageHeight - 20) {
          doc.addPage();
          yPosition = 20;
          return true;
        }
        return false;
      };

      // Header with Logo Placeholder and Title
      doc.setFillColor(16, 28, 44);
      doc.rect(0, 0, pageWidth, 40, "F");
      
      doc.setTextColor(212, 175, 55);
      doc.setFontSize(28);
      doc.setFont("helvetica", "bold");
      doc.text("REHMA", pageWidth / 2, 20, { align: "center" });
      
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(10);
      doc.text("Infinite Blessings Here & After", pageWidth / 2, 30, { align: "center" });

      yPosition = 50;

      // Organization Profile Title
      doc.setTextColor(16, 28, 44);
      doc.setFontSize(18);
      doc.setFont("helvetica", "bold");
      doc.text("ORGANIZATION PROFILE", pageWidth / 2, yPosition, { align: "center" });
      yPosition += 15;

      // Mission Section
      checkPageBreak(30);
      doc.setFillColor(212, 175, 55);
      doc.rect(10, yPosition - 5, pageWidth - 20, 8, "F");
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.text("MISSION", 15, yPosition);
      yPosition += 10;

      doc.setTextColor(60, 60, 60);
      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      const missionText = "To provide life-saving medical care and support to children with special needs through transparent, technology-driven charitable giving. We bridge the gap between those who want to help and those who need help most.";
      const missionLines = doc.splitTextToSize(missionText, pageWidth - 30);
      doc.text(missionLines, 15, yPosition);
      yPosition += missionLines.length * 5 + 10;

      // Vision Section
      checkPageBreak(30);
      doc.setFillColor(212, 175, 55);
      doc.rect(10, yPosition - 5, pageWidth - 20, 8, "F");
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.text("VISION", 15, yPosition);
      yPosition += 10;

      doc.setTextColor(60, 60, 60);
      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      const visionText = "A world where every child, regardless of their circumstances, has access to quality healthcare and the opportunity to thrive. We envision a global community united in compassion and action.";
      const visionLines = doc.splitTextToSize(visionText, pageWidth - 30);
      doc.text(visionLines, 15, yPosition);
      yPosition += visionLines.length * 5 + 10;

      // Impact Statistics
      checkPageBreak(50);
      doc.setFillColor(16, 28, 44);
      doc.rect(10, yPosition - 5, pageWidth - 20, 8, "F");
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.text("IMPACT STATISTICS", 15, yPosition);
      yPosition += 15;

      doc.setTextColor(16, 28, 44);
      doc.setFontSize(10);
      doc.setFont("helvetica", "bold");
      doc.text("Total Donations Raised:", 15, yPosition);
      doc.setFont("helvetica", "normal");
      doc.text(formatPrice(stats.totalDonated), 80, yPosition);
      yPosition += 8;

      doc.setFont("helvetica", "bold");
      doc.text("Children Helped:", 15, yPosition);
      doc.setFont("helvetica", "normal");
      doc.text(formatNumber(stats.childrenHelped).toString(), 80, yPosition);
      yPosition += 8;

      doc.setFont("helvetica", "bold");
      doc.text("Active Donors:", 15, yPosition);
      doc.setFont("helvetica", "normal");
      doc.text(formatNumber(stats.activeDonors).toString(), 80, yPosition);
      yPosition += 8;

      doc.setFont("helvetica", "bold");
      doc.text("Success Rate:", 15, yPosition);
      doc.setFont("helvetica", "normal");
      doc.text(`${stats.successRate}%`, 80, yPosition);
      yPosition += 15;

      // Financial Transparency
      checkPageBreak(60);
      doc.setFillColor(16, 28, 44);
      doc.rect(10, yPosition - 5, pageWidth - 20, 8, "F");
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.text("FINANCIAL TRANSPARENCY", 15, yPosition);
      yPosition += 15;

      doc.setTextColor(60, 60, 60);
      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.text("Where Your Money Goes (per donation):", 15, yPosition);
      yPosition += 8;

      // Transparency breakdown
      const allocations = [
        { label: "Direct Medical Care & Treatment", percentage: "75%" },
        { label: "Therapy & Rehabilitation", percentage: "12%" },
        { label: "Educational Support", percentage: "5%" },
        { label: "Administrative & Operations", percentage: "5%" },
        { label: "Platform Technology & Security", percentage: "3%" }
      ];

      allocations.forEach(item => {
        checkPageBreak(10);
        doc.setFont("helvetica", "bold");
        doc.text("•", 20, yPosition);
        doc.setFont("helvetica", "normal");
        doc.text(`${item.label}: ${item.percentage}`, 25, yPosition);
        yPosition += 6;
      });
      yPosition += 10;

      // Key Features
      checkPageBreak(60);
      doc.setFillColor(212, 175, 55);
      doc.rect(10, yPosition - 5, pageWidth - 20, 8, "F");
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.text("KEY FEATURES", 15, yPosition);
      yPosition += 15;

      const features = [
        "Real-time donation tracking and impact monitoring",
        "100% secure payment processing with bank-level encryption",
        "Verified child profiles reviewed by medical professionals",
        "Multi-currency support for global reach",
        "Comprehensive NGO and medical partner network",
        "GDPR compliant data privacy and protection",
        "Transparent fund allocation and reporting",
        "Mobile-responsive platform for easy access"
      ];

      doc.setTextColor(60, 60, 60);
      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      features.forEach(feature => {
        checkPageBreak(10);
        doc.text("•", 20, yPosition);
        const featureLines = doc.splitTextToSize(feature, pageWidth - 35);
        doc.text(featureLines, 25, yPosition);
        yPosition += featureLines.length * 5 + 3;
      });
      yPosition += 10;

      // Community Service
      checkPageBreak(60);
      doc.setFillColor(16, 28, 44);
      doc.rect(10, yPosition - 5, pageWidth - 20, 8, "F");
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.text("HOW WE SERVE THE COMMUNITY", 15, yPosition);
      yPosition += 15;

      const services = [
        {
          title: "Direct Medical Support",
          desc: "Immediate financial assistance for medical treatments, surgeries, and ongoing care"
        },
        {
          title: "Family Support Services",
          desc: "Counseling, educational resources, and community building for caregivers"
        },
        {
          title: "NGO & Medical Partnerships",
          desc: "Collaborative care coordination with verified partners"
        },
        {
          title: "Education & Awareness",
          desc: "Public campaigns, workshops, and advocacy for policy changes"
        }
      ];

      doc.setTextColor(60, 60, 60);
      doc.setFontSize(10);
      services.forEach(service => {
        checkPageBreak(15);
        doc.setFont("helvetica", "bold");
        doc.text(`• ${service.title}`, 20, yPosition);
        yPosition += 6;
        doc.setFont("helvetica", "normal");
        const descLines = doc.splitTextToSize(service.desc, pageWidth - 35);
        doc.text(descLines, 25, yPosition);
        yPosition += descLines.length * 5 + 5;
      });
      yPosition += 10;

      // Contact Information
      checkPageBreak(40);
      doc.setFillColor(212, 175, 55);
      doc.rect(10, yPosition - 5, pageWidth - 20, 8, "F");
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.text("CONTACT INFORMATION", 15, yPosition);
      yPosition += 15;

      doc.setTextColor(60, 60, 60);
      doc.setFontSize(10);
      doc.setFont("helvetica", "bold");
      doc.text("Email:", 15, yPosition);
      doc.setFont("helvetica", "normal");
      doc.text("info@rehma.ai", 40, yPosition);
      yPosition += 8;

      doc.setFont("helvetica", "bold");
      doc.text("Phone:", 15, yPosition);
      doc.setFont("helvetica", "normal");
      doc.text("+1 (555) 123-4567", 40, yPosition);
      yPosition += 8;

      doc.setFont("helvetica", "bold");
      doc.text("Location:", 15, yPosition);
      doc.setFont("helvetica", "normal");
      doc.text("Global Operations", 40, yPosition);
      yPosition += 8;

      doc.setFont("helvetica", "bold");
      doc.text("Website:", 15, yPosition);
      doc.setFont("helvetica", "normal");
      doc.text("https://rehma.ai", 40, yPosition);
      yPosition += 15;

      // Footer
      const footerY = pageHeight - 15;
      doc.setFillColor(16, 28, 44);
      doc.rect(0, footerY - 5, pageWidth, 20, "F");
      doc.setTextColor(212, 175, 55);
      doc.setFontSize(8);
      doc.setFont("helvetica", "italic");
      doc.text(`Generated on ${new Date().toLocaleDateString()} | © ${new Date().getFullYear()} Rehma. All rights reserved.`, pageWidth / 2, footerY, { align: "center" });

      // Save PDF
      doc.save("Rehma-Organization-Profile.pdf");
    } catch (error) {
      console.error("Error generating PDF:", error);
      alert("Failed to generate PDF. Please try again.");
    }
  };

  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-[#d4af37]/5">
        
        {/* Hero Section */}
        <section className="relative py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-[#101c2c] via-[#1e293b] to-[#334155] overflow-hidden">
          <div className="absolute inset-0 bg-black/20"></div>
          <div className="relative max-w-7xl mx-auto text-center">
            <Badge className="mb-6 bg-[#d4af37]/20 text-[#d4af37] hover:bg-[#d4af37]/30 border-[#d4af37]/30 text-sm px-4 py-2">
              ✨ About Rehma
            </Badge>
            
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
              Transforming Lives Through
              <span className="block bg-gradient-to-r from-[#d4af37] to-[#b8941f] bg-clip-text text-transparent">
                Compassion & Technology
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-4xl mx-auto leading-relaxed">
              Rehma combines cutting-edge technology with heartfelt compassion to create a transparent, 
              efficient platform that connects generous donors with children in need of medical care.
            </p>

            <Button 
              size="lg"
              onClick={handleDownloadPDF}
              className="bg-[#d4af37] text-white hover:bg-[#b8941f] px-8 py-4 text-lg font-semibold rounded-full shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300"
            >
              <Download className="w-5 h-5 mr-2" />
              Download Rehma Profile (PDF)
            </Button>
          </div>
        </section>

        {/* Mission, Vision & Values */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-7xl mx-auto">
            <div className="grid md:grid-cols-3 gap-8">
              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <CardHeader>
                  <Target className="w-12 h-12 text-[#d4af37] mb-4" />
                  <CardTitle className="text-2xl">Our Mission</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 leading-relaxed">
                    To provide life-saving medical care and support to children with special needs through 
                    transparent, technology-driven charitable giving. We bridge the gap between those who want 
                    to help and those who need help most.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <CardHeader>
                  <Eye className="w-12 h-12 text-[#101c2c] mb-4" />
                  <CardTitle className="text-2xl">Our Vision</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 leading-relaxed">
                    A world where every child, regardless of their circumstances, has access to quality healthcare 
                    and the opportunity to thrive. We envision a global community united in compassion and action.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <CardHeader>
                  <Heart className="w-12 h-12 text-red-500 mb-4" />
                  <CardTitle className="text-2xl">Our Values</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-gray-600">
                    <li className="flex items-start">
                      <CheckCircle2 className="w-5 h-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Transparency in every transaction</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="w-5 h-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Compassion in every interaction</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="w-5 h-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Excellence in service delivery</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Impact Statistics */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-[#101c2c] to-[#d4af37]">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Our Impact in Numbers
              </h2>
              <p className="text-xl text-gray-200 max-w-3xl mx-auto">
                Real results, real change, real transparency
              </p>
            </div>

            <div className="grid md:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mx-auto mb-4">
                  <Heart className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-4xl font-bold text-white mb-2">
                  {loading ? "..." : formatPrice(stats.totalDonated)}
                </h3>
                <p className="text-gray-200">Total Raised</p>
              </div>

              <div className="text-center">
                <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-4xl font-bold text-white mb-2">
                  {loading ? "..." : formatNumber(stats.childrenHelped)}
                </h3>
                <p className="text-gray-200">Children Helped</p>
              </div>

              <div className="text-center">
                <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mx-auto mb-4">
                  <Globe className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-4xl font-bold text-white mb-2">
                  {loading ? "..." : formatNumber(stats.activeDonors)}
                </h3>
                <p className="text-gray-200">Active Donors</p>
              </div>

              <div className="text-center">
                <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-4xl font-bold text-white mb-2">
                  {stats.successRate}%
                </h3>
                <p className="text-gray-200">Success Rate</p>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <Badge className="mb-4 bg-[#d4af37]/20 text-[#d4af37] hover:bg-[#d4af37]/30">
                🚀 Platform Features
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                What Makes Rehma Different
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Advanced technology meets humanitarian values
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                <CardContent className="pt-6">
                  <Shield className="w-12 h-12 text-[#101c2c] mb-4" />
                  <h3 className="text-xl font-bold text-gray-900 mb-2">100% Secure</h3>
                  <p className="text-gray-600">
                    Bank-level encryption and secure payment processing ensure your donations are protected at every step.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                <CardContent className="pt-6">
                  <BarChart3 className="w-12 h-12 text-[#d4af37] mb-4" />
                  <h3 className="text-xl font-bold text-gray-900 mb-2">Real-Time Tracking</h3>
                  <p className="text-gray-600">
                    Monitor your donation impact in real-time with detailed analytics and progress updates.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                <CardContent className="pt-6">
                  <CheckCircle2 className="w-12 h-12 text-green-500 mb-4" />
                  <h3 className="text-xl font-bold text-gray-900 mb-2">Verified Profiles</h3>
                  <p className="text-gray-600">
                    Every child profile is thoroughly verified by medical professionals and our team.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                <CardContent className="pt-6">
                  <Globe className="w-12 h-12 text-blue-500 mb-4" />
                  <h3 className="text-xl font-bold text-gray-900 mb-2">Global Reach</h3>
                  <p className="text-gray-600">
                    Connect with children in need across multiple countries with multi-currency support.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                <CardContent className="pt-6">
                  <Users className="w-12 h-12 text-purple-500 mb-4" />
                  <h3 className="text-xl font-bold text-gray-900 mb-2">NGO Network</h3>
                  <p className="text-gray-600">
                    Partner with verified NGOs and medical professionals for comprehensive care.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                <CardContent className="pt-6">
                  <Lock className="w-12 h-12 text-red-500 mb-4" />
                  <h3 className="text-xl font-bold text-gray-900 mb-2">Data Privacy</h3>
                  <p className="text-gray-600">
                    GDPR compliant with strict data protection policies to safeguard all user information.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Transparency Dashboard */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-50 to-[#d4af37]/10">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <Badge className="mb-4 bg-[#101c2c]/20 text-[#101c2c] hover:bg-[#101c2c]/30">
                📊 Complete Transparency
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Where Your Money Goes
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                We believe in complete financial transparency. Here's exactly how every donation is allocated.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8 mb-12">
              {transparencyMetrics.map((metric, index) => (
                <Card key={index} className="border-0 shadow-lg">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between mb-4">
                      <metric.icon className="w-10 h-10 text-gray-700" />
                      <span className="text-3xl font-bold text-gray-900">{metric.value}</span>
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-3">{metric.label}</h3>
                    <Progress value={metric.percentage} className="h-3 mb-2" />
                    <p className="text-sm text-gray-600">
                      {metric.percentage}% of every donation
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card className="border-0 shadow-xl bg-gradient-to-br from-white to-gray-50">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
                  Detailed Fund Allocation
                </h3>
                <div className="space-y-6">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="font-medium text-gray-700">Direct Medical Care & Treatment</span>
                      <span className="font-bold text-[#d4af37]">75%</span>
                    </div>
                    <Progress value={75} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="font-medium text-gray-700">Therapy & Rehabilitation</span>
                      <span className="font-bold text-[#d4af37]">12%</span>
                    </div>
                    <Progress value={12} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="font-medium text-gray-700">Educational Support</span>
                      <span className="font-bold text-[#d4af37]">5%</span>
                    </div>
                    <Progress value={5} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="font-medium text-gray-700">Administrative & Operations</span>
                      <span className="font-bold text-blue-500">5%</span>
                    </div>
                    <Progress value={5} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="font-medium text-gray-700">Platform Technology & Security</span>
                      <span className="font-bold text-blue-500">3%</span>
                    </div>
                    <Progress value={3} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Reviews & Testimonials */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <Badge className="mb-4 bg-[#d4af37]/20 text-[#d4af37] hover:bg-[#d4af37]/30">
                ⭐ Testimonials
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                What People Say About Rehma
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Real stories from donors, partners, and families we've helped
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {mockReviews.map((review) => (
                <Card key={review.id} className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                  <CardContent className="pt-6">
                    <div className="flex items-center mb-4">
                      <Image
                        src={review.avatar}
                        alt={review.name}
                        width={48}
                        height={48}
                        className="rounded-full mr-4"
                      />
                      <div>
                        <h4 className="font-semibold text-gray-900">{review.name}</h4>
                        <p className="text-sm text-gray-600">{review.role}</p>
                      </div>
                    </div>
                    <div className="flex mb-3">
                      {[...Array(review.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                    <p className="text-gray-700 leading-relaxed mb-3">
                      {review.comment}
                    </p>
                    <p className="text-xs text-gray-500">{new Date(review.date).toLocaleDateString()}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* How We Serve the Community */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-50 to-[#d4af37]/10">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <Badge className="mb-4 bg-[#101c2c]/20 text-[#101c2c] hover:bg-[#101c2c]/30">
                🤝 Community Service
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                How We Serve the Community
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Our multi-faceted approach to creating lasting impact
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <Card className="border-0 shadow-lg">
                <CardContent className="pt-6">
                  <Heart className="w-12 h-12 text-red-500 mb-4" />
                  <h3 className="text-xl font-bold text-gray-900 mb-3">Direct Medical Support</h3>
                  <p className="text-gray-600 mb-4">
                    We provide immediate financial assistance for medical treatments, surgeries, and ongoing care for children with special needs.
                  </p>
                  <ul className="space-y-2 text-gray-600">
                    <li className="flex items-start">
                      <CheckCircle2 className="w-5 h-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Emergency medical interventions</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="w-5 h-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Scheduled surgeries and procedures</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="w-5 h-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Long-term treatment plans</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg">
                <CardContent className="pt-6">
                  <Users className="w-12 h-12 text-[#d4af37] mb-4" />
                  <h3 className="text-xl font-bold text-gray-900 mb-3">Family Support Services</h3>
                  <p className="text-gray-600 mb-4">
                    Beyond medical care, we support families with resources, guidance, and emotional support throughout their journey.
                  </p>
                  <ul className="space-y-2 text-gray-600">
                    <li className="flex items-start">
                      <CheckCircle2 className="w-5 h-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Counseling and mental health support</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="w-5 h-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Educational resources for caregivers</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="w-5 h-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Community building and peer support</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg">
                <CardContent className="pt-6">
                  <Globe className="w-12 h-12 text-blue-500 mb-4" />
                  <h3 className="text-xl font-bold text-gray-900 mb-3">NGO & Medical Partnerships</h3>
                  <p className="text-gray-600 mb-4">
                    We collaborate with verified NGOs and medical professionals to ensure comprehensive, quality care delivery.
                  </p>
                  <ul className="space-y-2 text-gray-600">
                    <li className="flex items-start">
                      <CheckCircle2 className="w-5 h-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Network of verified medical partners</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="w-5 h-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Collaborative care coordination</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="w-5 h-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Shared resources and expertise</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg">
                <CardContent className="pt-6">
                  <Award className="w-12 h-12 text-[#101c2c] mb-4" />
                  <h3 className="text-xl font-bold text-gray-900 mb-3">Education & Awareness</h3>
                  <p className="text-gray-600 mb-4">
                    We raise awareness about special needs children and promote inclusive practices in communities.
                  </p>
                  <ul className="space-y-2 text-gray-600">
                    <li className="flex items-start">
                      <CheckCircle2 className="w-5 h-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Public awareness campaigns</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="w-5 h-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Educational workshops and seminars</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="w-5 h-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Advocacy for policy changes</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Contact Information */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-4 bg-[#d4af37]/20 text-[#d4af37] hover:bg-[#d4af37]/30">
              📞 Get in Touch
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Contact Rehma
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              Have questions? We're here to help you make a difference.
            </p>

            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 bg-[#d4af37]/10 rounded-full flex items-center justify-center mb-4">
                  <Mail className="w-8 h-8 text-[#d4af37]" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Email Us</h3>
                <p className="text-gray-600">info@rehma.ai</p>
              </div>

              <div className="flex flex-col items-center">
                <div className="w-16 h-16 bg-[#101c2c]/10 rounded-full flex items-center justify-center mb-4">
                  <Phone className="w-8 h-8 text-[#101c2c]" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Call Us</h3>
                <p className="text-gray-600">+1 (555) 123-4567</p>
              </div>

              <div className="flex flex-col items-center">
                <div className="w-16 h-16 bg-blue-500/10 rounded-full flex items-center justify-center mb-4">
                  <MapPin className="w-8 h-8 text-blue-500" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Visit Us</h3>
                <p className="text-gray-600">Global Operations</p>
              </div>
            </div>

            <Button 
              size="lg"
              onClick={handleDownloadPDF}
              className="bg-gradient-to-r from-[#101c2c] to-[#d4af37] hover:from-[#1e293b] hover:to-[#b8941f] text-white px-8 py-4 text-lg font-semibold rounded-full shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300"
            >
              <Download className="w-5 h-5 mr-2" />
              Download Complete Organization Profile
            </Button>
          </div>
        </section>
      </div>
    </Layout>
  );
}