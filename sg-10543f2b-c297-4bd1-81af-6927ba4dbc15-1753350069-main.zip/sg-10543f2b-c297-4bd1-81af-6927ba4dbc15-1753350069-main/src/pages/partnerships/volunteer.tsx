import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Users, Heart, Clock, Award, Globe, Lightbulb, Mail, Phone } from "lucide-react";
import { useState } from "react";
import Layout from "@/components/Layout";

interface VolunteerForm {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  location: string;
  age: string;
  profession: string;
  experience: string;
  availability: string;
  skills: string[];
  interests: string[];
  motivation: string;
  previousVolunteering: string;
}

const volunteerOpportunities = [
  {
    icon: Heart,
    title: "Direct Child Support",
    description: "Work directly with children and families, providing emotional support and companionship",
    timeCommitment: "4-8 hours/week"
  },
  {
    icon: Globe,
    title: "Online Advocacy",
    description: "Help spread awareness through social media, content creation, and digital campaigns",
    timeCommitment: "2-5 hours/week"
  },
  {
    icon: Users,
    title: "Community Outreach",
    description: "Organize local events, fundraisers, and awareness campaigns in your community",
    timeCommitment: "5-10 hours/week"
  },
  {
    icon: Lightbulb,
    title: "Professional Skills",
    description: "Use your professional expertise in areas like healthcare, education, or technology",
    timeCommitment: "3-6 hours/week"
  },
  {
    icon: Award,
    title: "Event Management",
    description: "Help organize and manage fundraising events, workshops, and awareness programs",
    timeCommitment: "Variable"
  },
  {
    icon: Clock,
    title: "Administrative Support",
    description: "Assist with data entry, research, documentation, and other administrative tasks",
    timeCommitment: "2-4 hours/week"
  }
];

const skillOptions = [
  "Healthcare/Medical",
  "Education/Teaching",
  "Social Work",
  "Psychology/Counseling",
  "Marketing/Communications",
  "Graphic Design",
  "Web Development",
  "Photography/Videography",
  "Event Planning",
  "Fundraising",
  "Translation",
  "Writing/Content Creation",
  "Accounting/Finance",
  "Legal Services",
  "Other"
];

const interestAreas = [
  "Direct Child Care",
  "Family Support",
  "Medical Assistance",
  "Educational Programs",
  "Fundraising Events",
  "Social Media Advocacy",
  "Community Outreach",
  "Administrative Support",
  "Research & Documentation",
  "Volunteer Coordination"
];

const availabilityOptions = [
  "Weekdays (Morning)",
  "Weekdays (Afternoon)",
  "Weekdays (Evening)",
  "Weekends (Morning)",
  "Weekends (Afternoon)",
  "Weekends (Evening)",
  "Flexible/As Needed"
];

export default function VolunteerPage() {
  const [formData, setFormData] = useState<VolunteerForm>({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    location: "",
    age: "",
    profession: "",
    experience: "",
    availability: "",
    skills: [],
    interests: [],
    motivation: "",
    previousVolunteering: ""
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (field: keyof VolunteerForm, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleArrayChange = (field: 'skills' | 'interests', value: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: checked 
        ? [...prev[field], value]
        : prev[field].filter(item => item !== value)
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    setTimeout(() => {
      alert("Thank you for your volunteer application! Our team will review your submission and contact you within 5-7 business days to discuss next steps.");
      setFormData({
        firstName: "",
        lastName: "",
        email: "",
        phone: "",
        location: "",
        age: "",
        profession: "",
        experience: "",
        availability: "",
        skills: [],
        interests: [],
        motivation: "",
        previousVolunteering: ""
      });
      setIsSubmitting(false);
    }, 2000);
  };

  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-gray-50">
        {/* Hero Section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-[#101c2c] to-[#1a2b3d]">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-6 bg-[#d4af37]/20 text-[#d4af37] hover:bg-[#d4af37]/30 border-[#d4af37]/30">
              🙋‍♀️ Join Our Team
            </Badge>
            
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Volunteer with Us
            </h1>
            
            <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
              Make a meaningful difference in the lives of children and families. Join our community of dedicated volunteers and help us create lasting positive impact.
            </p>

            <div className="bg-[#d4af37]/10 backdrop-blur-sm rounded-lg p-6 border border-[#d4af37]/20">
              <p className="text-white text-lg">
                <strong>Transparency Notice:</strong> From every donation processed through our platform, 10% goes to Rehma Portal to cover daily operations and platform maintenance. This ensures we can continue providing volunteer coordination and support services.
              </p>
            </div>
          </div>
        </section>

        {/* Volunteer Opportunities */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-[#101c2c] mb-4">Volunteer Opportunities</h2>
              <p className="text-xl text-gray-600">Find the perfect way to contribute your time and skills</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {volunteerOpportunities.map((opportunity, index) => (
                <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group">
                  <CardContent className="p-6">
                    <div className="w-16 h-16 bg-[#d4af37]/20 rounded-full flex items-center justify-center mb-4 group-hover:bg-[#d4af37]/30 transition-colors">
                      <opportunity.icon className="w-8 h-8 text-[#d4af37]" />
                    </div>
                    <h3 className="text-xl font-bold text-[#101c2c] mb-3">{opportunity.title}</h3>
                    <p className="text-gray-600 mb-4">{opportunity.description}</p>
                    <Badge variant="outline" className="border-[#d4af37]/30 text-[#d4af37]">
                      {opportunity.timeCommitment}
                    </Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Why Volunteer */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-50 to-[#d4af37]/10">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-[#101c2c] mb-8">Why Volunteer with Rehma?</h2>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div className="text-left">
                <h3 className="text-xl font-bold text-[#101c2c] mb-4">Make Real Impact</h3>
                <ul className="space-y-3 text-gray-600">
                  <li className="flex items-start space-x-3">
                    <Heart className="w-5 h-5 text-[#d4af37] mt-0.5 flex-shrink-0" />
                    <span>Directly help children receive life-saving medical care</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <Users className="w-5 h-5 text-[#d4af37] mt-0.5 flex-shrink-0" />
                    <span>Support families during their most challenging times</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <Globe className="w-5 h-5 text-[#d4af37] mt-0.5 flex-shrink-0" />
                    <span>Be part of a global movement for children's welfare</span>
                  </li>
                </ul>
              </div>
              
              <div className="text-left">
                <h3 className="text-xl font-bold text-[#101c2c] mb-4">Personal Growth</h3>
                <ul className="space-y-3 text-gray-600">
                  <li className="flex items-start space-x-3">
                    <Award className="w-5 h-5 text-[#d4af37] mt-0.5 flex-shrink-0" />
                    <span>Develop new skills and gain valuable experience</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <Lightbulb className="w-5 h-5 text-[#d4af37] mt-0.5 flex-shrink-0" />
                    <span>Connect with like-minded individuals and professionals</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <Clock className="w-5 h-5 text-[#d4af37] mt-0.5 flex-shrink-0" />
                    <span>Flexible scheduling that fits your lifestyle</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Volunteer Application Form */}
        <section className="py-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <Card className="border-0 shadow-lg">
              <CardHeader className="text-center">
                <CardTitle className="text-3xl text-[#101c2c] mb-4">Volunteer Application</CardTitle>
                <p className="text-gray-600">Tell us about yourself and how you'd like to help</p>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">First Name *</label>
                      <Input
                        required
                        value={formData.firstName}
                        onChange={(e) => handleInputChange("firstName", e.target.value)}
                        placeholder="Your first name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Last Name *</label>
                      <Input
                        required
                        value={formData.lastName}
                        onChange={(e) => handleInputChange("lastName", e.target.value)}
                        placeholder="Your last name"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Email Address *</label>
                      <Input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => handleInputChange("email", e.target.value)}
                        placeholder="your.email@example.com"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Phone Number *</label>
                      <Input
                        required
                        value={formData.phone}
                        onChange={(e) => handleInputChange("phone", e.target.value)}
                        placeholder="+92-300-1234567"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-3 gap-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Location *</label>
                      <Input
                        required
                        value={formData.location}
                        onChange={(e) => handleInputChange("location", e.target.value)}
                        placeholder="City, Country"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Age Range *</label>
                      <Select value={formData.age} onValueChange={(value) => handleInputChange("age", value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select age range" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="18-25">18-25</SelectItem>
                          <SelectItem value="26-35">26-35</SelectItem>
                          <SelectItem value="36-45">36-45</SelectItem>
                          <SelectItem value="46-55">46-55</SelectItem>
                          <SelectItem value="56+">56+</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Profession *</label>
                      <Input
                        required
                        value={formData.profession}
                        onChange={(e) => handleInputChange("profession", e.target.value)}
                        placeholder="Your profession"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Availability *</label>
                    <Select value={formData.availability} onValueChange={(value) => handleInputChange("availability", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="When are you available?" />
                      </SelectTrigger>
                      <SelectContent>
                        {availabilityOptions.map((option) => (
                          <SelectItem key={option} value={option}>
                            {option}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-4">Skills & Expertise (Select all that apply)</label>
                    <div className="grid md:grid-cols-3 gap-3">
                      {skillOptions.map((skill) => (
                        <div key={skill} className="flex items-center space-x-2">
                          <Checkbox
                            id={skill}
                            checked={formData.skills.includes(skill)}
                            onCheckedChange={(checked) => handleArrayChange('skills', skill, checked as boolean)}
                          />
                          <label htmlFor={skill} className="text-sm text-gray-700">{skill}</label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-4">Areas of Interest (Select all that apply)</label>
                    <div className="grid md:grid-cols-2 gap-3">
                      {interestAreas.map((interest) => (
                        <div key={interest} className="flex items-center space-x-2">
                          <Checkbox
                            id={interest}
                            checked={formData.interests.includes(interest)}
                            onCheckedChange={(checked) => handleArrayChange('interests', interest, checked as boolean)}
                          />
                          <label htmlFor={interest} className="text-sm text-gray-700">{interest}</label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Why do you want to volunteer with Rehma? *</label>
                    <Textarea
                      required
                      value={formData.motivation}
                      onChange={(e) => handleInputChange("motivation", e.target.value)}
                      placeholder="Tell us about your motivation to volunteer and what you hope to achieve..."
                      className="min-h-[120px]"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Previous Volunteering Experience</label>
                    <Textarea
                      value={formData.previousVolunteering}
                      onChange={(e) => handleInputChange("previousVolunteering", e.target.value)}
                      placeholder="Describe any previous volunteering experience, especially with children, healthcare, or charitable organizations..."
                      className="min-h-[100px]"
                    />
                  </div>

                  <Button 
                    type="submit" 
                    disabled={isSubmitting}
                    className="w-full bg-[#d4af37] hover:bg-[#b8941f] text-white py-3 text-lg"
                  >
                    {isSubmitting ? (
                      "Submitting Application..."
                    ) : (
                      <>
                        <Users className="w-5 h-5 mr-2" />
                        Submit Volunteer Application
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-[#101c2c] to-[#1a2b3d]">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-white mb-6">
              Ready to Start Your Volunteer Journey?
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              Have questions about volunteering? Our volunteer coordinator is here to help
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-[#d4af37] hover:bg-[#b8941f] text-white font-semibold px-8 py-3">
                <Mail className="w-5 h-5 mr-2" />
                volunteers@rehma.ai
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#101c2c] font-semibold px-8 py-3">
                <Phone className="w-5 h-5 mr-2" />
                +92-300-1234567
              </Button>
            </div>
          </div>
        </section>
      </div>
    </Layout>
  );
}
