import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Building, Heart, Award, TrendingUp, Users, Globe, Target, Mail, Phone, Calendar } from "lucide-react";
import { useState } from "react";
import Layout from "@/components/Layout";

interface CorporateForm {
  companyName: string;
  contactPerson: string;
  jobTitle: string;
  email: string;
  phone: string;
  website: string;
  companySize: string;
  industry: string;
  location: string;
  sponsorshipType: string;
  budget: string;
  objectives: string;
  timeline: string;
  previousCSR: string;
  additionalInfo: string;
}

const sponsorshipBenefits = [
  {
    icon: Heart,
    title: "Social Impact",
    description: "Make a meaningful difference in children's lives while demonstrating your company's commitment to social responsibility"
  },
  {
    icon: Award,
    title: "Brand Recognition",
    description: "Gain positive brand exposure through our platform, events, and marketing materials reaching thousands of supporters"
  },
  {
    icon: TrendingUp,
    title: "Employee Engagement",
    description: "Boost employee morale and engagement through meaningful corporate social responsibility initiatives"
  },
  {
    icon: Users,
    title: "Community Connection",
    description: "Strengthen your connection with local and global communities while building customer loyalty"
  },
  {
    icon: Globe,
    title: "Global Reach",
    description: "Extend your impact globally through our international network of partners and beneficiaries"
  },
  {
    icon: Target,
    title: "Measurable Impact",
    description: "Receive detailed reports and updates showing the direct impact of your corporate sponsorship"
  }
];

const sponsorshipTypes = [
  "Event Sponsorship",
  "Child Sponsorship Program",
  "Medical Equipment Donation",
  "Platform Development Support",
  "Marketing & Awareness Campaign",
  "Employee Volunteer Program",
  "Annual Partnership",
  "Custom Partnership"
];

const companySizes = [
  "Startup (1-10 employees)",
  "Small Business (11-50 employees)",
  "Medium Business (51-200 employees)",
  "Large Business (201-1000 employees)",
  "Enterprise (1000+ employees)"
];

const budgetRanges = [
  "$1,000 - $5,000",
  "$5,000 - $10,000",
  "$10,000 - $25,000",
  "$25,000 - $50,000",
  "$50,000 - $100,000",
  "$100,000+",
  "Prefer to discuss"
];

const industries = [
  "Technology",
  "Healthcare",
  "Finance",
  "Education",
  "Manufacturing",
  "Retail",
  "Consulting",
  "Real Estate",
  "Media & Entertainment",
  "Non-Profit",
  "Government",
  "Other"
];

export default function CorporateSponsorshipPage() {
  const [formData, setFormData] = useState<CorporateForm>({
    companyName: "",
    contactPerson: "",
    jobTitle: "",
    email: "",
    phone: "",
    website: "",
    companySize: "",
    industry: "",
    location: "",
    sponsorshipType: "",
    budget: "",
    objectives: "",
    timeline: "",
    previousCSR: "",
    additionalInfo: ""
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (field: keyof CorporateForm, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    setTimeout(() => {
      alert("Thank you for your interest in corporate sponsorship! Our partnerships team will review your proposal and contact you within 2-3 business days to discuss opportunities.");
      setFormData({
        companyName: "",
        contactPerson: "",
        jobTitle: "",
        email: "",
        phone: "",
        website: "",
        companySize: "",
        industry: "",
        location: "",
        sponsorshipType: "",
        budget: "",
        objectives: "",
        timeline: "",
        previousCSR: "",
        additionalInfo: ""
      });
      setIsSubmitting(false);
    }, 2000);
  };

  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-gray-50">
        {/* Hero Section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-[#101c2c] to-[#1a2b3d]">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-6 bg-[#d4af37]/20 text-[#d4af37] hover:bg-[#d4af37]/30 border-[#d4af37]/30">
              🏢 Corporate Partnership
            </Badge>
            
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Corporate Sponsorship
            </h1>
            
            <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
              Partner with Rehma to create meaningful social impact while achieving your corporate social responsibility goals. Together, we can transform lives and build stronger communities.
            </p>

            <div className="bg-[#d4af37]/10 backdrop-blur-sm rounded-lg p-6 border border-[#d4af37]/20">
              <p className="text-white text-lg">
                <strong>Transparency Notice:</strong> From every donation processed through our platform, 10% goes to Rehma Portal to cover daily operations and platform maintenance. This ensures sustainable operations and transparent reporting for all corporate partners.
              </p>
            </div>
          </div>
        </section>

        {/* Sponsorship Benefits */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-[#101c2c] mb-4">Why Partner with Rehma?</h2>
              <p className="text-xl text-gray-600">Benefits of corporate sponsorship with our platform</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {sponsorshipBenefits.map((benefit, index) => (
                <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group">
                  <CardContent className="p-6 text-center">
                    <div className="w-16 h-16 bg-[#d4af37]/20 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#d4af37]/30 transition-colors">
                      <benefit.icon className="w-8 h-8 text-[#d4af37]" />
                    </div>
                    <h3 className="text-xl font-bold text-[#101c2c] mb-3">{benefit.title}</h3>
                    <p className="text-gray-600">{benefit.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Sponsorship Packages */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-50 to-[#d4af37]/10">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-[#101c2c] mb-4">Sponsorship Packages</h2>
              <p className="text-xl text-gray-600">Flexible partnership options to match your goals and budget</p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader className="text-center">
                  <Badge className="mx-auto mb-4 bg-[#d4af37]/20 text-[#d4af37]">Bronze Partner</Badge>
                  <CardTitle className="text-2xl text-[#101c2c]">$5,000 - $15,000</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ul className="space-y-3 text-gray-600">
                    <li className="flex items-center space-x-2">
                      <Heart className="w-4 h-4 text-[#d4af37]" />
                      <span>Logo on website and materials</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <Heart className="w-4 h-4 text-[#d4af37]" />
                      <span>Quarterly impact reports</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <Heart className="w-4 h-4 text-[#d4af37]" />
                      <span>Social media recognition</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <Heart className="w-4 h-4 text-[#d4af37]" />
                      <span>Certificate of partnership</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow border-2 border-[#d4af37]">
                <CardHeader className="text-center">
                  <Badge className="mx-auto mb-4 bg-[#d4af37] text-white">Silver Partner</Badge>
                  <CardTitle className="text-2xl text-[#101c2c]">$15,000 - $50,000</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ul className="space-y-3 text-gray-600">
                    <li className="flex items-center space-x-2">
                      <Heart className="w-4 h-4 text-[#d4af37]" />
                      <span>All Bronze benefits</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <Heart className="w-4 h-4 text-[#d4af37]" />
                      <span>Featured partner spotlight</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <Heart className="w-4 h-4 text-[#d4af37]" />
                      <span>Employee volunteer opportunities</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <Heart className="w-4 h-4 text-[#d4af37]" />
                      <span>Custom impact dashboard</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <Heart className="w-4 h-4 text-[#d4af37]" />
                      <span>Event co-branding opportunities</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader className="text-center">
                  <Badge className="mx-auto mb-4 bg-[#101c2c] text-white">Gold Partner</Badge>
                  <CardTitle className="text-2xl text-[#101c2c]">$50,000+</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ul className="space-y-3 text-gray-600">
                    <li className="flex items-center space-x-2">
                      <Heart className="w-4 h-4 text-[#d4af37]" />
                      <span>All Silver benefits</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <Heart className="w-4 h-4 text-[#d4af37]" />
                      <span>Dedicated account manager</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <Heart className="w-4 h-4 text-[#d4af37]" />
                      <span>Custom partnership programs</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <Heart className="w-4 h-4 text-[#d4af37]" />
                      <span>Executive briefings</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <Heart className="w-4 h-4 text-[#d4af37]" />
                      <span>Naming rights opportunities</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Corporate Partnership Form */}
        <section className="py-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <Card className="border-0 shadow-lg">
              <CardHeader className="text-center">
                <CardTitle className="text-3xl text-[#101c2c] mb-4">Partnership Inquiry</CardTitle>
                <p className="text-gray-600">Tell us about your company and partnership goals</p>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Company Name *</label>
                      <Input
                        required
                        value={formData.companyName}
                        onChange={(e) => handleInputChange("companyName", e.target.value)}
                        placeholder="Your company name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Contact Person *</label>
                      <Input
                        required
                        value={formData.contactPerson}
                        onChange={(e) => handleInputChange("contactPerson", e.target.value)}
                        placeholder="Primary contact person"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Job Title *</label>
                      <Input
                        required
                        value={formData.jobTitle}
                        onChange={(e) => handleInputChange("jobTitle", e.target.value)}
                        placeholder="Your job title"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Email Address *</label>
                      <Input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => handleInputChange("email", e.target.value)}
                        placeholder="contact@company.com"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Phone Number *</label>
                      <Input
                        required
                        value={formData.phone}
                        onChange={(e) => handleInputChange("phone", e.target.value)}
                        placeholder="+1-555-123-4567"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Company Website</label>
                      <Input
                        value={formData.website}
                        onChange={(e) => handleInputChange("website", e.target.value)}
                        placeholder="https://company.com"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-3 gap-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Company Size *</label>
                      <Select value={formData.companySize} onValueChange={(value) => handleInputChange("companySize", value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select company size" />
                        </SelectTrigger>
                        <SelectContent>
                          {companySizes.map((size) => (
                            <SelectItem key={size} value={size}>
                              {size}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Industry *</label>
                      <Select value={formData.industry} onValueChange={(value) => handleInputChange("industry", value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select industry" />
                        </SelectTrigger>
                        <SelectContent>
                          {industries.map((industry) => (
                            <SelectItem key={industry} value={industry}>
                              {industry}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Location *</label>
                      <Input
                        required
                        value={formData.location}
                        onChange={(e) => handleInputChange("location", e.target.value)}
                        placeholder="City, Country"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Sponsorship Type *</label>
                      <Select value={formData.sponsorshipType} onValueChange={(value) => handleInputChange("sponsorshipType", value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select sponsorship type" />
                        </SelectTrigger>
                        <SelectContent>
                          {sponsorshipTypes.map((type) => (
                            <SelectItem key={type} value={type}>
                              {type}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Budget Range *</label>
                      <Select value={formData.budget} onValueChange={(value) => handleInputChange("budget", value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select budget range" />
                        </SelectTrigger>
                        <SelectContent>
                          {budgetRanges.map((range) => (
                            <SelectItem key={range} value={range}>
                              {range}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Partnership Objectives *</label>
                    <Textarea
                      required
                      value={formData.objectives}
                      onChange={(e) => handleInputChange("objectives", e.target.value)}
                      placeholder="What are your goals for this partnership? What impact do you want to achieve?"
                      className="min-h-[120px]"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Timeline *</label>
                    <Textarea
                      required
                      value={formData.timeline}
                      onChange={(e) => handleInputChange("timeline", e.target.value)}
                      placeholder="When would you like to start the partnership? Any specific deadlines or milestones?"
                      className="min-h-[80px]"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Previous CSR Experience</label>
                    <Textarea
                      value={formData.previousCSR}
                      onChange={(e) => handleInputChange("previousCSR", e.target.value)}
                      placeholder="Tell us about your company's previous corporate social responsibility initiatives..."
                      className="min-h-[100px]"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Additional Information</label>
                    <Textarea
                      value={formData.additionalInfo}
                      onChange={(e) => handleInputChange("additionalInfo", e.target.value)}
                      placeholder="Any additional information or specific requirements you'd like to share..."
                      className="min-h-[80px]"
                    />
                  </div>

                  <Button 
                    type="submit" 
                    disabled={isSubmitting}
                    className="w-full bg-[#d4af37] hover:bg-[#b8941f] text-white py-3 text-lg"
                  >
                    {isSubmitting ? (
                      "Submitting Inquiry..."
                    ) : (
                      <>
                        <Building className="w-5 h-5 mr-2" />
                        Submit Partnership Inquiry
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-[#101c2c] to-[#1a2b3d]">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-white mb-6">
              Ready to Make an Impact Together?
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              Our corporate partnerships team is ready to discuss how we can create meaningful change together
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-[#d4af37] hover:bg-[#b8941f] text-white font-semibold px-8 py-3">
                <Mail className="w-5 h-5 mr-2" />
                corporate@rehma.ai
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#101c2c] font-semibold px-8 py-3">
                <Phone className="w-5 h-5 mr-2" />
                +92-300-1234567
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#101c2c] font-semibold px-8 py-3">
                <Calendar className="w-5 h-5 mr-2" />
                Schedule Meeting
              </Button>
            </div>
          </div>
        </section>
      </div>
    </Layout>
  );
}
