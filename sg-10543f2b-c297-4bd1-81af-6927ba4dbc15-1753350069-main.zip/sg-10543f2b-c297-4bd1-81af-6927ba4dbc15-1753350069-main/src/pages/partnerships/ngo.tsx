import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Building, Users, Heart, Mail, Phone, Globe, Award, Target, Handshake } from "lucide-react";
import { useState } from "react";
import Layout from "@/components/Layout";

interface PartnershipForm {
  organizationName: string;
  contactPerson: string;
  email: string;
  phone: string;
  website: string;
  organizationType: string;
  location: string;
  description: string;
  partnershipType: string;
  experience: string;
}

const partnershipBenefits = [
  {
    icon: Heart,
    title: "Direct Impact",
    description: "Connect directly with families in need and see the immediate impact of your organization's work"
  },
  {
    icon: Users,
    title: "Expanded Reach",
    description: "Access our platform to reach more donors and supporters for your causes"
  },
  {
    icon: Globe,
    title: "Global Network",
    description: "Join a worldwide network of NGOs working together for children's welfare"
  },
  {
    icon: Award,
    title: "Recognition",
    description: "Get featured on our platform and gain recognition for your valuable work"
  },
  {
    icon: Target,
    title: "Resource Sharing",
    description: "Access shared resources, training materials, and best practices"
  },
  {
    icon: Handshake,
    title: "Collaboration",
    description: "Collaborate with other NGOs and healthcare providers in our network"
  }
];

const partnershipTypes = [
  "Medical Care Provider",
  "Child Welfare Organization",
  "Educational Support",
  "Rehabilitation Services",
  "Community Outreach",
  "Emergency Response",
  "Advocacy & Rights",
  "Other"
];

const organizationTypes = [
  "Registered NGO",
  "Non-Profit Organization",
  "Charity Foundation",
  "Community Organization",
  "Healthcare Provider",
  "Educational Institution",
  "Government Agency",
  "Other"
];

export default function NGOPartnershipPage() {
  const [formData, setFormData] = useState<PartnershipForm>({
    organizationName: "",
    contactPerson: "",
    email: "",
    phone: "",
    website: "",
    organizationType: "",
    location: "",
    description: "",
    partnershipType: "",
    experience: ""
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (field: keyof PartnershipForm, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    setTimeout(() => {
      alert("Thank you for your partnership application! Our team will review your submission and contact you within 3-5 business days.");
      setFormData({
        organizationName: "",
        contactPerson: "",
        email: "",
        phone: "",
        website: "",
        organizationType: "",
        location: "",
        description: "",
        partnershipType: "",
        experience: ""
      });
      setIsSubmitting(false);
    }, 2000);
  };

  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-gray-50">
        {/* Hero Section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-[#101c2c] to-[#1a2b3d]">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-6 bg-[#d4af37]/20 text-[#d4af37] hover:bg-[#d4af37]/30 border-[#d4af37]/30">
              🤝 Partnership Program
            </Badge>
            
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              NGO Partnership
            </h1>
            
            <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
              Join our network of trusted NGO partners and help us create a greater impact for children in need. Together, we can reach more families and provide comprehensive care.
            </p>

            <div className="bg-[#d4af37]/10 backdrop-blur-sm rounded-lg p-6 border border-[#d4af37]/20">
              <p className="text-white text-lg">
                <strong>Transparency Notice:</strong> From every donation processed through our platform, 10% goes to Rehma Portal to cover daily operations and platform maintenance. This ensures sustainable operations and continued service to all partner organizations.
              </p>
            </div>
          </div>
        </section>

        {/* Partnership Benefits */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-[#101c2c] mb-4">Why Partner with Rehma?</h2>
              <p className="text-xl text-gray-600">Benefits of joining our NGO network</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {partnershipBenefits.map((benefit, index) => (
                <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group">
                  <CardContent className="p-6 text-center">
                    <div className="w-16 h-16 bg-[#d4af37]/20 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-[#d4af37]/30 transition-colors">
                      <benefit.icon className="w-8 h-8 text-[#d4af37]" />
                    </div>
                    <h3 className="text-xl font-bold text-[#101c2c] mb-3">{benefit.title}</h3>
                    <p className="text-gray-600">{benefit.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Partnership Process */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-50 to-[#d4af37]/10">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-[#101c2c] mb-4">Partnership Process</h2>
              <p className="text-xl text-gray-600">Simple steps to become our partner</p>
            </div>

            <div className="space-y-8">
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-[#d4af37] rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-white font-bold text-sm">1</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-[#101c2c] mb-2">Application Submission</h3>
                  <p className="text-gray-600">Complete our partnership application form with your organization details and partnership goals.</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-[#d4af37] rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-white font-bold text-sm">2</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-[#101c2c] mb-2">Review & Verification</h3>
                  <p className="text-gray-600">Our team reviews your application and verifies your organization's credentials and impact history.</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-[#d4af37] rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-white font-bold text-sm">3</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-[#101c2c] mb-2">Partnership Agreement</h3>
                  <p className="text-gray-600">Once approved, we'll work together to establish partnership terms and integration process.</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-[#d4af37] rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-white font-bold text-sm">4</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-[#101c2c] mb-2">Platform Integration</h3>
                  <p className="text-gray-600">Get onboarded to our platform with training and support to maximize your impact.</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Partnership Application Form */}
        <section className="py-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <Card className="border-0 shadow-lg">
              <CardHeader className="text-center">
                <CardTitle className="text-3xl text-[#101c2c] mb-4">Partnership Application</CardTitle>
                <p className="text-gray-600">Tell us about your organization and how we can work together</p>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Organization Name *</label>
                      <Input
                        required
                        value={formData.organizationName}
                        onChange={(e) => handleInputChange("organizationName", e.target.value)}
                        placeholder="Your organization name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Contact Person *</label>
                      <Input
                        required
                        value={formData.contactPerson}
                        onChange={(e) => handleInputChange("contactPerson", e.target.value)}
                        placeholder="Primary contact person"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Email Address *</label>
                      <Input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => handleInputChange("email", e.target.value)}
                        placeholder="contact@yourorg.org"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Phone Number *</label>
                      <Input
                        required
                        value={formData.phone}
                        onChange={(e) => handleInputChange("phone", e.target.value)}
                        placeholder="+92-300-1234567"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Website</label>
                      <Input
                        value={formData.website}
                        onChange={(e) => handleInputChange("website", e.target.value)}
                        placeholder="https://yourorganization.org"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Organization Type *</label>
                      <Select value={formData.organizationType} onValueChange={(value) => handleInputChange("organizationType", value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select organization type" />
                        </SelectTrigger>
                        <SelectContent>
                          {organizationTypes.map((type) => (
                            <SelectItem key={type} value={type}>
                              {type}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Location *</label>
                      <Input
                        required
                        value={formData.location}
                        onChange={(e) => handleInputChange("location", e.target.value)}
                        placeholder="City, Country"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Partnership Type *</label>
                      <Select value={formData.partnershipType} onValueChange={(value) => handleInputChange("partnershipType", value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select partnership type" />
                        </SelectTrigger>
                        <SelectContent>
                          {partnershipTypes.map((type) => (
                            <SelectItem key={type} value={type}>
                              {type}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Organization Description *</label>
                    <Textarea
                      required
                      value={formData.description}
                      onChange={(e) => handleInputChange("description", e.target.value)}
                      placeholder="Tell us about your organization, mission, and current programs..."
                      className="min-h-[120px]"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Experience & Impact *</label>
                    <Textarea
                      required
                      value={formData.experience}
                      onChange={(e) => handleInputChange("experience", e.target.value)}
                      placeholder="Describe your experience working with children, families, or healthcare. Include any relevant achievements or impact metrics..."
                      className="min-h-[120px]"
                    />
                  </div>

                  <Button 
                    type="submit" 
                    disabled={isSubmitting}
                    className="w-full bg-[#d4af37] hover:bg-[#b8941f] text-white py-3 text-lg"
                  >
                    {isSubmitting ? (
                      "Submitting Application..."
                    ) : (
                      <>
                        <Building className="w-5 h-5 mr-2" />
                        Submit Partnership Application
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-[#101c2c] to-[#1a2b3d]">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-white mb-6">
              Have Questions About Partnership?
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              Our partnership team is here to help you understand the process and benefits
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-[#d4af37] hover:bg-[#b8941f] text-white font-semibold px-8 py-3">
                <Mail className="w-5 h-5 mr-2" />
                partnerships@rehma.ai
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#101c2c] font-semibold px-8 py-3">
                <Phone className="w-5 h-5 mr-2" />
                +92-300-1234567
              </Button>
            </div>
          </div>
        </section>
      </div>
    </Layout>
  );
}
