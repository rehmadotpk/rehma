
import type { NextApiRequest, NextApiResponse } from "next";
import { seoService } from "@/services/seoService";
import { emailService } from "@/services/emailService";
import { supabase } from "@/integrations/supabase/client";

type Data =
  | { success: true; results: Record<string, unknown> }
  | { success: false; error: string };

export default async function handler(req: NextApiRequest, res: NextApiResponse<Data>) {
  if (req.method !== "POST") {
    return res.status(405).json({ success: false, error: "Method not allowed" });
  }

  try {
    const results: Record<string, unknown> = {};

    // 1) Load settings
    const settings = await seoService.getSettings();

    // 2) Auto keyword research
    if (settings?.auto_keyword_research) {
      const newKeywords = await seoService.performKeywordResearch();
      let added = 0;
      for (const kw of newKeywords) {
        try {
          await seoService.addKeyword({
            keyword: kw,
            is_active: true,
            search_volume: null,
            difficulty: null,
            current_position: null,
            previous_position: null,
            target_url: null
          } as any);
          added++;
        } catch {
          // continue on duplicate or insert error
        }
      }
      results.keywordAdded = added;
    }

    // 3) Ranking check
    if (settings?.auto_ranking_check) {
      const check = await seoService.checkAllRankings();
      results.rankings = check;
    }

    // 4) Generate daily report
    const report = await seoService.generateDailyReport();
    results.reportId = report.id;

    // 5) Attempt to email report if configured
    if (settings?.daily_report_email) {
      const today = new Date().toISOString().split("T")[0];
      const subject = `Daily SEO Report - ${today}`;
      const html = `
        <h2>Daily SEO Report</h2>
        <p>Total Keywords: ${report.total_keywords}</p>
        <p>Improved: ${report.improved_keywords}</p>
        <p>Declined: ${report.declined_keywords}</p>
        <p>Average Position: ${report.average_position.toFixed(1)}</p>
      `;
      const text = `Daily SEO Report
Total Keywords: ${report.total_keywords}
Improved: ${report.improved_keywords}
Declined: ${report.declined_keywords}
Average Position: ${report.average_position.toFixed(1)}
`;

      try {
        await emailService.sendEmail({
          to: settings.daily_report_email,
          subject,
          html,
          text
        });

        await supabase
          .from("seo_reports")
          .update({ sent_at: new Date().toISOString() })
          .eq("id", report.id);
      } catch {
        // Do not fail the whole job if email fails
      }
    }

    return res.status(200).json({ success: true, results });
  } catch (e) {
    const message = e instanceof Error ? e.message : "Unknown automation error";
    return res.status(500).json({ success: false, error: message });
  }
}
  