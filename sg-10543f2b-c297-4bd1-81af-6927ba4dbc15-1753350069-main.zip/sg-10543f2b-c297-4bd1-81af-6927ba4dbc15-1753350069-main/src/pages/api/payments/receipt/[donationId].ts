import { NextApiRequest, NextApiResponse } from "next";
import PDFDocument from "pdfkit";
import { createClient } from "@supabase/supabase-js";
import { Database } from "@/integrations/supabase/types";

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  const { donationId } = req.query;

  if (!donationId || typeof donationId !== "string") {
    return res.status(400).json({ error: "Invalid donation ID" });
  }

  try {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

    if (!supabaseUrl || !supabaseServiceKey) {
      return res.status(500).json({ error: "Supabase environment variables not set." });
    }
    // Use admin client for server-side requests to bypass RLS
    const supabaseAdmin = createClient<Database>(
      supabaseUrl,
      supabaseServiceKey
    );

    const { data: donation, error } = await supabaseAdmin
      .from("donations")
      .select(
        `
        *,
        child:children(name, condition)
      `
      )
      .eq("id", donationId)
      .single();

    if (error || !donation) {
      console.error("Donation fetch error:", error);
      throw error || new Error("Donation not found");
    }

    const doc = new PDFDocument({ size: "A4", margin: 50 });

    res.setHeader("Content-Type", "application/pdf");
    res.setHeader(
      "Content-Disposition",
      `attachment; filename=receipt-${donation.id}.pdf`
    );
    doc.pipe(res);

    // --- PDF Content ---
    // Header
    doc
      .fontSize(20)
      .font("Helvetica-Bold")
      .text("Donation Receipt", { align: "center" })
      .moveDown();

    // Platform Info
    doc
      .fontSize(16)
      .text("Rehma", { align: "left" })
      .fontSize(10)
      .text("Connecting hearts, changing lives.", { align: "left" })
      .moveDown(2);

    // Receipt Details
    doc.fontSize(12).font("Helvetica-Bold").text("Receipt Details");
    doc.font("Helvetica").text(`Receipt ID: ${donation.id}`);
    doc.text(`Date: ${new Date(donation.created_at).toLocaleDateString()}`);
    doc.moveDown();

    // Donor Info
    doc.font("Helvetica-Bold").text("Donated By");
    doc
      .font("Helvetica")
      .text(donation.anonymous ? "Anonymous Donor" : donation.donor_name);
    doc.text(donation.donor_email);
    doc.moveDown();

    // Donation Info
    doc.font("Helvetica-Bold").text("Donation Details");
    const currency = donation.currency.toUpperCase();
    const amount = new Intl.NumberFormat("en-US", {
      style: "currency",
      currency,
    }).format(donation.amount);
    doc.font("Helvetica").text(`Amount: ${amount}`);
    doc.text(`Payment Method: ${donation.payment_method}`);
    doc.text(`Status: ${donation.payment_status}`);
    doc.moveDown();

    // Beneficiary Info
    if (donation.child) {
      doc.font("Helvetica-Bold").text("Beneficiary");
      doc.font("Helvetica").text(`Child: ${donation.child.name}`);
      doc.text(`Condition: ${donation.child.condition}`);
      doc.moveDown();
    }

    // Message
    if (donation.message) {
      doc.font("Helvetica-Bold").text("Message from Donor");
      doc.font("Helvetica").text(`"${donation.message}"`);
      doc.moveDown();
    }

    // Footer
    doc
      .fontSize(10)
      .text(
        "Thank you for your generous contribution. Your support makes a world of difference.",
        { align: "center" }
      )
      .moveDown()
      .text("www.rehma.ai", { align: "center", link: "https://www.rehma.ai" });

    doc.end();
  } catch (error) {
    console.error("Failed to generate receipt:", error);
    res.status(500).json({ error: "Failed to generate receipt" });
  }
}
