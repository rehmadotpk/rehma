
import { NextApiRequest, NextApiResponse } from 'next';
import { donationService } from '@/services/donationService';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const {
      orderID,
      childId,
      donorEmail,
    } = req.body;

    if (!orderID || !childId || !donorEmail) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Capture PayPal payment
    const paypalResponse = await fetch(`${process.env.PAYPAL_API_BASE}/v2/checkout/orders/${orderID}/capture`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${await getPayPalAccessToken()}`,
      }
    });

    const paypalData = await paypalResponse.json();

    if (!paypalResponse.ok) {
      throw new Error(paypalData.message || 'PayPal capture failed');
    }

    const capture = paypalData.purchase_units[0].payments.captures[0];
    const transactionId = capture.id;

    // Update donation status to completed
    const donations = await donationService.getUserDonations(donorEmail, 1, 1);
    const pendingDonation = donations.donations.find(d => 
      d.child_id === childId && 
      d.payment_status === 'pending' && 
      d.payment_method === 'paypal'
    );

    if (pendingDonation) {
      await donationService.updateDonation(pendingDonation.id, {
        payment_status: 'completed',
        transaction_id: transactionId,
        order_id: orderID
      });
    } else {
        console.warn(`Could not find pending PayPal donation for email ${donorEmail} and child ${childId} to update.`);
        // Even if we don't find the pending donation, the payment is successful.
        // We might want to create a new donation record here or log this for manual review.
    }

    res.status(200).json({ 
      success: true, 
      transactionId,
      message: 'Payment captured successfully' 
    });
  } catch (error) {
    console.error('PayPal capture error:', error);
    res.status(500).json({ 
      error: error instanceof Error ? error.message : 'Failed to capture PayPal payment' 
    });
  }
}

async function getPayPalAccessToken(): Promise<string> {
  const response = await fetch(`${process.env.PAYPAL_API_BASE}/v1/oauth2/token`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Authorization': `Basic ${Buffer.from(`${process.env.PAYPAL_CLIENT_ID}:${process.env.PAYPAL_CLIENT_SECRET}`).toString('base64')}`,
    },
    body: 'grant_type=client_credentials'
  });

  const data = await response.json();
  
  if (!response.ok) {
    throw new Error('Failed to get PayPal access token');
  }

  return data.access_token;
}
