
import { NextApiRequest, NextApiResponse } from 'next';
import { donationService } from '@/services/donationService';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const {
      amount,
      currency,
      childId,
      donorName,
      donorEmail,
      donorPhone,
      message,
      anonymous
    } = req.body;

    if (!amount || !currency || !childId || !donorName || !donorEmail) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Create PayPal order
    const paypalResponse = await fetch(`${process.env.PAYPAL_API_BASE}/v2/checkout/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${await getPayPalAccessToken()}`,
      },
      body: JSON.stringify({
        intent: 'CAPTURE',
        purchase_units: [{
          amount: {
            currency_code: currency,
            value: amount.toFixed(2)
          },
          description: `Donation for child ${childId}`,
          custom_id: childId
        }],
        application_context: {
          return_url: `${process.env.NEXT_PUBLIC_BASE_URL}/payment/success`,
          cancel_url: `${process.env.NEXT_PUBLIC_BASE_URL}/payment/cancel`,
          brand_name: 'Rehma',
          user_action: 'PAY_NOW'
        }
      })
    });

    const paypalData = await paypalResponse.json();

    if (!paypalResponse.ok) {
      throw new Error(paypalData.message || 'PayPal order creation failed');
    }

    // Create pending donation record
    await donationService.createDonation({
      child_id: childId,
      donor_id: null,
      amount: parseFloat(amount),
      currency,
      donor_name: donorName,
      donor_email: donorEmail,
      donor_phone: donorPhone,
      payment_status: 'pending',
      donation_type: 'one-time',
      payment_method: 'paypal',
      anonymous: anonymous || false,
      message: message || ''
    });

    res.status(200).json({ orderID: paypalData.id });
  } catch (error) {
    console.error('PayPal create order error:', error);
    res.status(500).json({ 
      error: error instanceof Error ? error.message : 'Failed to create PayPal order' 
    });
  }
}

async function getPayPalAccessToken(): Promise<string> {
  const response = await fetch(`${process.env.PAYPAL_API_BASE}/v1/oauth2/token`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Authorization': `Basic ${Buffer.from(`${process.env.PAYPAL_CLIENT_ID}:${process.env.PAYPAL_CLIENT_SECRET}`).toString('base64')}`,
    },
    body: 'grant_type=client_credentials'
  });

  const data = await response.json();
  
  if (!response.ok) {
    throw new Error('Failed to get PayPal access token');
  }

  return data.access_token;
}
