import { NextApiRequest, NextApiResponse } from 'next';
import { stripe } from '@/lib/stripe';
import { createClient } from '@supabase/supabase-js';
import { buffer } from "micro";

// Disable body parsing for webhook
export const config = {
  api: {
    bodyParser: false,
  },
};

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const buf = await buffer(req);
  const sig = req.headers["stripe-signature"] as string;
  
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!webhookSecret) {
    console.error("STRIPE_WEBHOOK_SECRET is not set.");
    return res.status(500).json({ error: "Webhook secret not configured." });
  }

  let event;

  try {
    event = stripe.webhooks.constructEvent(buf, sig, webhookSecret);
  } catch (err) {
    console.error('Webhook signature verification failed:', err);
    return res.status(400).json({ error: "Webhook signature verification failed" });
  }

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!supabaseUrl || !supabaseServiceKey) {
    console.error("Supabase environment variables not set for webhook.");
    return res.status(500).json({ error: "Database connection failed." });
  }

  const supabaseAdmin = createClient(
    supabaseUrl,
    supabaseServiceKey
  );

  try {
    switch (event.type) {
      case 'payment_intent.succeeded': {
        const paymentIntent = event.data.object;
        const donationId = paymentIntent.metadata.donationId;
        const childId = paymentIntent.metadata.childId;

        if (donationId) {
          // Update donation status to completed
          await supabaseAdmin
            .from('donations')
            .update({ 
              payment_status: 'completed',
              updated_at: new Date().toISOString()
            })
            .eq('id', donationId);

          // Update child's raised amount
          const { data: donations } = await supabaseAdmin
            .from('donations')
            .select('amount')
            .eq('child_id', childId)
            .eq('payment_status', 'completed');

          if (donations) {
            const totalRaised = donations.reduce((sum, d) => sum + Number(d.amount), 0);
            await supabaseAdmin
              .from('children')
              .update({ 
                raised_amount: totalRaised,
                updated_at: new Date().toISOString()
              })
              .eq('id', childId);
          }
        }
        break;
      }

      case 'payment_intent.payment_failed': {
        const paymentIntent = event.data.object;
        const donationId = paymentIntent.metadata.donationId;

        if (donationId) {
          await supabaseAdmin
            .from('donations')
            .update({ 
              payment_status: 'failed',
              updated_at: new Date().toISOString()
            })
            .eq('id', donationId);
        }
        break;
      }

      case 'payment_intent.canceled': {
        const paymentIntent = event.data.object;
        const donationId = paymentIntent.metadata.donationId;

        if (donationId) {
          await supabaseAdmin
            .from('donations')
            .update({ 
              payment_status: 'failed',
              updated_at: new Date().toISOString()
            })
            .eq('id', donationId);
        }
        break;
      }

      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    res.status(200).json({ received: true });
  } catch (error) {
    console.error('Webhook processing error:', error);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
}
