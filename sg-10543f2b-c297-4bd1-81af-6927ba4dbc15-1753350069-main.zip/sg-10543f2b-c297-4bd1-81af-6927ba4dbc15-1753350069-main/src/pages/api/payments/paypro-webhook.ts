
import { NextApiRequest, NextApiResponse } from "next";
import { payproService } from "@/services/payproService";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") {
    return res.status(405).json({ message: "Method not allowed" });
  }

  try {
    const webhookData = req.body;
    
    // Log webhook for debugging
    console.log("PayPro Webhook received:", webhookData);

    // Handle the webhook
    const success = await payproService.handleWebhook(webhookData);

    if (success) {
      res.status(200).json({ message: "Webhook processed successfully" });
    } else {
      res.status(400).json({ message: "Webhook processing failed" });
    }
  } catch (error) {
    console.error("Webhook error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
}
