import { NextApiRequest, NextApiResponse } from "next";
import { stripe, safeStripeOperation } from "@/lib/stripe";
import { supabase } from "@/integrations/supabase/client";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Check if Stripe is configured
  if (!stripe) {
    return res.status(503).json({ 
      error: 'Payment service is not configured. Please contact support.',
      code: 'STRIPE_NOT_CONFIGURED'
    });
  }

  try {
    const { amount, currency = 'pkr', childId, donorId, donationType = 'one-time', donorName, donorEmail } = req.body;

    if (!amount || amount <= 0) {
      return res.status(400).json({ error: 'Invalid amount' });
    }

    if (!childId || !donorId || !donorName || !donorEmail) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Convert amount to smallest currency unit (paisas for PKR, cents for USD)
    const amountInSmallestUnit = Math.round(amount * 100);

    // Create payment intent using safe operation
    const paymentIntent = await safeStripeOperation(async () => {
      return stripe.paymentIntents.create({
        amount: amountInSmallestUnit,
        currency: currency.toLowerCase(),
        metadata: {
          childId,
          donorId,
          donationType,
          platform: 'rehma'
        },
        automatic_payment_methods: {
          enabled: true,
        },
      });
    });

    if (!paymentIntent) {
      return res.status(500).json({ error: 'Failed to create payment intent' });
    }

    // Create a donation record in your database
    const { data: donationData, error: donationError } = await supabase
      .from("donations")
      .insert({
        amount: Math.round(amount), // Ensure amount is an integer
        currency: currency.toUpperCase(),
        payment_status: "pending", // Corrected value
        donor_id: donorId,
        child_id: childId,
        donor_name: donorName,
        donor_email: donorEmail,
        anonymous: false, 
        donation_type: donationType,
        payment_method: "card", // Add payment method
        transaction_id: paymentIntent.id
      })
      .select()
      .single();

    if (donationError) {
      console.error("Error creating donation record:", donationError);
      // Attempt to cancel the payment intent if donation record fails
      await safeStripeOperation(() => stripe.paymentIntents.cancel(paymentIntent.id));
      return res.status(500).json({ error: "Failed to record donation" });
    }

    res.status(200).json({ client_secret: paymentIntent.client_secret, id: donationData.id });

  } catch (error) {
    console.error('Payment intent creation error:', error);
    res.status(500).json({ 
      error: 'Failed to create payment intent',
      details: process.env.NODE_ENV === 'development' ? error : undefined
    });
  }
}
