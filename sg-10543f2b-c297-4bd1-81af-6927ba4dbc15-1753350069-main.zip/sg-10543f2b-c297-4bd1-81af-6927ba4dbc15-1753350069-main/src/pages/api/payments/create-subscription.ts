import { NextApiRequest, NextApiResponse } from "next";
import Stripe from "stripe";

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== "POST") {
    return res.status(405).json({ message: "Method not allowed" });
  }

  // Check for Stripe secret key at runtime
  if (!process.env.STRIPE_SECRET_KEY) {
    return res.status(500).json({ 
      message: "Payment system not configured",
      error: "STRIPE_SECRET_KEY is not set in environment variables."
    });
  }

  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
    apiVersion: "2025-02-24.acacia",
  });

  try {
    const {
      amount,
      currency = "usd",
      donor_email,
      donor_name,
      recurring_frequency = "monthly",
      child_id,
      ngo_id,
    } = req.body;

    // Create or retrieve customer
    let customer;
    const existingCustomers = await stripe.customers.list({
      email: donor_email,
      limit: 1,
    });

    if (existingCustomers.data.length > 0) {
      customer = existingCustomers.data[0];
    } else {
      customer = await stripe.customers.create({
        email: donor_email,
        name: donor_name,
        metadata: {
          platform: "rehma",
        },
      });
    }

    // Create price for recurring donation
    const price = await stripe.prices.create({
      unit_amount: Math.round(amount * 100),
      currency: currency.toLowerCase(),
      recurring: {
        interval: recurring_frequency === "yearly" ? "year" : "month",
        interval_count: recurring_frequency === "quarterly" ? 3 : 1,
      },
      product_data: {
        name: `Recurring Donation - Rehma Platform for ${child_id ? `child ${child_id}` : ""}${ngo_id ? `NGO ${ngo_id}` : ""}`,
      },
      metadata: {
        child_id: child_id || "",
        ngo_id: ngo_id || "",
      },
    });

    // Create subscription
    const subscription = await stripe.subscriptions.create({
      customer: customer.id,
      items: [{ price: price.id }],
      payment_behavior: "default_incomplete",
      payment_settings: { save_default_payment_method: "on_subscription" },
      expand: ["latest_invoice.payment_intent"],
    });

    const invoice = subscription.latest_invoice as Stripe.Invoice;
    const paymentIntent = invoice.payment_intent as Stripe.PaymentIntent;

    res.status(200).json({
      subscription_id: subscription.id,
      client_secret: paymentIntent.client_secret,
      customer_id: customer.id,
    });
  } catch (error: unknown) {
    console.error("Subscription creation failed:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    res.status(500).json({
      message: "Subscription creation failed",
      error: errorMessage,
    });
  }
}
