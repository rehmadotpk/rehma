import { useState, useEffect } from "react";
import { useRouter } from "next/router";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Users, 
  Loader2,
  Settings,
  Shield,
  AlertTriangle,
  LayoutDashboard,
  CreditCard,
  Search as SearchIcon,
  BarChart3,
  FileCheck,
  Menu,
  X,
  ChevronRight,
  UserCog,
  Calendar,
  Users2,
  Image as ImageIcon,
  Search
} from "lucide-react";
import Layout from "@/components/Layout";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import dynamic from "next/dynamic";
const ChildrenManagement = dynamic(() => import("@/components/admin/ChildrenManagement").then(m => m.ChildrenManagement), { ssr: false, loading: () => <Loader2 className="h-5 w-5 animate-spin" /> });
const ApprovalManagement = dynamic(() => import("@/components/admin/ApprovalManagement").then(m => m.ApprovalManagement), { ssr: false, loading: () => <Loader2 className="h-5 w-5 animate-spin" /> });
const BannerManagement = dynamic(() => import("@/components/admin/BannerManagement").then(m => m.BannerManagement), { ssr: false, loading: () => <Loader2 className="h-5 w-5 animate-spin" /> });
const AdvancedAnalytics = dynamic(() => import("@/components/admin/AdvancedAnalytics").then(m => m.AdvancedAnalytics), { ssr: false, loading: () => <Loader2 className="h-5 w-5 animate-spin" /> });
const PaymentGatewayManagement = dynamic(() => import("@/components/admin/PaymentGatewayManagement").then(m => m.PaymentGatewayManagement), { ssr: false, loading: () => <Loader2 className="h-5 w-5 animate-spin" /> });
const SEOManagement = dynamic(() => import("@/components/admin/SEOManagement").then(m => m.SEOManagement), { ssr: false, loading: () => <Loader2 className="h-5 w-5 animate-spin" /> });
import { Separator } from "@/components/ui/separator";

type AdminSection = 
  | "overview" 
  | "children" 
  | "approvals" 
  | "banners" 
  | "analytics" 
  | "payments" 
  | "seo";

interface SidebarItem {
  id: AdminSection;
  label: string;
  icon: typeof LayoutDashboard;
  description: string;
}

const sidebarItems: SidebarItem[] = [
  {
    id: "overview",
    label: "Overview",
    icon: LayoutDashboard,
    description: "Dashboard overview and statistics"
  },
  {
    id: "children",
    label: "Children Management",
    icon: Users,
    description: "Manage children profiles"
  },
  {
    id: "approvals",
    label: "Approvals",
    icon: FileCheck,
    description: "Review pending approvals"
  },
  {
    id: "banners",
    label: "Banner System",
    icon: Calendar,
    description: "Manage promotional banners"
  },
  {
    id: "payments",
    label: "Payment Gateways",
    icon: CreditCard,
    description: "Configure payment integrations"
  },
  {
    id: "seo",
    label: "SEO Management",
    icon: SearchIcon,
    description: "Advanced SEO automation"
  },
  {
    id: "analytics",
    label: "Analytics",
    icon: BarChart3,
    description: "Advanced analytics and insights"
  }
];

function AdminDashboardContent() {
  const { userProfile } = useAuth();
  const { toast } = useToast();
  const router = useRouter();
  const [activeSection, setActiveSection] = useState<AdminSection>("overview");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalChildren: 0,
    pendingApprovals: 0,
    activeBanners: 0
  });

  useEffect(() => {
    // Load basic stats for overview
    const loadStats = async () => {
      try {
        // TODO: Implement actual stat fetching from your services
        setStats({
          totalUsers: 0,
          totalChildren: 0,
          pendingApprovals: 0,
          activeBanners: 0
        });
      } catch (error) {
        console.error("Failed to load stats:", error);
      }
    };
    loadStats();
  }, []);

  const renderContent = () => {
    switch (activeSection) {
      case "overview":
        return (
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold">Welcome back, {userProfile?.full_name || "Admin"}</h1>
              <p className="text-muted-foreground mt-2">Manage your platform from this central dashboard</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Total Users</p>
                      <h3 className="text-2xl font-bold mt-1">{stats.totalUsers}</h3>
                    </div>
                    <Users className="h-8 w-8 text-blue-500" />
                  </div>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Children</p>
                      <h3 className="text-2xl font-bold mt-1">{stats.totalChildren}</h3>
                    </div>
                    <Users className="h-8 w-8 text-green-500" />
                  </div>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Pending Approvals</p>
                      <h3 className="text-2xl font-bold mt-1">{stats.pendingApprovals}</h3>
                    </div>
                    <FileCheck className="h-8 w-8 text-yellow-500" />
                  </div>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Active Banners</p>
                      <h3 className="text-2xl font-bold mt-1">{stats.activeBanners}</h3>
                    </div>
                    <Calendar className="h-8 w-8 text-purple-500" />
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardContent className="pt-6">
                  <h3 className="font-semibold mb-4">Quick Actions</h3>
                  <div className="space-y-2">
                    {sidebarItems.slice(1).map((item) => (
                      <Button
                        key={item.id}
                        variant="outline"
                        className="w-full justify-start"
                        onClick={() => setActiveSection(item.id)}
                      >
                        <item.icon className="h-4 w-4 mr-2" />
                        {item.label}
                        <ChevronRight className="h-4 w-4 ml-auto" />
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <h3 className="font-semibold mb-4">System Status</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Payment Gateways</span>
                      <Badge variant="default">Active</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">SEO Automation</span>
                      <Badge variant="default">Running</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Database</span>
                      <Badge variant="default">Healthy</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Email Service</span>
                      <Badge variant="default">Active</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardContent className="pt-6">
                <h3 className="font-semibold mb-4">Admin Tools</h3>
                <div className="flex flex-wrap gap-3">
                  <Button variant="outline" onClick={() => router.push('/admin/create-admin')}>
                    <Shield className="h-4 w-4 mr-2" />
                    Create Admin
                  </Button>
                  <Button variant="outline" onClick={() => router.push('/admin/setup')}>
                    <Settings className="h-4 w-4 mr-2" />
                    Initial Setup
                  </Button>
                  <Button variant="outline" onClick={() => router.push('/admin/database-reset')}>
                    <Settings className="h-4 w-4 mr-2" />
                    Database Tools
                  </Button>
                  <Button variant="outline" onClick={() => router.push('/settings')}>
                    <Settings className="h-4 w-4 mr-2" />
                    System Settings
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        );
      case "children":
        return <ChildrenManagement />;
      case "approvals":
        return <ApprovalManagement />;
      case "banners":
        return <BannerManagement />;
      case "analytics":
        return <AdvancedAnalytics />;
      case "payments":
        return <PaymentGatewayManagement />;
      case "seo":
        return <SEOManagement />;
      default:
        return null;
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar */}
      <aside
        className={`fixed lg:sticky top-0 left-0 z-40 h-screen transition-transform ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        } ${sidebarOpen ? "w-64" : "lg:w-20"} bg-white border-r border-gray-200`}
      >
        <div className="flex flex-col h-full">
          {/* Sidebar Header */}
          <div className="flex items-center justify-between p-4 border-b">
            {sidebarOpen && (
              <div className="flex items-center gap-2">
                <Shield className="h-6 w-6 text-blue-600" />
                <span className="font-bold text-lg">Admin</span>
              </div>
            )}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:flex hidden"
            >
              {sidebarOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </Button>
          </div>

          {/* Sidebar Navigation */}
          <nav className="flex-1 overflow-y-auto p-4">
            <div className="space-y-2">
              {sidebarItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveSection(item.id);
                    if (window.innerWidth < 1024) setSidebarOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                    activeSection === item.id
                      ? "bg-blue-50 text-blue-600 font-medium"
                      : "text-gray-700 hover:bg-gray-100"
                  }`}
                >
                  <item.icon className="h-5 w-5 flex-shrink-0" />
                  {sidebarOpen && (
                    <div className="text-left flex-1 min-w-0">
                      <div className="text-sm font-medium truncate">{item.label}</div>
                      {activeSection === item.id && (
                        <div className="text-xs text-gray-500 truncate">{item.description}</div>
                      )}
                    </div>
                  )}
                  {activeSection === item.id && (
                    <ChevronRight className="h-4 w-4 flex-shrink-0" />
                  )}
                </button>
              ))}
            </div>
          </nav>

          {/* Sidebar Footer */}
          {sidebarOpen && (
            <div className="p-4 border-t">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                  <UserCog className="h-5 w-5 text-blue-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{userProfile?.full_name || "Admin"}</p>
                  <p className="text-xs text-gray-500 truncate">{userProfile?.email}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </aside>

      {/* Mobile Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        <div className="sticky top-0 z-10 bg-white border-b lg:hidden">
          <div className="flex items-center justify-between p-4">
            <Button variant="ghost" size="sm" onClick={() => setSidebarOpen(true)}>
              <Menu className="h-5 w-5" />
            </Button>
            <span className="font-semibold">Admin Dashboard</span>
            <div className="w-8" />
          </div>
        </div>

        <div className="p-6 lg:p-8 max-w-7xl mx-auto">
          {renderContent()}
        </div>
      </main>
    </div>
  );
}

export default function AdminDashboard() {
  const { user, loading, isAdmin, userProfile, initialized } = useAuth();

  if (loading || !initialized) {
    return (
      <Layout>
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="h-12 w-12 animate-spin mx-auto mb-4" />
            <p className="text-gray-600">Loading admin dashboard...</p>
          </div>
        </div>
      </Layout>
    );
  }

  if (!user) {
    return (
      <Layout>
        <div className="min-h-screen flex items-center justify-center bg-gray-100">
          <Card className="max-w-md w-full mx-4 text-center">
            <CardContent className="p-8">
              <AlertTriangle className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
              <h1 className="text-2xl font-bold text-gray-900 mb-4">Access Denied</h1>
              <p className="text-gray-600 mb-6">You must be logged in to access this page.</p>
              <Button onClick={() => window.location.href = '/auth/login'} className="w-full">
                <Shield className="w-4 h-4 mr-2" />
                Login
              </Button>
            </CardContent>
          </Card>
        </div>
      </Layout>
    );
  }

  if (!isAdmin) {
    return (
      <Layout>
        <div className="min-h-screen flex items-center justify-center bg-gray-100">
          <Card className="max-w-md w-full mx-4 text-center">
            <CardContent className="p-8">
              <AlertTriangle className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
              <h1 className="text-2xl font-bold text-gray-900 mb-4">Access Denied</h1>
              <p className="text-gray-600 mb-6">
                You must be an administrator to view this page.
              </p>
              <div className="space-y-3 text-sm text-gray-500">
                <p>Current user: {userProfile?.email}</p>
                <p>Current role: {userProfile?.role || 'No role assigned'}</p>
                <Button onClick={() => window.location.href = '/auth/login'} className="w-full">
                  <Shield className="w-4 h-4 mr-2" />
                  Login as Admin
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <AdminDashboardContent />
    </Layout>
  );
}

export function AdminHome() {
  const [section, setSection] = useState<"analytics" | "approvals" | "children" | "banners" | "payments" | "seo">("analytics");

  const NavButton = ({ id, icon: Icon, label }: { id: typeof section; icon: any; label: string }) => (
    <Button
      variant={section === id ? "default" : "ghost"}
      className="w-full justify-start"
      onClick={() => setSection(id)}
    >
      <Icon className="w-4 h-4 mr-2" />
      {label}
    </Button>
  );

  return (
    <div className="max-w-7xl mx-auto p-4">
      <div className="grid grid-cols-12 gap-6">
        <aside className="col-span-12 md:col-span-3">
          <Card>
            <CardContent className="p-3 space-y-1">
              <NavButton id="analytics" icon={BarChart3} label="Dashboard" />
              <NavButton id="approvals" icon={Users2} label="Approvals" />
              <NavButton id="children" icon={Users2} label="Children" />
              <NavButton id="banners" icon={ImageIcon} label="Banners" />
              <Separator className="my-2" />
              <NavButton id="payments" icon={CreditCard} label="Payment Gateways" />
              <NavButton id="seo" icon={Search} label="SEO Automation" />
            </CardContent>
          </Card>
        </aside>

        <main className="col-span-12 md:col-span-9 space-y-4">
          {section === "analytics" && <AdvancedAnalytics />}
          {section === "approvals" && <ApprovalManagement />}
          {section === "children" && <ChildrenManagement />}
          {section === "banners" && <BannerManagement />}
          {section === "payments" && <PaymentGatewayManagement />}
          {section === "seo" && <SEOManagement />}
        </main>
      </div>
    </div>
  );
}
