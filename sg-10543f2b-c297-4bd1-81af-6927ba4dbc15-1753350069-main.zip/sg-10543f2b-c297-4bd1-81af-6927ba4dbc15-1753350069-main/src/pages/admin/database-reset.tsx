
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Trash2, UserPlus, AlertTriangle, CheckCircle } from "lucide-react";
import Layout from "@/components/Layout";
import databaseResetService from "@/services/databaseResetService";
import { useRouter } from "next/router";

export default function DatabaseResetPage() {
  const router = useRouter();
  const [isClearing, setIsClearing] = useState(false);
  const [isCreatingAdmin, setIsCreatingAdmin] = useState(false);
  const [clearResult, setClearResult] = useState<{ success: boolean; message?: string; error?: string } | null>(null);
  const [adminResult, setAdminResult] = useState<{ success: boolean; message?: string; error?: string } | null>(null);
  
  const [adminData, setAdminData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    fullName: ""
  });

  const handleClearDatabase = async () => {
    if (!confirm("⚠️ WARNING: This will permanently delete ALL user data including profiles, roles, and donations. This action cannot be undone. Are you sure?")) {
      return;
    }

    setIsClearing(true);
    setClearResult(null);

    try {
      const result = await databaseResetService.clearAllUsers();
      setClearResult(result);
    } catch (error) {
      setClearResult({ success: false, error: error.message });
    } finally {
      setIsClearing(false);
    }
  };

  const handleCreateAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (adminData.password !== adminData.confirmPassword) {
      setAdminResult({ success: false, error: "Passwords do not match" });
      return;
    }

    if (adminData.password.length < 6) {
      setAdminResult({ success: false, error: "Password must be at least 6 characters long" });
      return;
    }

    setIsCreatingAdmin(true);
    setAdminResult(null);

    try {
      const result = await databaseResetService.createAdminUser(
        adminData.email,
        adminData.password,
        adminData.fullName
      );
      setAdminResult(result);
      
      if (result.success) {
        // Clear form
        setAdminData({
          email: "",
          password: "",
          confirmPassword: "",
          fullName: ""
        });
        
        // Redirect to login after 3 seconds
        setTimeout(() => {
          router.push('/auth/login');
        }, 3000);
      }
    } catch (error) {
      setAdminResult({ success: false, error: error.message });
    } finally {
      setIsCreatingAdmin(false);
    }
  };

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Database Reset & Admin Setup</h1>
            <p className="text-lg text-gray-600">
              Reset the database and create a new admin user for the Rehma platform
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Clear Database Section */}
            <Card className="border-red-200">
              <CardHeader>
                <CardTitle className="flex items-center text-red-700">
                  <Trash2 className="w-5 h-5 mr-2" />
                  Clear All User Data
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Alert className="border-red-200 bg-red-50">
                  <AlertTriangle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-800">
                    <strong>Danger Zone:</strong> This will permanently delete all users, profiles, roles, and user-related donations. This action cannot be undone.
                  </AlertDescription>
                </Alert>

                <div className="space-y-2">
                  <h4 className="font-semibold text-gray-900">What will be deleted:</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• All user accounts and authentication data</li>
                    <li>• User profiles and personal information</li>
                    <li>• User roles and permissions</li>
                    <li>• User-related donations and transactions</li>
                    <li>• User notifications and preferences</li>
                  </ul>
                </div>

                <Button
                  onClick={handleClearDatabase}
                  disabled={isClearing}
                  className="w-full bg-red-600 hover:bg-red-700 text-white"
                >
                  {isClearing ? "Clearing Database..." : "Clear All User Data"}
                </Button>

                {clearResult && (
                  <Alert className={clearResult.success ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"}>
                    {clearResult.success ? (
                      <CheckCircle className="h-4 w-4 text-green-600" />
                    ) : (
                      <AlertTriangle className="h-4 w-4 text-red-600" />
                    )}
                    <AlertDescription className={clearResult.success ? "text-green-800" : "text-red-800"}>
                      {clearResult.success ? clearResult.message : clearResult.error}
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>

            {/* Create Admin Section */}
            <Card className="border-green-200">
              <CardHeader>
                <CardTitle className="flex items-center text-green-700">
                  <UserPlus className="w-5 h-5 mr-2" />
                  Create New Admin User
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleCreateAdmin} className="space-y-4">
                  <div>
                    <Label htmlFor="fullName">Full Name</Label>
                    <Input
                      id="fullName"
                      type="text"
                      value={adminData.fullName}
                      onChange={(e) => setAdminData({ ...adminData, fullName: e.target.value })}
                      placeholder="Enter admin full name"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      value={adminData.email}
                      onChange={(e) => setAdminData({ ...adminData, email: e.target.value })}
                      placeholder="admin@rehma.ai"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="password">Password</Label>
                    <Input
                      id="password"
                      type="password"
                      value={adminData.password}
                      onChange={(e) => setAdminData({ ...adminData, password: e.target.value })}
                      placeholder="Enter secure password"
                      minLength={6}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="confirmPassword">Confirm Password</Label>
                    <Input
                      id="confirmPassword"
                      type="password"
                      value={adminData.confirmPassword}
                      onChange={(e) => setAdminData({ ...adminData, confirmPassword: e.target.value })}
                      placeholder="Confirm password"
                      minLength={6}
                      required
                    />
                  </div>

                  <Button
                    type="submit"
                    disabled={isCreatingAdmin}
                    className="w-full bg-green-600 hover:bg-green-700 text-white"
                  >
                    {isCreatingAdmin ? "Creating Admin..." : "Create Admin User"}
                  </Button>
                </form>

                {adminResult && (
                  <Alert className={`mt-4 ${adminResult.success ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"}`}>
                    {adminResult.success ? (
                      <CheckCircle className="h-4 w-4 text-green-600" />
                    ) : (
                      <AlertTriangle className="h-4 w-4 text-red-600" />
                    )}
                    <AlertDescription className={adminResult.success ? "text-green-800" : "text-red-800"}>
                      {adminResult.success ? (
                        <>
                          {adminResult.message}
                          <br />
                          <span className="text-sm">Redirecting to login page in 3 seconds...</span>
                        </>
                      ) : (
                        adminResult.error
                      )}
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="mt-8 text-center">
            <Button
              variant="outline"
              onClick={() => router.push('/admin')}
              className="px-6 py-2"
            >
              Back to Admin Panel
            </Button>
          </div>
        </div>
      </div>
    </Layout>
  );
}
