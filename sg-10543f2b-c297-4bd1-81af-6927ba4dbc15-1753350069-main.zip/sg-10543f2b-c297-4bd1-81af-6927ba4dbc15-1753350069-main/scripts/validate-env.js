#!/usr/bin/env node

/**
 * Environment Variables Validation Script
 * Validates all required environment variables for production deployment
 */

const fs = require('fs');
const path = require('path');

// Color codes for console output
const colors = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  white: '\x1b[37m'
};

// Required environment variables by category
const requiredVars = {
  core: [
    'NEXT_PUBLIC_SUPABASE_URL',
    'NEXT_PUBLIC_SUPABASE_ANON_KEY',
    'SUPABASE_SERVICE_ROLE_KEY',
    'NEXT_PUBLIC_APP_URL',
    'NODE_ENV'
  ],
  security: [
    'JWT_SECRET',
    'ENCRYPTION_KEY',
    'WEBHOOK_SECRET'
  ],
  payments: {
    stripe: [
      'STRIPE_PUBLISHABLE_KEY',
      'STRIPE_SECRET_KEY',
      'STRIPE_WEBHOOK_SECRET'
    ],
    paypro: [
      'PAYPRO_MERCHANT_ID',
      'PAYPRO_SECRET_KEY',
      'PAYPRO_WEBHOOK_SECRET'
    ],
    paypal: [
      'PAYPAL_CLIENT_ID',
      'PAYPAL_CLIENT_SECRET',
      'PAYPAL_WEBHOOK_ID'
    ]
  },
  email: {
    sendgrid: [
      'SENDGRID_API_KEY',
      'SENDGRID_FROM_EMAIL'
    ],
    mailgun: [
      'MAILGUN_API_KEY',
      'MAILGUN_DOMAIN'
    ],
    resend: [
      'RESEND_API_KEY',
      'RESEND_FROM_EMAIL'
    ]
  }
};

// Load environment variables
require('dotenv').config({ path: '.env.local' });

function log(message, color = 'white') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

function validateCore() {
  log('\n🔍 Validating Core Configuration...', 'cyan');
  let valid = true;
  
  requiredVars.core.forEach(varName => {
    if (!process.env[varName]) {
      log(`❌ Missing: ${varName}`, 'red');
      valid = false;
    } else {
      log(`✅ Found: ${varName}`, 'green');
    }
  });
  
  return valid;
}

function validateSecurity() {
  log('\n🔐 Validating Security Configuration...', 'cyan');
  let valid = true;
  
  requiredVars.security.forEach(varName => {
    const value = process.env[varName];
    if (!value) {
      log(`❌ Missing: ${varName}`, 'red');
      valid = false;
    } else {
      // Check key strength
      if (varName === 'JWT_SECRET' && value.length < 32) {
        log(`⚠️  Warning: ${varName} should be at least 32 characters`, 'yellow');
      } else if (varName === 'ENCRYPTION_KEY' && value.length < 32) {
        log(`⚠️  Warning: ${varName} should be exactly 32 characters`, 'yellow');
      } else {
        log(`✅ Found: ${varName} (${value.length} chars)`, 'green');
      }
    }
  });
  
  return valid;
}

function validatePayments() {
  log('\n💳 Validating Payment Gateway Configuration...', 'cyan');
  let hasStripe = false;
  let hasPayPro = false;
  let hasPayPal = false;
  
  // Check Stripe
  const stripeVars = requiredVars.payments.stripe;
  const stripeValid = stripeVars.every(varName => {
    const exists = !!process.env[varName];
    if (exists) {
      log(`✅ Stripe: ${varName}`, 'green');
    }
    return exists;
  });
  
  if (stripeValid) {
    hasStripe = true;
    log('✅ Stripe configuration complete', 'green');
  } else {
    log('❌ Stripe configuration incomplete', 'red');
  }
  
  // Check PayPro
  const payproVars = requiredVars.payments.paypro;
  const payproValid = payproVars.every(varName => {
    const exists = !!process.env[varName];
    if (exists) {
      log(`✅ PayPro: ${varName}`, 'green');
    }
    return exists;
  });
  
  if (payproValid) {
    hasPayPro = true;
    log('✅ PayPro configuration complete', 'green');
  } else {
    log('❌ PayPro configuration incomplete', 'red');
  }
  
  // Check PayPal
  const paypalVars = requiredVars.payments.paypal;
  const paypalValid = paypalVars.every(varName => {
    const exists = !!process.env[varName];
    if (exists) {
      log(`✅ PayPal: ${varName}`, 'green');
    }
    return exists;
  });
  
  if (paypalValid) {
    hasPayPal = true;
    log('✅ PayPal configuration complete', 'green');
  } else {
    log('❌ PayPal configuration incomplete', 'red');
  }
  
  if (!hasStripe && !hasPayPro && !hasPayPal) {
    log('❌ No payment gateway configured! At least one is required.', 'red');
    return false;
  }
  
  return true;
}

function validateEmail() {
  log('\n📧 Validating Email Service Configuration...', 'cyan');
  const emailProvider = process.env.EMAIL_PROVIDER || 'sendgrid';
  
  log(`📮 Email provider: ${emailProvider}`, 'blue');
  
  const providerVars = requiredVars.email[emailProvider];
  if (!providerVars) {
    log(`❌ Unknown email provider: ${emailProvider}`, 'red');
    return false;
  }
  
  const valid = providerVars.every(varName => {
    const exists = !!process.env[varName];
    if (exists) {
      log(`✅ ${emailProvider.toUpperCase()}: ${varName}`, 'green');
    } else {
      log(`❌ Missing: ${varName}`, 'red');
    }
    return exists;
  });
  
  return valid;
}

function validateUrls() {
  log('\n🌐 Validating URLs and Endpoints...', 'cyan');
  let valid = true;
  
  const appUrl = process.env.NEXT_PUBLIC_APP_URL;
  if (appUrl) {
    try {
      new URL(appUrl);
      if (appUrl.startsWith('https://')) {
        log(`✅ App URL: ${appUrl}`, 'green');
      } else {
        log(`⚠️  Warning: App URL should use HTTPS in production`, 'yellow');
      }
    } catch (error) {
      log(`❌ Invalid App URL: ${appUrl}`, 'red');
      valid = false;
    }
  }
  
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  if (supabaseUrl) {
    try {
      new URL(supabaseUrl);
      log(`✅ Supabase URL: ${supabaseUrl}`, 'green');
    } catch (error) {
      log(`❌ Invalid Supabase URL: ${supabaseUrl}`, 'red');
      valid = false;
    }
  }
  
  return valid;
}

function generateSecurityKeys() {
  log('\n🔑 Security Key Generation Helper', 'magenta');
  log('Copy these generated keys to your .env file:', 'white');
  log('');
  
  const crypto = require('crypto');
  
  const jwtSecret = crypto.randomBytes(64).toString('base64');
  const encryptionKey = crypto.randomBytes(32).toString('base64').substring(0, 32);
  const webhookSecret = crypto.randomBytes(32).toString('base64');
  
  log(`JWT_SECRET=${jwtSecret}`, 'cyan');
  log(`ENCRYPTION_KEY=${encryptionKey}`, 'cyan');
  log(`WEBHOOK_SECRET=${webhookSecret}`, 'cyan');
  log('');
}

function checkEnvironmentFile() {
  const envPath = path.join(process.cwd(), '.env.local');
  if (!fs.existsSync(envPath)) {
    log('❌ .env.local file not found!', 'red');
    log('Create .env.local file and add your environment variables.', 'yellow');
    return false;
  }
  
  log('✅ .env.local file found', 'green');
  return true;
}

function main() {
  log('🚀 Rehma Foundation - Environment Validation', 'magenta');
  log('================================================', 'magenta');
  
  if (!checkEnvironmentFile()) {
    process.exit(1);
  }
  
  const results = {
    core: validateCore(),
    security: validateSecurity(),
    payments: validatePayments(),
    email: validateEmail(),
    urls: validateUrls()
  };
  
  log('\n📊 Validation Summary', 'magenta');
  log('====================', 'magenta');
  
  Object.entries(results).forEach(([category, isValid]) => {
    const status = isValid ? '✅ PASS' : '❌ FAIL';
    const color = isValid ? 'green' : 'red';
    log(`${category.toUpperCase()}: ${status}`, color);
  });
  
  const allValid = Object.values(results).every(Boolean);
  
  if (allValid) {
    log('\n🎉 All validations passed! Ready for production deployment.', 'green');
  } else {
    log('\n⚠️  Some validations failed. Please fix the issues above.', 'red');
    
    if (!results.security) {
      generateSecurityKeys();
    }
    
    process.exit(1);
  }
}

// Run validation if called directly
if (require.main === module) {
  main();
}

module.exports = { validateCore, validateSecurity, validatePayments, validateEmail };
