# 🚀 Rehma Foundation - Production Environment Setup Guide

## Overview
This guide will help you configure all production environment variables for the Rehma Foundation platform, including payment gateways, email services, and security configurations.

## 📋 Prerequisites
- Domain name configured and SSL certificate installed
- Supabase project created and configured
- Access to payment gateway merchant accounts
- Email service provider accounts

---

## 🏦 Payment Gateway Setup

### 1. Stripe Configuration (International Payments)

#### Step 1: Create Stripe Account
1. Go to [Stripe Dashboard](https://dashboard.stripe.com)
2. Complete business verification
3. Enable live mode

#### Step 2: Get API Keys
```bash
# Navigate to: Developers > API keys
STRIPE_PUBLISHABLE_KEY=pk_live_...
STRIPE_SECRET_KEY=sk_live_...
```

#### Step 3: Configure Webhooks
1. Go to Developers > Webhooks
2. Add endpoint: `https://your-domain.com/api/payments/webhook`
3. Select events:
   - `payment_intent.succeeded`
   - `payment_intent.payment_failed`
   - `customer.subscription.created`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
   - `invoice.payment_succeeded`
   - `invoice.payment_failed`

```bash
STRIPE_WEBHOOK_SECRET=whsec_...
```

### 2. PayPro Configuration (Pakistani Payments)

#### Step 1: Create PayPro Account
1. Visit [PayPro](https://paypro.com.pk)
2. Complete merchant registration
3. Get approval for live transactions

#### Step 2: Get Credentials
```bash
PAYPRO_MERCHANT_ID=your_merchant_id
PAYPRO_SECRET_KEY=your_secret_key
PAYPRO_API_URL=https://api.paypro.com.pk
```

#### Step 3: Configure Webhooks
1. Set webhook URL: `https://your-domain.com/api/payments/paypro-webhook`
2. Get webhook secret from PayPro dashboard

```bash
PAYPRO_WEBHOOK_SECRET=your_webhook_secret
```

### 3. PayPal Configuration

#### Step 1: Create PayPal Developer Account
1. Go to [PayPal Developer](https://developer.paypal.com/) and create an account.
2. Go to your Dashboard, and under "My Apps & Credentials", create a new App.
3. Choose "Live" mode for production credentials.

#### Step 2: Get API Credentials
```bash
# Get from your PayPal App details
PAYPAL_CLIENT_ID=your_live_client_id
PAYPAL_CLIENT_SECRET=your_live_client_secret
```

#### Step 3: Configure Webhooks
1. In your App settings, add a webhook URL: `https://your-domain.com/api/payments/paypal-webhook`
2. Select all events, or at least `CHECKOUT.ORDER.APPROVED`.
3. Get the Webhook ID from the webhook settings.

```bash
PAYPAL_WEBHOOK_ID=your_webhook_id
```

---

## 📧 Email Service Setup

### Option 1: SendGrid (Recommended)

#### Step 1: Create SendGrid Account
1. Go to [SendGrid](https://sendgrid.com)
2. Complete sender authentication
3. Verify domain

#### Step 2: Create API Key
1. Go to Settings > API Keys
2. Create key with full access
3. Configure sender identity

```bash
SENDGRID_API_KEY=SG.your_api_key
SENDGRID_FROM_EMAIL=noreply@your-domain.com
SENDGRID_FROM_NAME=Rehma Foundation
EMAIL_PROVIDER=sendgrid
```

### Option 2: Mailgun

#### Setup Steps
1. Create [Mailgun](https://mailgun.com) account
2. Add and verify your domain
3. Get API credentials

```bash
MAILGUN_API_KEY=your_api_key
MAILGUN_DOMAIN=your-domain.com
MAILGUN_FROM_EMAIL=noreply@your-domain.com
EMAIL_PROVIDER=mailgun
```

### Option 3: Resend

#### Setup Steps
1. Create [Resend](https://resend.com) account
2. Verify domain
3. Generate API key

```bash
RESEND_API_KEY=re_your_api_key
RESEND_FROM_EMAIL=noreply@your-domain.com
EMAIL_PROVIDER=resend
```

---

## 🔐 Security Configuration

### 1. Generate Secure Keys

```bash
# JWT Secret (64+ characters)
JWT_SECRET=$(openssl rand -base64 64)

# Encryption Key (32 characters)
ENCRYPTION_KEY=$(openssl rand -base64 32)

# Webhook Secret
WEBHOOK_SECRET=$(openssl rand -base64 32)
```

### 2. Security Headers & CORS
```bash
# Already configured in your Next.js app
NEXT_PUBLIC_APP_URL=https://your-domain.com
```

---

## 📊 Analytics & Monitoring

### 1. Google Analytics
```bash
# Get from Google Analytics 4
GOOGLE_ANALYTICS_ID=G-XXXXXXXXXX
```

### 2. Sentry Error Monitoring
```bash
# Create project at sentry.io
SENTRY_DSN=https://your_sentry_dsn
```

### 3. Vercel Analytics (if using Vercel)
```bash
VERCEL_ANALYTICS_ID=your_analytics_id
```

---

## 🚨 Production Checklist

### Before Going Live

- [ ] **Domain & SSL**
  - [ ] Domain configured with SSL certificate
  - [ ] DNS records properly set
  - [ ] CDN configured (if applicable)

- [ ] **Database**
  - [ ] Supabase project in production mode
  - [ ] Row Level Security (RLS) policies tested
  - [ ] Database backups configured
  - [ ] Connection pooling optimized

- [ ] **Payment Gateways**
  - [ ] Stripe live mode activated
  - [ ] PayPro merchant account approved
  - [ ] Webhook endpoints tested
  - [ ] Test transactions completed

- [ ] **Email Services**
  - [ ] Domain authentication completed
  - [ ] SPF/DKIM records configured
  - [ ] Email templates tested
  - [ ] Delivery rates monitored

- [ ] **Security**
  - [ ] All secrets properly generated
  - [ ] Environment variables secured
  - [ ] Rate limiting configured
  - [ ] CORS policies set

- [ ] **Monitoring**
  - [ ] Error tracking active
  - [ ] Performance monitoring set up
  - [ ] Uptime monitoring configured
  - [ ] Log aggregation working

### Environment Variables Validation

Run the validation script to ensure all required variables are set:

```bash
npm run validate-env
```

---

## 🔧 Environment Variables Template

Copy this template to your production `.env` file:

```bash
# ===========================================
# REHMA FOUNDATION - PRODUCTION ENVIRONMENT
# ===========================================

# Database Configuration
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key

# Application Configuration
NEXT_PUBLIC_APP_URL=https://your-domain.com
NEXT_PUBLIC_APP_NAME=Rehma Foundation
NEXT_PUBLIC_APP_DESCRIPTION=Infinite Blessings Here & After

# Payment Gateway Configuration
PAYPRO_MERCHANT_ID=your_paypro_merchant_id
PAYPRO_SECRET_KEY=your_paypro_secret_key
PAYPRO_API_URL=https://api.paypro.com.pk
PAYPRO_WEBHOOK_SECRET=your_paypro_webhook_secret

STRIPE_PUBLISHABLE_KEY=pk_live_your_stripe_publishable_key
STRIPE_SECRET_KEY=sk_live_your_stripe_secret_key
STRIPE_WEBHOOK_SECRET=whsec_your_stripe_webhook_secret

PAYPAL_CLIENT_ID=your_live_client_id
PAYPAL_CLIENT_SECRET=your_live_client_secret
PAYPAL_WEBHOOK_ID=your_webhook_id

# Email Service Configuration (Choose one)
EMAIL_PROVIDER=sendgrid
SENDGRID_API_KEY=SG.your_sendgrid_api_key
SENDGRID_FROM_EMAIL=noreply@your-domain.com
SENDGRID_FROM_NAME=Rehma Foundation

# Security Configuration
JWT_SECRET=your_64_character_jwt_secret
ENCRYPTION_KEY=your_32_character_encryption_key
WEBHOOK_SECRET=your_webhook_verification_secret

# Production Flags
NODE_ENV=production
NEXT_PUBLIC_ENVIRONMENT=production
ENABLE_DEBUG_LOGS=false
ENABLE_MAINTENANCE_MODE=false

# Analytics & Monitoring
GOOGLE_ANALYTICS_ID=G-XXXXXXXXXX
SENTRY_DSN=https://your_sentry_dsn

# Rate Limiting
RATE_LIMIT_MAX_REQUESTS=100
RATE_LIMIT_WINDOW_MS=900000
```

---

## 🆘 Support & Troubleshooting

### Common Issues

1. **Payment Gateway Errors**
   - Verify webhook URLs are accessible
   - Check API key permissions
   - Ensure SSL certificates are valid

2. **Email Delivery Issues**
   - Verify domain authentication
   - Check SPF/DKIM records
   - Monitor sender reputation

3. **Database Connection Issues**
   - Verify Supabase project status
   - Check connection string format
   - Monitor connection pool usage

### Getting Help

- Check the application logs for detailed error messages
- Use the built-in health check endpoints
- Monitor error tracking dashboard
- Contact support with specific error codes

---

## 📈 Performance Optimization

### Recommended Settings

```bash
# File Upload Limits
NEXT_PUBLIC_MAX_FILE_SIZE=5242880  # 5MB
NEXT_PUBLIC_ALLOWED_FILE_TYPES=image/jpeg,image/png,image/webp

# Cache Configuration
CACHE_TTL=3600  # 1 hour

# Rate Limiting (adjust based on traffic)
RATE_LIMIT_MAX_REQUESTS=100
RATE_LIMIT_WINDOW_MS=900000  # 15 minutes
```

### Monitoring Metrics

- Response times
- Error rates
- Payment success rates
- Email delivery rates
- Database query performance
- User engagement metrics

---

## SEO Automation Scheduling (Daily Emails)

Once deployed to Vercel, schedule the SEO automation to run every day and email reports automatically.

1. Go to your Vercel project → Settings → Cron Jobs
2. Add a new Cron:
   - Schedule: 0 0 * * *  (runs at 00:00 UTC daily)
   - Endpoint: /api/seo/run-daily
   - Region: Same as your deployment
3. Save. Vercel will invoke your endpoint daily. The job will:
   - Perform keyword research (if enabled)
   - Check rankings (if enabled)
   - Generate a daily report
   - Email the report to the address configured in Admin → SEO → Settings (daily_report_email)

Notes:
- Make sure your email provider env vars are set (see .env.example).
- You can also run the automation manually from Admin → SEO → “Run Automation”.

---

*Last updated: January 2025*
*For technical support, contact: tech@rehma.foundation*
